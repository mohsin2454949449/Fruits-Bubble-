#!/bin/bash
set -e

SOURCE="public/assets/aistudio/file_00000000ad04820c8107519d72f6c11a_4bc860ef.png"
RES_DIR="android/app/src/main/res"
TMP_DIR="/tmp/android_icons"

mkdir -p "$TMP_DIR"

echo "1. Creating master transparent logo..."
convert "$SOURCE" \
  -alpha set -fuzz 5% \
  -fill none -draw "color 0,0 floodfill" \
  -fill none -draw "color 1253,0 floodfill" \
  -fill none -draw "color 0,1253 floodfill" \
  -fill none -draw "color 1253,1253 floodfill" \
  "$TMP_DIR/logo_transparent.png"

# Define densities: name canvas_size(for adaptive foreground 108dp) inner_logo_size legacy_size(for ic_launcher 48dp)
declare -A FOREGROUND_SIZES=(
  ["mdpi"]="108:76"
  ["hdpi"]="162:114"
  ["xhdpi"]="216:152"
  ["xxhdpi"]="324:228"
  ["xxxhdpi"]="432:304"
)

declare -A LEGACY_SIZES=(
  ["mdpi"]="48"
  ["hdpi"]="72"
  ["xhdpi"]="96"
  ["xxhdpi"]="144"
  ["xxxhdpi"]="192"
)

for DENSITY in mdpi hdpi xhdpi xxhdpi xxxhdpi; do
  TARGET_DIR="$RES_DIR/mipmap-$DENSITY"
  mkdir -p "$TARGET_DIR"

  # 1. Generate Legacy Standard Icon (ic_launcher.png)
  LEGACY_SZ="${LEGACY_SIZES[$DENSITY]}"
  echo "Generating mipmap-$DENSITY/ic_launcher.png (${LEGACY_SZ}x${LEGACY_SZ})..."
  convert "$TMP_DIR/logo_transparent.png" \
    -filter Lanczos -resize "${LEGACY_SZ}x${LEGACY_SZ}" \
    "$TARGET_DIR/ic_launcher.png"

  # 2. Generate Legacy Round Icon (ic_launcher_round.png)
  echo "Generating mipmap-$DENSITY/ic_launcher_round.png (${LEGACY_SZ}x${LEGACY_SZ})..."
  RADIUS=$(( (LEGACY_SZ - 1) / 2 ))
  CENTER=$(( LEGACY_SZ / 2 ))
  convert "$TARGET_DIR/ic_launcher.png" \
    \( -size "${LEGACY_SZ}x${LEGACY_SZ}" xc:none -fill white -draw "circle $CENTER,$CENTER $CENTER,1" \) \
    -compose DstIn -composite \
    "$TARGET_DIR/ic_launcher_round.png"

  # 3. Generate Adaptive Foreground Icon (ic_launcher_foreground.png)
  FG_SPEC="${FOREGROUND_SIZES[$DENSITY]}"
  CANVAS_SZ="${FG_SPEC%%:*}"
  INNER_SZ="${FG_SPEC##*:}"
  echo "Generating mipmap-$DENSITY/ic_launcher_foreground.png (${CANVAS_SZ}x${CANVAS_SZ} with inner ${INNER_SZ}x${INNER_SZ} safe zone)..."
  convert -size "${CANVAS_SZ}x${CANVAS_SZ}" xc:none \
    \( "$TMP_DIR/logo_transparent.png" -filter Lanczos -resize "${INNER_SZ}x${INNER_SZ}" \) \
    -gravity center -composite \
    "$TARGET_DIR/ic_launcher_foreground.png"
done

# Also generate web / PWA / Play Store icons in public/
echo "Generating web icons in public/..."
convert "$TMP_DIR/logo_transparent.png" -filter Lanczos -resize 192x192 public/icon-192.png
convert "$TMP_DIR/logo_transparent.png" -filter Lanczos -resize 512x512 public/icon-512.png
convert "$TMP_DIR/logo_transparent.png" -filter Lanczos -resize 512x512 public/icon.png
convert "$TMP_DIR/logo_transparent.png" -filter Lanczos -resize 64x64 public/favicon.png

# Also copy to Android high-res Play Store icon
mkdir -p android/app/src/main/assets
cp public/icon-512.png android/app/src/main/playstore-icon.png 2>/dev/null || true

echo "All Android launcher icons generated successfully!"
