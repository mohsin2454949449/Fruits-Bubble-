/**
 * Centralized Google AdMob Configuration for Android
 * Uses Google's official test ad unit IDs for Android.
 */

export const ADMOB_CONFIG = {
  // Official Google Android Test Ad Unit IDs
  APP_ID: 'ca-app-pub-3940256099942544~3347511713',
  INTERSTITIAL_TEST_ID: 'ca-app-pub-3940256099942544/1033173712',
  REWARDED_TEST_ID: 'ca-app-pub-3940256099942544/5224354917',

  // Development & Testing flags
  IS_TESTING: true,

  // Interstitial frequency limits and constraints
  INTERSTITIAL_LEVEL_INTERVAL: 3, // Show interstitial after every 3 completed levels
  INTERSTITIAL_MIN_COOLDOWN_MS: 90_000, // 90 seconds minimum cooldown between interstitials

  // Rewarded Video options
  REWARD_AMOUNTS: {
    SMALL_BOOST: 500, // +500 Coins
    LARGE_BOOST: 1000, // +1,000 Coins
  },

  // Reward Ad cooldowns (in milliseconds) to prevent spamming
  REWARD_COOLDOWN_MS: 30_000, // 30s cooldown between rewarded ad requests
} as const;

export type AdType = 'interstitial' | 'rewarded';
export type AdState = 'idle' | 'loading' | 'loaded' | 'showing' | 'failed';

export interface AdReward {
  amount: number;
  type: string; // e.g. 'coins'
  label: string;
}
