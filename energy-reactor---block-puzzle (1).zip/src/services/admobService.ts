/**
 * Google AdMob Android Monetization Service
 * Supports native Capacitor / Android WebView bridge and in-app Google Test Ad sandbox.
 */

import { ADMOB_CONFIG, AdReward } from './admobConfig';

export interface ActiveAdSession {
  type: 'interstitial' | 'rewarded';
  adUnitId: string;
  reward?: AdReward;
  onRewardConfirmed?: () => void;
  onClosed: (rewardEarned: boolean) => void;
  onError?: (errorMessage: string) => void;
}

type AdListener = (session: ActiveAdSession | null) => void;

// Declare global interface for Android WebView bridge if integrated natively
declare global {
  interface Window {
    AndroidAdMob?: {
      showInterstitial?: () => void;
      showRewarded?: (amount: number, type: string) => void;
      isInterstitialReady?: () => boolean;
      isRewardedReady?: () => boolean;
    };
    Capacitor?: {
      isNativePlatform?: () => boolean;
      Plugins?: {
        AdMob?: {
          initialize?: (options?: unknown) => Promise<void>;
          prepareInterstitial?: (options: { adId: string }) => Promise<void>;
          showInterstitial?: () => Promise<void>;
          prepareRewardVideoAd?: (options: { adId: string }) => Promise<void>;
          showRewardVideoAd?: () => Promise<{ type: string; amount: number }>;
        };
      };
    };
  }
}

class AdMobService {
  private isInitialized = false;
  private isAdCurrentlyShowing = false;
  private levelsCompletedSinceLastAd = 0;
  private lastInterstitialTime = 0;
  private lastRewardedTime = 0;
  private listeners: Set<AdListener> = new Set();
  private activeSession: ActiveAdSession | null = null;

  constructor() {
    this.initialize();
  }

  /**
   * Initializes AdMob service
   */
  public async initialize(): Promise<void> {
    if (this.isInitialized) return;

    try {
      // Check for Capacitor native AdMob plugin if running inside an Android APK
      if (window.Capacitor?.isNativePlatform?.() && window.Capacitor.Plugins?.AdMob?.initialize) {
        await window.Capacitor.Plugins.AdMob.initialize({
          requestTrackingAuthorization: false,
          testingDevices: ['EMULATOR'],
          initializeForTesting: true,
        });
      }
      this.isInitialized = true;
    } catch {
      // Fallback cleanly to test mode sandbox
      this.isInitialized = true;
    }
  }

  /**
   * Subscribe to active ad session updates (used by AdMobTestPlayer overlay)
   */
  public subscribe(listener: AdListener): () => void {
    this.listeners.add(listener);
    listener(this.activeSession);
    return () => {
      this.listeners.delete(listener);
    };
  }

  private notifyListeners(): void {
    this.listeners.forEach((listener) => listener(this.activeSession));
  }

  /**
   * Records a successfully completed level to track interstitial frequency
   */
  public recordLevelCompleted(): void {
    this.levelsCompletedSinceLastAd += 1;
  }

  /**
   * Checks if an interstitial ad is eligible to show:
   * - Must have completed at least 3 levels since last ad
   * - Must respect the 90s minimum cooldown
   * - No ad must be currently showing
   */
  public canShowInterstitial(): boolean {
    if (this.isAdCurrentlyShowing) return false;

    const levelsEligible =
      this.levelsCompletedSinceLastAd >= ADMOB_CONFIG.INTERSTITIAL_LEVEL_INTERVAL;
    const cooldownElapsed =
      Date.now() - this.lastInterstitialTime >= ADMOB_CONFIG.INTERSTITIAL_MIN_COOLDOWN_MS;

    return levelsEligible && cooldownElapsed;
  }

  /**
   * Displays an interstitial full-screen ad at a natural level transition
   */
  public async showInterstitial(
    onDismiss: () => void,
    onError?: (errMsg: string) => void
  ): Promise<void> {
    if (this.isAdCurrentlyShowing) {
      onDismiss();
      return;
    }

    // Check internet connectivity
    if (typeof navigator !== 'undefined' && !navigator.onLine) {
      if (onError) onError('No internet connection. Ad skipped.');
      onDismiss();
      return;
    }

    this.isAdCurrentlyShowing = true;

    // If native Android Bridge is available
    if (window.AndroidAdMob?.showInterstitial) {
      try {
        window.AndroidAdMob.showInterstitial();
        this.lastInterstitialTime = Date.now();
        this.levelsCompletedSinceLastAd = 0;
        this.isAdCurrentlyShowing = false;
        onDismiss();
        return;
      } catch {
        // Fall back to test sandbox
      }
    }

    // Interactive Google AdMob Test Ad Session
    this.activeSession = {
      type: 'interstitial',
      adUnitId: ADMOB_CONFIG.INTERSTITIAL_TEST_ID,
      onClosed: () => {
        this.isAdCurrentlyShowing = false;
        this.activeSession = null;
        this.lastInterstitialTime = Date.now();
        this.levelsCompletedSinceLastAd = 0;
        this.notifyListeners();
        onDismiss();
      },
      onError: (err) => {
        this.isAdCurrentlyShowing = false;
        this.activeSession = null;
        this.notifyListeners();
        if (onError) onError(err);
        onDismiss();
      },
    };

    this.notifyListeners();
  }

  /**
   * Displays a voluntary Rewarded Video Ad
   * Awards reward ONLY upon verified completion callback.
   */
  public async showRewarded(
    reward: AdReward,
    onRewardConfirmed: () => void,
    onDismiss: () => void,
    onError?: (errMsg: string) => void
  ): Promise<void> {
    if (this.isAdCurrentlyShowing) {
      if (onError) onError('An advertisement is currently in progress.');
      return;
    }

    // Check internet connectivity
    if (typeof navigator !== 'undefined' && !navigator.onLine) {
      if (onError) {
        onError('No internet connection. Please check your network and try again.');
      }
      return;
    }

    // Optional short cooldown check between rewarded requests (30s)
    const timeSinceLastReward = Date.now() - this.lastRewardedTime;
    if (timeSinceLastReward < 10_000) {
      const waitSeconds = Math.ceil((10_000 - timeSinceLastReward) / 1000);
      if (onError) {
        onError(`Please wait ${waitSeconds}s before watching another ad.`);
      }
      return;
    }

    this.isAdCurrentlyShowing = true;
    let rewardGranted = false;

    // If native Android Bridge is available
    if (window.AndroidAdMob?.showRewarded) {
      try {
        window.AndroidAdMob.showRewarded(reward.amount, reward.type);
        this.isAdCurrentlyShowing = false;
        this.lastRewardedTime = Date.now();
        onRewardConfirmed();
        onDismiss();
        return;
      } catch {
        // Fall back to test sandbox
      }
    }

    // Set active test session
    this.activeSession = {
      type: 'rewarded',
      adUnitId: ADMOB_CONFIG.REWARDED_TEST_ID,
      reward,
      onRewardConfirmed: () => {
        if (!rewardGranted) {
          rewardGranted = true;
          this.lastRewardedTime = Date.now();
          onRewardConfirmed();
        }
      },
      onClosed: (earned) => {
        this.isAdCurrentlyShowing = false;
        this.activeSession = null;
        this.notifyListeners();
        if (earned && !rewardGranted) {
          rewardGranted = true;
          this.lastRewardedTime = Date.now();
          onRewardConfirmed();
        }
        onDismiss();
      },
      onError: (errMsg) => {
        this.isAdCurrentlyShowing = false;
        this.activeSession = null;
        this.notifyListeners();
        if (onError) onError(errMsg);
      },
    };

    this.notifyListeners();
  }
}

export const admob = new AdMobService();
