export type ReactorColor = 'blue' | 'red' | 'green' | 'yellow' | 'purple';

export interface ColorScheme {
  id: ReactorColor;
  name: string;
  primary: string;
  core: string;
  coreHighlight: string;
  plasmaGlow: string;
  borderDark: string;
  borderLight: string;
  recessed: string;
  socketTint: string;
}

export type GridCell = {
  filled: boolean;
  color: ReactorColor | null;
  clearing?: boolean;
  clearingDelay?: number;
  highlighted?: boolean;
  justPlaced?: boolean;
};

export type BoardMatrix = GridCell[][];

export interface PieceShape {
  id: string;
  name: string;
  matrix: number[][]; // 1 = filled cell, 0 = empty
  width: number;
  height: number;
}

export interface GamePiece {
  id: string;
  shape: PieceShape;
  color: ReactorColor;
  used: boolean;
  canFit: boolean;
  rotation?: number; // 0, 90, 180, 270
}

export interface DragPosition {
  x: number;
  y: number;
}

export interface PlacementPreview {
  valid: boolean;
  startRow: number;
  startCol: number;
  cells: { r: number; c: number }[];
  clearingRows: number[];
  clearingCols: number[];
}

export interface GameStats {
  score: number;
  highScore: number;
  linesCleared: number;
  blocksPlaced: number;
  comboStreak: number;
  maxCombo: number;
}

export interface ScoreBreakdown {
  baseScore: number;
  multiplier: number;
  finalPoints: number;
}

// Navigation & Screen Types
export type NavigationScreen =
  | 'home'
  | 'game'
  | 'levels'
  | 'store'
  | 'daily'
  | 'settings'
  | 'profile'
  | 'achievements';

// Level System
export interface LevelData {
  levelNumber: number;
  targetScore: number;
  rewardCoins: number;
  title: string;
  difficulty: 'normal' | 'hard' | 'expert' | 'legendary';
}

export interface LevelProgress {
  completed: boolean;
  stars: number;
  bestScore: number;
}

// Store & Cosmetics
export type StoreItemType = 'blockSkin' | 'boardTheme' | 'bgTheme' | 'powerup';

export interface StoreItem {
  id: string;
  name: string;
  type: StoreItemType;
  price: number;
  currency: 'coins';
  description: string;
  previewGradient?: string;
  previewColor?: string;
  badge?: string;
}

export interface PowerUpInventory {
  hammer: number;  // Break any single block on grid
  refresh: number; // Reroll upcoming batch pieces
}

// Daily Rewards
export interface DailyGift {
  day: number;
  coins: number;
  specialReward?: string;
  label: string;
}

// Achievements
export interface Achievement {
  id: string;
  title: string;
  description: string;
  target: number;
  rewardCoins: number;
  icon: string;
}

// User Profile & Save State
export interface PlayerProfile {
  level: number;
  completedLevels: Record<number, LevelProgress>;
  coins: number;
  highScore: number;
  totalGames: number;
  totalLines: number;
  totalBlocks: number;
  maxCombo: number;
  equippedBlockSkin: string;
  equippedBoardTheme: string;
  equippedBgTheme: string;
  purchasedItems: string[];
  powerups: PowerUpInventory;
  claimedAchievements: string[];
  claimedMilestones: number[];
  lastDailyClaimDate: string; // YYYY-MM-DD
  dailyStreak: number;
}

export interface GameSettings {
  soundEnabled: boolean;
  musicEnabled: boolean;
  vibrationEnabled: boolean;
}
