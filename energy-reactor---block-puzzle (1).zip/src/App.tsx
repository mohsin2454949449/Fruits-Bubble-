import React, { useState, useEffect, useRef, useCallback } from 'react';
import {
  BoardMatrix,
  GamePiece,
  GameStats,
  PlacementPreview,
  ReactorColor,
  ScoreBreakdown,
  NavigationScreen,
  PlayerProfile,
  GameSettings,
  StoreItem,
  DailyGift,
  Achievement,
} from './types/game';
import {
  BOARD_SIZE,
  canPlacePiece,
  canPieceFitAnywhere,
  checkIsGameOver,
  createEmptyBoard,
  executeClearLines,
  getPlacementPreview,
  placePieceOnBoard,
  calculateScore,
  rotatePiece90,
} from './utils/gameLogic';
import { generateThreePieces } from './utils/shapes';
import { sound } from './utils/audio';
import { getLevelData, getLevelTarget } from './utils/levelData';
import {
  loadProfile,
  saveProfile,
  loadSettings,
  saveSettings,
  triggerHaptic,
} from './utils/saveManager';
import { HomeScreen } from './components/HomeScreen';
import { LevelsScreen } from './components/LevelsScreen';
import { StoreScreen } from './components/StoreScreen';
import { DailyGiftsScreen } from './components/DailyGiftsScreen';
import { ProfileScreen } from './components/ProfileScreen';
import { AchievementsScreen } from './components/AchievementsScreen';
import { GameBoard } from './components/GameBoard';
import { PieceTray } from './components/PieceTray';
import { ScoreHeader } from './components/ScoreHeader';
import { ParticleCanvas, ParticleEffect } from './components/ParticleCanvas';
import { GameOverModal } from './components/GameOverModal';
import { LevelCompleteModal } from './components/LevelCompleteModal';
import { SettingsModal } from './components/SettingsModal';
import { ReactorBlock } from './components/ReactorBlock';
import { LineClearAnnouncement, LineAnnouncementData } from './components/LineClearAnnouncement';
import { ComboNotification, ComboNotificationData } from './components/ComboNotification';
import { BackgroundRenderer } from './components/BackgroundRenderer';
import { MilestoneChestModal } from './components/MilestoneChestModal';
import { isMilestoneLevel, generateMilestoneReward, MilestoneReward } from './utils/milestoneRewards';
import { admob } from './services/admobService';
import { AdMobTestPlayer } from './components/AdMobTestPlayer';
import { WatchAdModal } from './components/WatchAdModal';
import { Sparkles } from 'lucide-react';

export default function App() {
  // Navigation Screen State (Starts at 'home' as requested)
  const [currentScreen, setCurrentScreen] = useState<NavigationScreen>('home');

  // Milestone Mystery Reward Chest State
  const [activeMilestoneChest, setActiveMilestoneChest] = useState<{
    milestoneLevel: number;
    reward: MilestoneReward;
  } | null>(null);

  // Google AdMob Rewarded & Interstitial State
  const [isWatchAdModalOpen, setIsWatchAdModalOpen] = useState(false);
  const [hasClaimedAdBonus, setHasClaimedAdBonus] = useState(false);
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  // Persisted Profile & Settings State
  const [profile, setProfile] = useState<PlayerProfile>(() => loadProfile());
  const [settings, setSettings] = useState<GameSettings>(() => loadSettings());

  // Current Level State (Independent score for each level)
  const [currentLevel, setCurrentLevel] = useState<number>(() => profile.level);
  const currentTargetScore = getLevelTarget(currentLevel);

  // Active Game State
  const [board, setBoard] = useState<BoardMatrix>(() => createEmptyBoard());
  const [pieces, setPieces] = useState<GamePiece[]>(() => generateThreePieces());
  const [selectedPieceId, setSelectedPieceId] = useState<string | null>(null);

  // Dragging State
  const [draggedPiece, setDraggedPiece] = useState<GamePiece | null>(null);
  const [dragPos, setDragPos] = useState<{ x: number; y: number } | null>(null);
  const [isTouchDevice, setIsTouchDevice] = useState<boolean>(false);
  const [preview, setPreview] = useState<PlacementPreview | null>(null);

  // Level Score & Metrics (Level score starts strictly from 0 points)
  const [score, setScore] = useState<number>(0);
  const [comboStreak, setComboStreak] = useState<number>(0);
  const [lastScoreInfo, setLastScoreInfo] = useState<(ScoreBreakdown & { linesCount: number }) | null>(null);
  const [linesCleared, setLinesCleared] = useState<number>(0);
  const [blocksPlaced, setBlocksPlaced] = useState<number>(0);
  const [maxCombo, setMaxCombo] = useState<number>(0);

  // Power-Ups in Game
  const [hammerActive, setHammerActive] = useState<boolean>(false);

  // Modals & Popups
  const [isGameOver, setIsGameOver] = useState<boolean>(false);
  const [isNewRecord, setIsNewRecord] = useState<boolean>(false);
  const [isLevelCompleteModalOpen, setIsLevelCompleteModalOpen] = useState<boolean>(false);
  const [isSettingsOpen, setIsSettingsOpen] = useState<boolean>(false);

  // Announcements & Combo Notifications
  const [lineAnnouncement, setLineAnnouncement] = useState<LineAnnouncementData | null>(null);
  const [comboNotification, setComboNotification] = useState<ComboNotificationData | null>(null);
  const comboTimeoutRef = useRef<NodeJS.Timeout | null>(null);
  const comboDismissTimeoutRef = useRef<NodeJS.Timeout | null>(null);

  // Refs
  const boardContainerRef = useRef<HTMLDivElement | null>(null);
  const particleCanvasRef = useRef<ParticleEffect | null>(null);
  const isProcessingPlacementRef = useRef<boolean>(false);

  // Touch offset
  const TOUCH_Y_OFFSET = 50;

  // Initialize audio / music preferences on mount
  useEffect(() => {
    sound.setMuted(!settings.soundEnabled);
    sound.setMusicMuted(!settings.musicEnabled);
    if (settings.musicEnabled) {
      sound.startBgm();
    }
    return () => {
      sound.stopBgm();
    };
  }, []);

  // Update Profile Helper
  const updateProfile = useCallback((updater: (prev: PlayerProfile) => PlayerProfile) => {
    setProfile((prev) => {
      const next = updater(prev);
      saveProfile(next);
      return next;
    });
  }, []);

  // Update Settings Helper
  const handleUpdateSettings = useCallback((newSettings: Partial<GameSettings>) => {
    setSettings((prev) => {
      const next = { ...prev, ...newSettings };
      saveSettings(next);
      if (newSettings.soundEnabled !== undefined) {
        sound.setMuted(!newSettings.soundEnabled);
      }
      if (newSettings.musicEnabled !== undefined) {
        sound.setMusicMuted(!newSettings.musicEnabled);
      }
      return next;
    });
  }, []);

  // Start Level with ZERO points and clean board
  const startLevel = useCallback((lvl: number) => {
    sound.unlockAudio();
    sound.playClick();
    setCurrentLevel(lvl);
    setScore(0);
    setComboStreak(0);
    setLinesCleared(0);
    setBlocksPlaced(0);
    setMaxCombo(0);
    setLastScoreInfo(null);
    setBoard(createEmptyBoard());
    setPieces(generateThreePieces(lvl));
    setSelectedPieceId(null);
    setDraggedPiece(null);
    setPreview(null);
    setHammerActive(false);
    setIsGameOver(false);
    setIsLevelCompleteModalOpen(false);
    setHasClaimedAdBonus(false);
    setIsNewRecord(false);
    isProcessingPlacementRef.current = false;
    setCurrentScreen('game');

    // Trigger BGM if enabled
    if (settings.musicEnabled) {
      sound.startBgm();
    }
  }, [settings.musicEnabled]);

  // Restart current level
  const handleRestartLevel = useCallback(() => {
    startLevel(currentLevel);
  }, [startLevel, currentLevel]);

  // Reset High Score
  const handleResetHighScore = useCallback(() => {
    updateProfile((prev) => ({ ...prev, highScore: 0 }));
    localStorage.removeItem('block_pulse_high_score');
  }, [updateProfile]);

  // Trigger combo notification with 5-second duration
  const triggerComboNotification = useCallback((count: number, multiplier: number) => {
    if (comboTimeoutRef.current) clearTimeout(comboTimeoutRef.current);
    if (comboDismissTimeoutRef.current) clearTimeout(comboDismissTimeoutRef.current);

    setComboNotification({
      id: Date.now(),
      count,
      multiplier,
      visible: true,
    });

    comboTimeoutRef.current = setTimeout(() => {
      setComboNotification((prev) => (prev ? { ...prev, visible: false } : null));
      comboDismissTimeoutRef.current = setTimeout(() => {
        setComboNotification(null);
      }, 350);
    }, 5000);
  }, []);

  const dismissComboNotification = useCallback(() => {
    if (comboTimeoutRef.current) clearTimeout(comboTimeoutRef.current);
    if (comboDismissTimeoutRef.current) clearTimeout(comboDismissTimeoutRef.current);
    setComboNotification((prev) => (prev ? { ...prev, visible: false } : null));
    comboDismissTimeoutRef.current = setTimeout(() => {
      setComboNotification(null);
    }, 350);
  }, []);

  // Announcement label mapping
  const getAnnouncementText = useCallback((lines: number): string => {
    if (lines === 2) return 'NICE!';
    if (lines === 3) return 'GREAT!';
    if (lines === 4) return 'EXCELLENT!';
    if (lines === 5) return 'IMPRESSIVE!';
    if (lines === 6) return 'UNBELIEVABLE!';
    if (lines >= 7) return 'LEGENDARY!';
    return '';
  }, []);

  // Refresh piece fit viability whenever board changes
  useEffect(() => {
    setPieces((prev) =>
      prev.map((p) => {
        if (p.used) return p;
        const { height, width } = p.shape;
        let fits = false;
        for (let r = 0; r <= BOARD_SIZE - height; r++) {
          for (let c = 0; c <= BOARD_SIZE - width; c++) {
            if (canPlacePiece(board, p, r, c)) {
              fits = true;
              break;
            }
          }
          if (fits) break;
        }
        return { ...p, canFit: fits };
      })
    );
  }, [board]);

  // Check Game Over
  const verifyGameOver = useCallback(
    (currentBoard: BoardMatrix, currentPieces: GamePiece[]) => {
      const isOver = checkIsGameOver(currentBoard, currentPieces);
      if (isOver && !isLevelCompleteModalOpen) {
        sound.playGameOver();
        setIsGameOver(true);
        triggerHaptic(settings.vibrationEnabled, [80, 50, 120]);
      }
    },
    [isLevelCompleteModalOpen, settings.vibrationEnabled]
  );

  // Calculate target grid coordinates
  const getGridCoordinates = useCallback(
    (clientX: number, clientY: number, piece: GamePiece): { row: number; col: number } | null => {
      const boardEl = boardContainerRef.current;
      if (!boardEl) return null;

      const rect = boardEl.getBoundingClientRect();
      const cellWidth = rect.width / BOARD_SIZE;
      const cellHeight = rect.height / BOARD_SIZE;

      const targetX = clientX - (piece.shape.width * cellWidth) / 2;
      const targetY = clientY - (piece.shape.height * cellHeight) / 2;

      const col = Math.round((targetX - rect.left) / cellWidth);
      const row = Math.round((targetY - rect.top) / cellHeight);

      return { row, col };
    },
    []
  );

  // Commit Placement with Level Scoring Rules
  const commitPlacement = useCallback(
    (piece: GamePiece, startRow: number, startCol: number) => {
      if (isProcessingPlacementRef.current) return false;
      if (piece.used) return false;

      const currentPiece = pieces.find((p) => p.id === piece.id && !p.used);
      if (!currentPiece) return false;

      if (!canPlacePiece(board, piece, startRow, startCol)) {
        sound.playInvalid();
        triggerHaptic(settings.vibrationEnabled, 40);
        return false;
      }

      isProcessingPlacementRef.current = true;

      // 1. Place piece on grid
      const { newBoard, clearedRows, clearedCols, cellsCount } = placePieceOnBoard(
        board,
        piece,
        startRow,
        startCol
      );

      // Trigger placement sparks
      if (boardContainerRef.current && particleCanvasRef.current) {
        const rect = boardContainerRef.current.getBoundingClientRect();
        const cellW = rect.width / BOARD_SIZE;
        const cellH = rect.height / BOARD_SIZE;
        const impactX = rect.left + (startCol + piece.shape.width / 2) * cellW;
        const impactY = rect.top + (startRow + piece.shape.height / 2) * cellH;
        particleCanvasRef.current.triggerPlaceImpact(impactX, impactY, piece.color);
      }

      sound.playPlace();
      triggerHaptic(settings.vibrationEnabled, 25);

      const updatedPieces = pieces.map((p) => (p.id === piece.id ? { ...p, used: true } : p));
      const allThreeUsed = updatedPieces.every((p) => p.used);

      setPieces(updatedPieces);
      setSelectedPieceId(null);
      setBlocksPlaced((prev) => prev + cellsCount);

      // Update total blocks in profile
      updateProfile((prev) => ({
        ...prev,
        totalBlocks: prev.totalBlocks + cellsCount,
      }));

      // 2. Line clear detection
      const totalLinesCleared = clearedRows.length + clearedCols.length;

      // RULE: NO POINTS ON PLACEMENT WITHOUT LINE CLEAR
      if (totalLinesCleared === 0) {
        setComboStreak(0);
        dismissComboNotification();
        setLastScoreInfo(null);
        setBoard(newBoard);

        if (allThreeUsed) {
          const nextBatch = generateThreePieces();
          setPieces(nextBatch);
          verifyGameOver(newBoard, nextBatch);
        } else {
          verifyGameOver(newBoard, updatedPieces);
        }

        isProcessingPlacementRef.current = false;
        return true;
      }

      // 3. LINES CLEARED - Score calculation & multiplier
      const scoreResult = calculateScore(totalLinesCleared, comboStreak);

      // Highlight clearing lines
      for (const r of clearedRows) {
        for (let c = 0; c < BOARD_SIZE; c++) {
          newBoard[r][c].clearing = true;
        }
      }
      for (const c of clearedCols) {
        for (let r = 0; r < BOARD_SIZE; r++) {
          newBoard[r][c].clearing = true;
        }
      }
      setBoard(newBoard);

      // Sound and announcement
      sound.playLineClearAnnouncement(totalLinesCleared);
      triggerHaptic(settings.vibrationEnabled, [40, 60, 80]);

      if (totalLinesCleared >= 2) {
        const announcementText = getAnnouncementText(totalLinesCleared);
        setLineAnnouncement({
          id: Date.now(),
          linesCount: totalLinesCleared,
          text: announcementText,
        });
      }

      // Combo achievement
      if (scoreResult.newConsecutiveClears >= 2) {
        setTimeout(() => {
          sound.playCombo(scoreResult.newConsecutiveClears);
        }, 120);
        triggerComboNotification(
          scoreResult.newConsecutiveClears,
          scoreResult.multiplier
        );
      }

      // Particles
      if (boardContainerRef.current && particleCanvasRef.current) {
        const rect = boardContainerRef.current.getBoundingClientRect();
        const comboLabel = scoreResult.multiplier > 1 ? ` (COMBO ×${scoreResult.multiplier})` : '';
        const floatingText = `+${scoreResult.finalPoints.toLocaleString()}${comboLabel}`;

        particleCanvasRef.current.triggerLineClear(
          clearedRows,
          clearedCols,
          rect,
          piece.color,
          floatingText
        );
      }

      // Execute clear and scoring after blast animation (280ms)
      setTimeout(() => {
        setBoard((b) => {
          const clearedBoard = executeClearLines(b, clearedRows, clearedCols);

          setScore((prevScore) => {
            const nextScore = prevScore + scoreResult.finalPoints;

            // Check Level Completion
            if (nextScore >= currentTargetScore && !isLevelCompleteModalOpen) {
              const lvlInfo = getLevelData(currentLevel);
              sound.playLevelComplete();
              triggerHaptic(settings.vibrationEnabled, [60, 100, 160]);

              // Update Profile with Level Completion & Rewards
              updateProfile((prevProfile) => {
                const nextLevelUnlocked = Math.max(prevProfile.level, currentLevel + 1);
                const prevLevelRecord = prevProfile.completedLevels[currentLevel];
                const alreadyCompleted = !!prevLevelRecord?.completed;

                // Award coins on completion
                const earnedCoins = alreadyCompleted ? Math.round(lvlInfo.rewardCoins / 3) : lvlInfo.rewardCoins;

                return {
                  ...prevProfile,
                  level: nextLevelUnlocked,
                  coins: prevProfile.coins + earnedCoins,
                  highScore: Math.max(prevProfile.highScore, nextScore),
                  totalLines: prevProfile.totalLines + totalLinesCleared,
                  completedLevels: {
                    ...prevProfile.completedLevels,
                    [currentLevel]: {
                      completed: true,
                      stars: 3,
                      bestScore: Math.max(prevLevelRecord?.bestScore || 0, nextScore),
                    },
                  },
                };
              });

              admob.recordLevelCompleted();
              setHasClaimedAdBonus(false);
              setIsLevelCompleteModalOpen(true);
            } else {
              // Update High Score if exceeded
              if (nextScore > profile.highScore) {
                setIsNewRecord(true);
                updateProfile((p) => ({ ...p, highScore: nextScore }));
              }
            }

            return nextScore;
          });

          // Update combo & stats
          setComboStreak(scoreResult.newConsecutiveClears);
          setMaxCombo((prev) => Math.max(prev, scoreResult.newConsecutiveClears));
          setLinesCleared((prev) => prev + totalLinesCleared);
          setLastScoreInfo({
            baseScore: scoreResult.baseScore,
            multiplier: scoreResult.multiplier,
            finalPoints: scoreResult.finalPoints,
            linesCount: totalLinesCleared,
          });

          // Update total lines in profile
          updateProfile((p) => ({
            ...p,
            totalLines: p.totalLines + totalLinesCleared,
            maxCombo: Math.max(p.maxCombo, scoreResult.newConsecutiveClears),
          }));

          // Batch transition
          if (allThreeUsed) {
            const nextBatch = generateThreePieces(currentLevel);
            setPieces(nextBatch);
            verifyGameOver(clearedBoard, nextBatch);
          } else {
            verifyGameOver(clearedBoard, updatedPieces);
          }

          isProcessingPlacementRef.current = false;
          return clearedBoard;
        });
      }, 280);

      return true;
    },
    [
      board,
      pieces,
      profile.highScore,
      comboStreak,
      currentLevel,
      currentTargetScore,
      isLevelCompleteModalOpen,
      settings.vibrationEnabled,
      verifyGameOver,
      dismissComboNotification,
      triggerComboNotification,
      getAnnouncementText,
      updateProfile,
    ]
  );

  // Drag handlers
  const handleDragStart = useCallback(
    (piece: GamePiece, clientX: number, clientY: number) => {
      sound.playPickup();
      triggerHaptic(settings.vibrationEnabled, 20);
      setDraggedPiece(piece);
      setSelectedPieceId(piece.id);

      const isTouch = window.matchMedia('(pointer: coarse)').matches;
      setIsTouchDevice(isTouch);

      const yPos = isTouch ? clientY - TOUCH_Y_OFFSET : clientY;
      setDragPos({ x: clientX, y: yPos });

      const coords = getGridCoordinates(clientX, yPos, piece);
      if (coords) {
        const p = getPlacementPreview(board, piece, coords.row, coords.col);
        setPreview(p);
      }
    },
    [board, getGridCoordinates, settings.vibrationEnabled]
  );

  // Pointer movement listener while dragging
  useEffect(() => {
    if (!draggedPiece) return;

    const handlePointerMove = (e: MouseEvent | TouchEvent) => {
      let clientX = 0;
      let clientY = 0;

      if ('touches' in e && e.touches.length > 0) {
        clientX = e.touches[0].clientX;
        clientY = e.touches[0].clientY;
      } else if ('clientX' in e) {
        clientX = e.clientX;
        clientY = e.clientY;
      }

      const yPos = isTouchDevice ? clientY - TOUCH_Y_OFFSET : clientY;
      setDragPos({ x: clientX, y: yPos });

      const coords = getGridCoordinates(clientX, yPos, draggedPiece);
      if (coords) {
        const p = getPlacementPreview(board, draggedPiece, coords.row, coords.col);
        setPreview(p);
      } else {
        setPreview(null);
      }
    };

    const handlePointerUp = (e: MouseEvent | TouchEvent) => {
      let clientX = 0;
      let clientY = 0;

      if ('changedTouches' in e && e.changedTouches.length > 0) {
        clientX = e.changedTouches[0].clientX;
        clientY = e.changedTouches[0].clientY;
      } else if ('clientX' in e) {
        clientX = e.clientX;
        clientY = e.clientY;
      }

      const yPos = isTouchDevice ? clientY - TOUCH_Y_OFFSET : clientY;
      const coords = getGridCoordinates(clientX, yPos, draggedPiece);

      if (coords && canPlacePiece(board, draggedPiece, coords.row, coords.col)) {
        commitPlacement(draggedPiece, coords.row, coords.col);
      } else {
        sound.playInvalid();
      }

      setDraggedPiece(null);
      setDragPos(null);
      setPreview(null);
    };

    window.addEventListener('mousemove', handlePointerMove, { passive: false });
    window.addEventListener('mouseup', handlePointerUp);
    window.addEventListener('touchmove', handlePointerMove, { passive: false });
    window.addEventListener('touchend', handlePointerUp);
    window.addEventListener('touchcancel', handlePointerUp);

    return () => {
      window.removeEventListener('mousemove', handlePointerMove);
      window.removeEventListener('mouseup', handlePointerUp);
      window.removeEventListener('touchmove', handlePointerMove);
      window.removeEventListener('touchend', handlePointerUp);
      window.removeEventListener('touchcancel', handlePointerUp);
    };
  }, [draggedPiece, isTouchDevice, board, getGridCoordinates, commitPlacement]);

  // Tap-to-place cell click or Hammer smash
  const handleCellClick = useCallback(
    (row: number, col: number) => {
      // 1. Hammer Mode: Smash single core
      if (hammerActive) {
        if (board[row][col].filled) {
          sound.playPowerup();
          triggerHaptic(settings.vibrationEnabled, [50, 50]);

          // Trigger particle blast at cell
          if (boardContainerRef.current && particleCanvasRef.current) {
            const rect = boardContainerRef.current.getBoundingClientRect();
            const cellW = rect.width / BOARD_SIZE;
            const cellH = rect.height / BOARD_SIZE;
            particleCanvasRef.current.triggerPlaceImpact(
              rect.left + (col + 0.5) * cellW,
              rect.top + (row + 0.5) * cellH,
              board[row][col].color || 'blue'
            );
          }

          // Remove cell
          setBoard((b) => {
            const nb = b.map((r) => r.map((c) => ({ ...c })));
            nb[row][col] = { filled: false, color: null };
            return nb;
          });

          // Decrement hammer
          updateProfile((p) => ({
            ...p,
            powerups: {
              ...p.powerups,
              hammer: Math.max(0, p.powerups.hammer - 1),
            },
          }));

          setHammerActive(false);
          return;
        } else {
          sound.playInvalid();
          return;
        }
      }

      // 2. Normal Tap to Place
      if (!selectedPieceId) return;
      const piece = pieces.find((p) => p.id === selectedPieceId && !p.used);
      if (!piece) return;

      if (canPlacePiece(board, piece, row, col)) {
        commitPlacement(piece, row, col);
      } else {
        sound.playInvalid();
      }
    },
    [hammerActive, board, selectedPieceId, pieces, settings.vibrationEnabled, commitPlacement, updateProfile]
  );

  // Power-Up: Toggle Hammer
  const handleToggleHammer = useCallback(() => {
    if (profile.powerups.hammer <= 0) {
      sound.playInvalid();
      // Prompt store
      setCurrentScreen('store');
      return;
    }
    sound.playClick();
    setHammerActive((prev) => !prev);
  }, [profile.powerups.hammer]);

  // Power-Up: Reroll tray pieces
  const handleRerollTray = useCallback(() => {
    if (profile.powerups.refresh <= 0) {
      sound.playInvalid();
      setCurrentScreen('store');
      return;
    }
    sound.playPowerup();
    triggerHaptic(settings.vibrationEnabled, 50);

    const newPieces = generateThreePieces(currentLevel);
    setPieces(newPieces);
    setSelectedPieceId(null);
    updateProfile((p) => ({
      ...p,
      powerups: {
        ...p.powerups,
        refresh: Math.max(0, p.powerups.refresh - 1),
      },
    }));
  }, [profile.powerups.refresh, settings.vibrationEnabled, updateProfile]);

  // Tray piece select
  const handlePieceSelect = useCallback((piece: GamePiece) => {
    if (piece.used) return;
    sound.playClick();
    setHammerActive(false);
    setSelectedPieceId((prev) => (prev === piece.id ? null : piece.id));
  }, []);

  // Tray piece rotate (90 degrees clockwise)
  const handleRotatePiece = useCallback(
    (pieceToRotate: GamePiece) => {
      if (pieceToRotate.used) return;
      sound.playRotate();
      triggerHaptic(settings.vibrationEnabled, 25);
      setHammerActive(false);

      setPieces((prevPieces) =>
        prevPieces.map((p) => {
          if (p.id !== pieceToRotate.id) return p;
          const rotated = rotatePiece90(p);
          const fits = canPieceFitAnywhere(board, rotated);
          return { ...rotated, canFit: fits };
        })
      );

      setSelectedPieceId(pieceToRotate.id);
    },
    [board, settings.vibrationEnabled]
  );

  // Store handlers
  const handlePurchaseItem = useCallback(
    (item: StoreItem): boolean => {
      if (profile.coins < item.price) return false;

      updateProfile((p) => {
        const costCoins = item.price;

        // Consumable powerup packs (+3 charges)
        if (item.type === 'powerup') {
          const isHammer = item.id === 'powerup_hammer';
          return {
            ...p,
            coins: p.coins - costCoins,
            powerups: {
              ...p.powerups,
              hammer: isHammer ? p.powerups.hammer + 3 : p.powerups.hammer,
              refresh: !isHammer ? p.powerups.refresh + 3 : p.powerups.refresh,
            },
          };
        }

        // Cosmetic skin
        return {
          ...p,
          coins: p.coins - costCoins,
          purchasedItems: [...p.purchasedItems, item.id],
        };
      });

      return true;
    },
    [profile.coins, updateProfile]
  );

  const handleEquipItem = useCallback(
    (item: StoreItem) => {
      updateProfile((p) => {
        if (item.type === 'blockSkin') {
          return { ...p, equippedBlockSkin: item.id };
        } else if (item.type === 'boardTheme') {
          return { ...p, equippedBoardTheme: item.id };
        } else if (item.type === 'bgTheme') {
          return { ...p, equippedBgTheme: item.id };
        }
        return p;
      });
    },
    [updateProfile]
  );

  // Daily Gift Claim
  const handleClaimDailyGift = useCallback(
    (gift: DailyGift) => {
      const todayStr = new Date().toISOString().split('T')[0];
      updateProfile((p) => ({
        ...p,
        coins: p.coins + gift.coins,
        dailyStreak: p.dailyStreak + 1,
        lastDailyClaimDate: todayStr,
      }));
    },
    [updateProfile]
  );

  // Achievement Claim
  const handleClaimAchievement = useCallback(
    (ach: Achievement) => {
      updateProfile((p) => ({
        ...p,
        coins: p.coins + ach.rewardCoins,
        claimedAchievements: [...p.claimedAchievements, ach.id],
      }));
    },
    [updateProfile]
  );

  // Milestone Mystery Chest Handlers
  const handleOpenMilestoneChest = useCallback(
    (milestoneLevel: number) => {
      if (profile.claimedMilestones?.includes(milestoneLevel)) {
        return;
      }
      const reward = generateMilestoneReward(milestoneLevel, profile.purchasedItems || []);
      setActiveMilestoneChest({ milestoneLevel, reward });
      sound.playClick();
    },
    [profile.claimedMilestones, profile.purchasedItems]
  );

  const handleClaimMilestoneReward = useCallback(
    (reward: MilestoneReward) => {
      if (!activeMilestoneChest) return;
      const milestoneLevel = activeMilestoneChest.milestoneLevel;

      updateProfile((prev) => {
        const claimed = prev.claimedMilestones || [];
        if (claimed.includes(milestoneLevel)) {
          return prev;
        }

        let nextCoins = prev.coins;
        const nextPurchased = [...(prev.purchasedItems || [])];

        if (reward.type === 'coins' && reward.amount) {
          nextCoins += reward.amount;
        } else if (reward.itemId) {
          if (!nextPurchased.includes(reward.itemId)) {
            nextPurchased.push(reward.itemId);
          }
          if (reward.bonusCoins) {
            nextCoins += reward.bonusCoins;
          }
        }

        return {
          ...prev,
          coins: nextCoins,
          purchasedItems: nextPurchased,
          claimedMilestones: [...claimed, milestoneLevel],
        };
      });

      sound.playCoin();
      sound.playLevelComplete();
      setActiveMilestoneChest(null);
    },
    [activeMilestoneChest, updateProfile]
  );

  // User notification toast
  const showToast = useCallback((msg: string) => {
    setToastMessage(msg);
    setTimeout(() => {
      setToastMessage((cur) => (cur === msg ? null : cur));
    }, 3200);
  }, []);

  // Interstitial Ad Level Transition:
  // After every 3 successfully completed levels, subject to frequency limits & 90s cooldown.
  // Never during active gameplay, never while placing/rotating pieces.
  const handleLevelTransition = useCallback(
    (action: () => void) => {
      if (admob.canShowInterstitial()) {
        admob.showInterstitial(
          () => {
            action();
          },
          () => {
            // If ad fails or offline, safely proceed with zero interruption
            action();
          }
        );
      } else {
        action();
      }
    },
    []
  );

  // Rewarded Video Ad Handlers:
  // Voluntary watching for 500 or 1,000 Coins, confirmed reward only.
  const handleWatchAd = useCallback(
    (amount: number, label: string) => {
      setIsWatchAdModalOpen(false);
      admob.showRewarded(
        { amount, type: 'coins', label },
        () => {
          updateProfile((prev) => ({
            ...prev,
            coins: prev.coins + amount,
          }));
          sound.playCoin();
          sound.playLevelComplete();
          showToast(`+${amount.toLocaleString()} Coins earned from ${label}!`);
        },
        () => {
          // Closed without error
        },
        (errMsg) => {
          showToast(errMsg || 'Advertisement temporarily unavailable.');
        }
      );
    },
    [updateProfile, showToast]
  );

  // Voluntary Victory Bonus Rewarded Ad
  const handleWatchLevelCompleteAdBonus = useCallback(() => {
    if (hasClaimedAdBonus) return;
    admob.showRewarded(
      { amount: 500, type: 'coins', label: 'Victory Bonus (+500 Coins)' },
      () => {
        setHasClaimedAdBonus(true);
        updateProfile((prev) => ({
          ...prev,
          coins: prev.coins + 500,
        }));
        sound.playCoin();
        sound.playLevelComplete();
        showToast('+500 Bonus Coins claimed!');
      },
      () => {},
      (errMsg) => {
        showToast(errMsg || 'Advertisement temporarily unavailable.');
      }
    );
  }, [hasClaimedAdBonus, updateProfile, showToast]);

  return (
    <div className="relative w-full h-[100dvh] max-h-[100dvh] bg-[#090412] text-white flex flex-col overflow-hidden selection:bg-pink-500 selection:text-white">
      {/* Dynamic Full-Screen Background Theme Renderer */}
      <BackgroundRenderer themeId={profile.equippedBgTheme} />

      {/* 60fps Particle Canvas */}
      <ParticleCanvas ref={particleCanvasRef} />

      {/* ======================= SCREEN ROUTER ======================= */}

      {/* 1. HOME SCREEN */}
      {currentScreen === 'home' && (
        <HomeScreen
          profile={profile}
          onPlayGame={() => startLevel(profile.level)}
          onOpenWatchAd={() => setIsWatchAdModalOpen(true)}
          onNavigate={(screen) => {
            sound.playClick();
            if (screen === 'settings') {
              setIsSettingsOpen(true);
            } else {
              setCurrentScreen(screen);
            }
          }}
        />
      )}

      {/* 2. LEVELS SELECTION SCREEN */}
      {currentScreen === 'levels' && (
        <LevelsScreen
          profile={profile}
          onSelectLevel={(lvl) => startLevel(lvl)}
          onOpenMilestoneChest={handleOpenMilestoneChest}
          onBack={() => {
            sound.playClick();
            setCurrentScreen('home');
          }}
        />
      )}

      {/* 3. STORE SCREEN */}
      {currentScreen === 'store' && (
        <StoreScreen
          profile={profile}
          onPurchaseItem={handlePurchaseItem}
          onEquipItem={handleEquipItem}
          onOpenWatchAd={() => setIsWatchAdModalOpen(true)}
          onBack={() => {
            sound.playClick();
            setCurrentScreen('home');
          }}
        />
      )}

      {/* 4. DAILY GIFTS SCREEN */}
      {currentScreen === 'daily' && (
        <DailyGiftsScreen
          profile={profile}
          onClaimReward={handleClaimDailyGift}
          onBack={() => {
            sound.playClick();
            setCurrentScreen('home');
          }}
        />
      )}

      {/* 5. PROFILE SCREEN */}
      {currentScreen === 'profile' && (
        <ProfileScreen
          profile={profile}
          onBack={() => {
            sound.playClick();
            setCurrentScreen('home');
          }}
        />
      )}

      {/* 6. ACHIEVEMENTS SCREEN */}
      {currentScreen === 'achievements' && (
        <AchievementsScreen
          profile={profile}
          onClaimAchievement={handleClaimAchievement}
          onBack={() => {
            sound.playClick();
            setCurrentScreen('home');
          }}
        />
      )}

      {/* 7. ACTIVE GAME SCREEN */}
      {currentScreen === 'game' && (
        <div className="w-full max-w-[430px] h-full mx-auto flex flex-col justify-between px-2 sm:px-3.5 pt-[max(6px,env(safe-area-inset-top))] pb-[max(8px,env(safe-area-inset-bottom))] z-10 overflow-hidden animate-fade-in">
          {/* Top Score & Level HUD */}
          <header className="w-full shrink-0">
            <ScoreHeader
              level={currentLevel}
              targetScore={currentTargetScore}
              score={score}
              highScore={profile.highScore}
              comboStreak={comboStreak}
              lastScoreInfo={lastScoreInfo}
              isMuted={!settings.soundEnabled}
              onToggleSound={() =>
                handleUpdateSettings({ soundEnabled: !settings.soundEnabled })
              }
              onRestart={handleRestartLevel}
              onOpenSettings={() => {
                sound.playClick();
                setIsSettingsOpen(true);
              }}
              onHome={() => {
                sound.playClick();
                setCurrentScreen('home');
              }}
            />
          </header>

          {/* 7x7 Game Board Section */}
          <main className="flex-1 flex flex-col justify-center items-center min-h-0 w-full my-auto py-0.5 sm:py-1">
            <GameBoard
              board={board}
              preview={preview}
              draggedPieceColor={draggedPiece?.color || null}
              boardRef={boardContainerRef}
              onCellClick={handleCellClick}
              hammerActive={hammerActive}
              boardTheme={profile.equippedBoardTheme}
              blockSkin={profile.equippedBlockSkin}
            />
          </main>

          {/* 3 Upcoming Pieces Tray with Powerup Actions */}
          <footer className="w-full shrink-0">
            <PieceTray
              pieces={pieces}
              selectedPieceId={selectedPieceId}
              draggedPieceId={draggedPiece?.id || null}
              onPieceSelect={handlePieceSelect}
              onRotatePiece={handleRotatePiece}
              onDragStart={handleDragStart}
              hammerCount={profile.powerups.hammer}
              refreshCount={profile.powerups.refresh}
              hammerActive={hammerActive}
              onToggleHammer={handleToggleHammer}
              onRerollTray={handleRerollTray}
              blockSkin={profile.equippedBlockSkin}
            />
          </footer>
        </div>
      )}

      {/* Floating Dragged Piece Overlay */}
      {draggedPiece && dragPos && (
        <div
          className="fixed pointer-events-none z-50 transform -translate-x-1/2 -translate-y-1/2 drop-shadow-[0_10px_25px_rgba(0,0,0,0.85)]"
          style={{
            left: `${dragPos.x}px`,
            top: `${dragPos.y}px`,
          }}
        >
          <div
            className="grid gap-0.5 sm:gap-1"
            style={{
              gridTemplateColumns: `repeat(${draggedPiece.shape.width}, minmax(0, 1fr))`,
              gridTemplateRows: `repeat(${draggedPiece.shape.height}, minmax(0, 1fr))`,
            }}
          >
            {draggedPiece.shape.matrix.map((row, r) =>
              row.map((val, c) => (
                <div key={`${r}-${c}`} className="w-[26px] h-[26px] sm:w-[30px] sm:h-[30px]">
                  {val === 1 && (
                    <ReactorBlock
                      color={draggedPiece.color}
                      theme={profile.equippedBlockSkin}
                      size="100%"
                      glow={true}
                    />
                  )}
                </div>
              ))
            )}
          </div>
        </div>
      )}

      {/* Animated Line-Clear Announcement Banner */}
      <LineClearAnnouncement announcement={lineAnnouncement} />

      {/* Premium Right-Corner Combo Notification */}
      <ComboNotification combo={comboNotification} />

      {/* Settings Modal */}
      <SettingsModal
        isOpen={isSettingsOpen}
        settings={settings}
        onUpdateSettings={handleUpdateSettings}
        onRestart={currentScreen === 'game' ? handleRestartLevel : undefined}
        onResetHighScore={handleResetHighScore}
        onClose={() => setIsSettingsOpen(false)}
      />

      {/* Level Completion Modal */}
      {isLevelCompleteModalOpen && (
        <LevelCompleteModal
          levelData={getLevelData(currentLevel)}
          score={score}
          rewardCoins={getLevelData(currentLevel).rewardCoins}
          isMilestone={isMilestoneLevel(currentLevel) && !profile.claimedMilestones?.includes(currentLevel)}
          onOpenMilestoneChest={() => handleOpenMilestoneChest(currentLevel)}
          onWatchBonusAd={handleWatchLevelCompleteAdBonus}
          hasClaimedAdBonus={hasClaimedAdBonus}
          onContinue={() => handleLevelTransition(() => startLevel(currentLevel + 1))}
          onReplay={() => handleLevelTransition(() => startLevel(currentLevel))}
          onHome={() =>
            handleLevelTransition(() => {
              setIsLevelCompleteModalOpen(false);
              setCurrentScreen('home');
            })
          }
        />
      )}

      {/* Milestone Mystery Chest Modal */}
      {activeMilestoneChest && (
        <MilestoneChestModal
          milestoneLevel={activeMilestoneChest.milestoneLevel}
          reward={activeMilestoneChest.reward}
          onClaim={handleClaimMilestoneReward}
          onClose={() => setActiveMilestoneChest(null)}
        />
      )}

      {/* Rewarded Video Ad Opportunities Modal */}
      <WatchAdModal
        isOpen={isWatchAdModalOpen}
        onClose={() => setIsWatchAdModalOpen(false)}
        onWatchAd={handleWatchAd}
      />

      {/* Google AdMob Android Test Player Overlay */}
      <AdMobTestPlayer />

      {/* Toast Notification */}
      {toastMessage && (
        <div className="fixed top-12 left-1/2 -translate-x-1/2 z-[120] px-4 py-2 rounded-2xl bg-slate-900/95 border border-amber-400/60 text-white font-mono font-bold text-xs shadow-2xl backdrop-blur-md animate-bounce-in flex items-center gap-2">
          <Sparkles className="w-4 h-4 text-amber-300" />
          <span>{toastMessage}</span>
        </div>
      )}

      {/* Game Over Modal */}
      {isGameOver && (
        <GameOverModal
          level={currentLevel}
          targetScore={currentTargetScore}
          stats={{
            score,
            highScore: profile.highScore,
            linesCleared,
            blocksPlaced,
            comboStreak,
            maxCombo,
          }}
          isNewRecord={isNewRecord}
          onRestart={handleRestartLevel}
          onHome={() => {
            setIsGameOver(false);
            setCurrentScreen('home');
          }}
          onLevels={() => {
            setIsGameOver(false);
            setCurrentScreen('levels');
          }}
        />
      )}
    </div>
  );
}
