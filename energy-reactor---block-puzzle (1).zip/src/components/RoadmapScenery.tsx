import React, { useMemo } from 'react';
import { BiomeInfo } from '../utils/levelData';

interface RoadmapSceneryProps {
  totalHeight: number;
  biome: BiomeInfo;
  activeBatch: number;
}

/**
 * Extreme 3D Cartoon Fantasy World Background Scenery
 * Inspired by Mario Wonder, Candy Crush & Pixar.
 * Renders rich, child-friendly environment layers spanning:
 * - Base (Levels 1-10): Candy Forest & Blossom Meadow
 * - Lower-Mid (Levels 11-20): Mushroom Village & Crystal Brook
 * - Mid (Levels 21-30): Rainbow Valley & Sweet Cascades
 * - Upper-Mid (Levels 31-40): Fruit Kingdom & Giant Treats
 * - Summit (Levels 41-50): Cloud Kingdom & Magical Fantasy Castle
 */
export const RoadmapScenery: React.FC<RoadmapSceneryProps> = ({
  totalHeight,
  biome,
  activeBatch,
}) => {
  // Generate deterministic decorative stars & sparkles for the sky
  const skyStars = useMemo(() => {
    const stars = [];
    const count = 35;
    for (let i = 0; i < count; i++) {
      const x = (i * 97 + 13) % 360 + 10;
      const y = (i * 131 + 45) % 1100 + 40;
      const size = (i % 3) + 2;
      const delay = (i * 0.23) % 3;
      stars.push({ id: i, x, y, size, delay });
    }
    return stars;
  }, []);

  return (
    <div
      className="absolute inset-0 pointer-events-none select-none overflow-hidden"
      style={{ width: '380px', height: `${totalHeight}px` }}
    >
      {/* =========================================================================
          BACKGROUND GRADIENT SKY CANVAS (Daylight Summit down to Lush Meadow Base)
          ========================================================================= */}
      <svg
        className="absolute inset-0 w-full h-full"
        width="380"
        height={totalHeight}
        viewBox={`0 0 380 ${totalHeight}`}
        preserveAspectRatio="none"
      >
        <defs>
          {/* Vertical World Atmosphere Gradient */}
          <linearGradient id="fantasySky" x1="0%" y1="0%" x2="0%" y2="100%">
            {/* Summit: Sunny Bright Sky & Gold */}
            <stop offset="0%" stopColor="#38bdf8" />
            <stop offset="6%" stopColor="#7dd3fc" />
            <stop offset="14%" stopColor="#bae6fd" />
            <stop offset="20%" stopColor="#fef08a" />
            {/* Upper-Mid: Pastel Sunset Peach & Coral */}
            <stop offset="28%" stopColor="#fbcfe8" />
            <stop offset="40%" stopColor="#f472b6" />
            {/* Mid: Rainbow & Violet Dream Valley */}
            <stop offset="52%" stopColor="#c084fc" />
            <stop offset="65%" stopColor="#818cf8" />
            {/* Lower-Mid: Mystical Cyan & Teal Forest */}
            <stop offset="78%" stopColor="#0d9488" />
            <stop offset="88%" stopColor="#059669" />
            {/* Base: Lush Emerald Candy Grass */}
            <stop offset="96%" stopColor="#10b981" />
            <stop offset="100%" stopColor="#047857" />
          </linearGradient>

          {/* Soft Hill Gradients */}
          <linearGradient id="hillGreen1" x1="0%" y1="0%" x2="0%" y2="100%">
            <stop offset="0%" stopColor="#34d399" />
            <stop offset="100%" stopColor="#059669" />
          </linearGradient>
          <linearGradient id="hillGreen2" x1="0%" y1="0%" x2="0%" y2="100%">
            <stop offset="0%" stopColor="#10b981" />
            <stop offset="100%" stopColor="#047857" />
          </linearGradient>
          <linearGradient id="hillCyan" x1="0%" y1="0%" x2="0%" y2="100%">
            <stop offset="0%" stopColor="#2dd4bf" />
            <stop offset="100%" stopColor="#0f766e" />
          </linearGradient>
          <linearGradient id="hillPurple" x1="0%" y1="0%" x2="0%" y2="100%">
            <stop offset="0%" stopColor="#c084fc" />
            <stop offset="100%" stopColor="#7e22ce" />
          </linearGradient>
          <linearGradient id="hillPink" x1="0%" y1="0%" x2="0%" y2="100%">
            <stop offset="0%" stopColor="#f472b6" />
            <stop offset="100%" stopColor="#be185d" />
          </linearGradient>
          <linearGradient id="hillGold" x1="0%" y1="0%" x2="0%" y2="100%">
            <stop offset="0%" stopColor="#fde047" />
            <stop offset="100%" stopColor="#d97706" />
          </linearGradient>

          {/* 3D Gloss Filter */}
          <filter id="softGlow" x="-20%" y="-20%" width="140%" height="140%">
            <feGaussianBlur stdDeviation="3" result="blur" />
            <feComposite in="SourceGraphic" in2="blur" operator="over" />
          </filter>

          {/* Rainbow Gradient */}
          <linearGradient id="rainbowGrad" x1="0%" y1="0%" x2="100%" y2="0%">
            <stop offset="0%" stopColor="#ff4d4d" />
            <stop offset="20%" stopColor="#ffa500" />
            <stop offset="40%" stopColor="#ffff00" />
            <stop offset="60%" stopColor="#00e676" />
            <stop offset="80%" stopColor="#00b0ff" />
            <stop offset="100%" stopColor="#d500f9" />
          </linearGradient>
        </defs>

        {/* 1. Base Sky Fill */}
        <rect x="0" y="0" width="380" height={totalHeight} fill="url(#fantasySky)" opacity="0.9" />

        {/* 2. Soft Ambient Vignette / Ray Beams from Top */}
        <path
          d={`M 190 0 L 0 ${totalHeight * 0.15} L 0 0 Z`}
          fill="#ffffff"
          opacity="0.12"
        />
        <path
          d={`M 190 0 L 380 ${totalHeight * 0.18} L 380 0 Z`}
          fill="#ffffff"
          opacity="0.1"
        />
        <path
          d={`M 190 0 L 120 ${totalHeight * 0.22} L 70 ${totalHeight * 0.22} Z`}
          fill="#ffffff"
          opacity="0.15"
        />
        <path
          d={`M 190 0 L 260 ${totalHeight * 0.2} L 310 ${totalHeight * 0.2} Z`}
          fill="#ffffff"
          opacity="0.12"
        />

        {/* =========================================================================
            BACKGROUND ROLLING CARTOON HILLS (Spanning from summit to base)
            ========================================================================= */}
        {/* Tier 5 / Summit Cloud Islands (Y: 200 - 900) */}
        <path
          d="M -20 720 Q 80 660 190 710 Q 300 760 400 700 L 400 900 L -20 900 Z"
          fill="url(#hillPink)"
          opacity="0.4"
        />
        <path
          d="M -20 860 Q 110 800 210 850 Q 310 900 400 830 L 400 1020 L -20 1020 Z"
          fill="url(#hillGold)"
          opacity="0.5"
        />

        {/* Tier 4 / Fruit Kingdom Hills (Y: 1000 - 1900) */}
        <path
          d="M -20 1200 Q 100 1130 220 1190 Q 340 1250 400 1180 L 400 1400 L -20 1400 Z"
          fill="url(#hillGold)"
          opacity="0.45"
        />
        <path
          d="M -20 1500 Q 90 1430 200 1480 Q 310 1530 400 1460 L 400 1700 L -20 1700 Z"
          fill="url(#hillPink)"
          opacity="0.5"
        />
        <path
          d="M -20 1800 Q 120 1720 240 1790 Q 350 1850 400 1780 L 400 2000 L -20 2000 Z"
          fill="url(#hillPurple)"
          opacity="0.45"
        />

        {/* Tier 3 / Rainbow Valley Hills (Y: 2000 - 2900) */}
        <path
          d="M -20 2200 Q 100 2120 210 2180 Q 320 2240 400 2160 L 400 2400 L -20 2400 Z"
          fill="url(#hillPurple)"
          opacity="0.55"
        />
        <path
          d="M -20 2550 Q 90 2470 200 2530 Q 310 2590 400 2510 L 400 2750 L -20 2750 Z"
          fill="url(#hillCyan)"
          opacity="0.5"
        />
        <path
          d="M -20 2850 Q 120 2770 230 2840 Q 340 2900 400 2820 L 400 3050 L -20 3050 Z"
          fill="url(#hillCyan)"
          opacity="0.6"
        />

        {/* Tier 2 / Mushroom Village Hills (Y: 3000 - 3900) */}
        <path
          d="M -20 3200 Q 90 3120 190 3170 Q 300 3230 400 3150 L 400 3400 L -20 3400 Z"
          fill="url(#hillCyan)"
          opacity="0.55"
        />
        <path
          d="M -20 3550 Q 110 3470 220 3530 Q 330 3590 400 3510 L 400 3750 L -20 3750 Z"
          fill="url(#hillGreen1)"
          opacity="0.65"
        />
        <path
          d="M -20 3880 Q 100 3800 200 3860 Q 310 3920 400 3840 L 400 4100 L -20 4100 Z"
          fill="url(#hillGreen1)"
          opacity="0.75"
        />

        {/* Tier 1 / Base Meadow Hills (Y: 4000 - totalHeight) */}
        <path
          d={`M -20 4250 Q 120 4170 230 4230 Q 340 4290 400 4210 L 400 ${totalHeight} L -20 ${totalHeight} Z`}
          fill="url(#hillGreen2)"
          opacity="0.8"
        />
        <path
          d={`M -20 4600 Q 90 4520 200 4580 Q 310 4640 400 4560 L 400 ${totalHeight} L -20 ${totalHeight} Z`}
          fill="url(#hillGreen2)"
          opacity="0.9"
        />

        {/* Twinkling Fantasy Sky Stars at Summit */}
        {skyStars.map((st) => (
          <polygon
            key={`sky-star-${st.id}`}
            points={`${st.x},${st.y - st.size} ${st.x + st.size * 0.4},${st.y - st.size * 0.3} ${st.x + st.size},${st.y} ${st.x + st.size * 0.4},${st.y + st.size * 0.3} ${st.x},${st.y + st.size} ${st.x - st.size * 0.4},${st.y + st.size * 0.3} ${st.x - st.size},${st.y} ${st.x - st.size * 0.4},${st.y - st.size * 0.3}`}
            fill="#ffffff"
            opacity="0.85"
            className="animate-star-twinkle"
            style={{ animationDelay: `${st.delay}s` }}
          />
        ))}
      </svg>

      {/* =========================================================================
          TIER 5: SUMMIT (Y: 0 to 950) - CLOUD KINGDOM & MAGICAL FANTASY CASTLE
          ========================================================================= */}
      {/* 1. Smiling Cartoon Sunshine with Rotating Rays (Top Right, Y: 40) */}
      <div className="absolute top-[40px] right-[20px] w-24 h-24 pointer-events-none">
        {/* Rotating Sun Rays */}
        <div className="absolute inset-0 flex items-center justify-center animate-sun-rays">
          <svg viewBox="0 0 100 100" className="w-full h-full text-amber-300/80 drop-shadow-[0_0_12px_rgba(251,191,36,0.8)]">
            {[0, 30, 60, 90, 120, 150, 180, 210, 240, 270, 300, 330].map((deg) => (
              <polygon
                key={deg}
                points="50,2 45,16 55,16"
                fill="currentColor"
                transform={`rotate(${deg} 50 50)`}
              />
            ))}
          </svg>
        </div>
        {/* Smiling Sun Face */}
        <div className="absolute inset-3 rounded-full bg-gradient-to-br from-yellow-200 via-amber-300 to-orange-400 border-2 border-white shadow-[0_0_24px_rgba(251,191,36,0.9)] flex items-center justify-center">
          <svg viewBox="0 0 60 60" className="w-12 h-12">
            {/* Cute Cartoon Eyes */}
            <ellipse cx="22" cy="24" rx="3.5" ry="5" fill="#1c1917" />
            <circle cx="23.5" cy="22" r="1.5" fill="#ffffff" />
            <ellipse cx="38" cy="24" rx="3.5" ry="5" fill="#1c1917" />
            <circle cx="39.5" cy="22" r="1.5" fill="#ffffff" />
            {/* Rosy Cheeks */}
            <circle cx="17" cy="30" r="4" fill="#fb7185" opacity="0.6" />
            <circle cx="43" cy="30" r="4" fill="#fb7185" opacity="0.6" />
            {/* Big Happy Smile */}
            <path
              d="M 23 32 Q 30 42 37 32"
              fill="none"
              stroke="#1c1917"
              strokeWidth="2.5"
              strokeLinecap="round"
            />
            {/* Sun Top Highlight */}
            <ellipse cx="28" cy="12" rx="10" ry="3" fill="#ffffff" opacity="0.5" />
          </svg>
        </div>
      </div>

      {/* 2. Magnificent 3D Cartoon Fantasy Castle (Y: 90 to 220, centered background behind summit road) */}
      <div className="absolute top-[85px] left-1/2 -translate-x-1/2 w-[340px] pointer-events-none drop-shadow-[0_12px_24px_rgba(0,0,0,0.45)]">
        <svg viewBox="0 0 340 180" className="w-full h-auto">
          <defs>
            <linearGradient id="castleWall" x1="0%" y1="0%" x2="0%" y2="100%">
              <stop offset="0%" stopColor="#ffffff" />
              <stop offset="40%" stopColor="#fdf2f8" />
              <stop offset="100%" stopColor="#e9d5ff" />
            </linearGradient>
            <linearGradient id="castleRoofPink" x1="0%" y1="0%" x2="0%" y2="100%">
              <stop offset="0%" stopColor="#fb7185" />
              <stop offset="100%" stopColor="#e11d48" />
            </linearGradient>
            <linearGradient id="castleRoofCyan" x1="0%" y1="0%" x2="0%" y2="100%">
              <stop offset="0%" stopColor="#38bdf8" />
              <stop offset="100%" stopColor="#0284c7" />
            </linearGradient>
            <linearGradient id="castleGold" x1="0%" y1="0%" x2="0%" y2="100%">
              <stop offset="0%" stopColor="#fef08a" />
              <stop offset="100%" stopColor="#f59e0b" />
            </linearGradient>
          </defs>

          {/* Floating Cloud Island Platform */}
          <path
            d="M 30 160 Q 40 135 70 140 Q 90 125 125 130 Q 160 115 200 125 Q 240 120 270 135 Q 300 135 310 160 Q 315 175 290 178 Q 230 185 170 180 Q 90 185 45 175 Z"
            fill="#ffffff"
            stroke="#c4b5fd"
            strokeWidth="3"
            filter="drop-shadow(0 6px 12px rgba(139,92,246,0.3))"
          />

          {/* Castle Main Central Keep */}
          <rect x="125" y="70" width="90" height="85" rx="8" fill="url(#castleWall)" stroke="#c4b5fd" strokeWidth="2.5" />
          {/* Central Keep Battlements */}
          <rect x="128" y="60" width="16" height="12" rx="2" fill="url(#castleWall)" stroke="#c4b5fd" strokeWidth="1.5" />
          <rect x="150" y="60" width="16" height="12" rx="2" fill="url(#castleWall)" stroke="#c4b5fd" strokeWidth="1.5" />
          <rect x="172" y="60" width="16" height="12" rx="2" fill="url(#castleWall)" stroke="#c4b5fd" strokeWidth="1.5" />
          <rect x="194" y="60" width="16" height="12" rx="2" fill="url(#castleWall)" stroke="#c4b5fd" strokeWidth="1.5" />

          {/* Central Grand Spire */}
          <polygon points="170,10 148,65 192,65" fill="url(#castleRoofPink)" stroke="#ffffff" strokeWidth="2" />
          {/* Golden Orb & Flag on Central Spire */}
          <circle cx="170" cy="10" r="4.5" fill="url(#castleGold)" stroke="#ffffff" strokeWidth="1" />
          <polygon points="170,10 186,6 170,2" fill="#facc15" />

          {/* Left Main Turret */}
          <rect x="75" y="85" width="45" height="70" rx="6" fill="url(#castleWall)" stroke="#c4b5fd" strokeWidth="2" />
          <polygon points="97,35 70,88 124,88" fill="url(#castleRoofCyan)" stroke="#ffffff" strokeWidth="2" />
          <circle cx="97" cy="35" r="3.5" fill="url(#castleGold)" />
          <polygon points="97,35 110,31 97,27" fill="#38bdf8" />

          {/* Right Main Turret */}
          <rect x="220" y="85" width="45" height="70" rx="6" fill="url(#castleWall)" stroke="#c4b5fd" strokeWidth="2" />
          <polygon points="242,35 215,88 269,88" fill="url(#castleRoofCyan)" stroke="#ffffff" strokeWidth="2" />
          <circle cx="242" cy="35" r="3.5" fill="url(#castleGold)" />
          <polygon points="242,35 255,31 242,27" fill="#f43f5e" />

          {/* Castle Windows with Warm Glow */}
          <rect x="158" y="82" width="24" height="34" rx="12" fill="#fef08a" stroke="#ca8a04" strokeWidth="2" />
          <line x1="170" y1="82" x2="170" y2="116" stroke="#ca8a04" strokeWidth="1.5" />
          <line x1="158" y1="98" x2="182" y2="98" stroke="#ca8a04" strokeWidth="1.5" />

          <rect x="88" y="105" width="18" height="24" rx="9" fill="#fef08a" stroke="#ca8a04" strokeWidth="1.5" />
          <rect x="233" y="105" width="18" height="24" rx="9" fill="#fef08a" stroke="#ca8a04" strokeWidth="1.5" />

          {/* Arched Castle Grand Gate */}
          <path d="M 155 155 L 155 130 Q 170 120 185 130 L 185 155 Z" fill="#4c1d95" stroke="#fbbf24" strokeWidth="2.5" />
          {/* Golden Gate Portcullis Grill */}
          <line x1="165" y1="126" x2="165" y2="155" stroke="#fbbf24" strokeWidth="1.5" />
          <line x1="175" y1="126" x2="175" y2="155" stroke="#fbbf24" strokeWidth="1.5" />
          <line x1="155" y1="140" x2="185" y2="140" stroke="#fbbf24" strokeWidth="1.5" />
        </svg>
      </div>

      {/* 3. Floating Smiling Clouds around Summit (Y: 230 to 450) */}
      <div className="absolute top-[230px] left-[15px] w-24 pointer-events-none animate-float">
        <svg viewBox="0 0 100 55" className="w-full h-auto drop-shadow-[0_6px_14px_rgba(255,255,255,0.4)]">
          <path
            d="M 20 45 Q 10 45 10 35 Q 10 25 20 22 Q 22 10 38 10 Q 52 10 58 20 Q 75 14 82 25 Q 92 26 92 37 Q 92 45 82 45 Z"
            fill="#ffffff"
          />
          {/* Smiling Eyes */}
          <path d="M 38 32 Q 42 27 46 32" fill="none" stroke="#64748b" strokeWidth="2" strokeLinecap="round" />
          <path d="M 54 32 Q 58 27 62 32" fill="none" stroke="#64748b" strokeWidth="2" strokeLinecap="round" />
          <circle cx="34" cy="35" r="3" fill="#fb7185" opacity="0.6" />
          <circle cx="66" cy="35" r="3" fill="#fb7185" opacity="0.6" />
          <path d="M 47 37 Q 50 41 53 37" fill="none" stroke="#64748b" strokeWidth="1.5" strokeLinecap="round" />
        </svg>
      </div>

      <div className="absolute top-[320px] right-[16px] w-28 pointer-events-none animate-float" style={{ animationDelay: '1.5s' }}>
        <svg viewBox="0 0 100 55" className="w-full h-auto drop-shadow-[0_6px_14px_rgba(255,255,255,0.4)]">
          <path
            d="M 20 45 Q 10 45 10 35 Q 10 25 20 22 Q 22 10 38 10 Q 52 10 58 20 Q 75 14 82 25 Q 92 26 92 37 Q 92 45 82 45 Z"
            fill="#ffffff"
          />
          <ellipse cx="40" cy="30" rx="3" ry="4" fill="#334155" />
          <circle cx="41.5" cy="28.5" r="1.2" fill="#ffffff" />
          <ellipse cx="60" cy="30" rx="3" ry="4" fill="#334155" />
          <circle cx="61.5" cy="28.5" r="1.2" fill="#ffffff" />
          <circle cx="33" cy="34" r="3.5" fill="#f43f5e" opacity="0.5" />
          <circle cx="67" cy="34" r="3.5" fill="#f43f5e" opacity="0.5" />
          <path d="M 46 34 Q 50 40 54 34" fill="none" stroke="#334155" strokeWidth="2" strokeLinecap="round" />
        </svg>
      </div>

      {/* Floating Rainbow Arch across Upper Sky (Y: 520 to 650) */}
      <div className="absolute top-[520px] left-1/2 -translate-x-1/2 w-[360px] pointer-events-none opacity-85 animate-rainbow">
        <svg viewBox="0 0 360 120" className="w-full h-auto">
          <path
            d="M 20 110 Q 180 0 340 110"
            fill="none"
            stroke="url(#rainbowGrad)"
            strokeWidth="16"
            strokeLinecap="round"
            opacity="0.8"
          />
          <path
            d="M 20 110 Q 180 0 340 110"
            fill="none"
            stroke="#ffffff"
            strokeWidth="3"
            strokeDasharray="10 14"
            opacity="0.7"
          />
        </svg>
      </div>

      {/* Floating Cloud Platforms with Gold Stars (Y: 690 to 880) */}
      <div className="absolute top-[690px] left-[18px] w-24 pointer-events-none">
        <svg viewBox="0 0 100 50" className="w-full h-auto drop-shadow-md">
          <path
            d="M 15 35 Q 5 35 5 25 Q 5 15 18 15 Q 25 5 45 5 Q 65 5 72 15 Q 90 12 92 25 Q 95 35 80 35 Z"
            fill="#ffffff"
          />
          {/* Golden star badge */}
          <polygon points="50,14 53,22 62,22 55,27 58,35 50,30 42,35 45,27 38,22 47,22" fill="#fbbf24" stroke="#ffffff" strokeWidth="1" />
        </svg>
      </div>

      <div className="absolute top-[820px] right-[20px] w-26 pointer-events-none">
        <svg viewBox="0 0 100 50" className="w-full h-auto drop-shadow-md">
          <path
            d="M 15 35 Q 5 35 5 25 Q 5 15 18 15 Q 25 5 45 5 Q 65 5 72 15 Q 90 12 92 25 Q 95 35 80 35 Z"
            fill="#ffffff"
          />
          <polygon points="50,14 53,22 62,22 55,27 58,35 50,30 42,35 45,27 38,22 47,22" fill="#f472b6" stroke="#ffffff" strokeWidth="1" />
        </svg>
      </div>

      {/* =========================================================================
          TIER 4: FRUIT KINGDOM & GIANT TREATS (Y: 950 to 1950)
          ========================================================================= */}
      {/* 1. Animated Citrus Windmill (Left flank, Y: 1040) */}
      <div className="absolute top-[1040px] left-[14px] w-24 pointer-events-none drop-shadow-[0_8px_18px_rgba(0,0,0,0.35)]">
        <svg viewBox="0 0 100 130" className="w-full h-auto">
          {/* Windmill Tower Body (Cute Strawberry/Lemon Cottage style) */}
          <polygon points="35,50 65,50 72,120 28,120" fill="#fef08a" stroke="#ca8a04" strokeWidth="2.5" />
          {/* Conical Orange Roof */}
          <polygon points="50,22 28,50 72,50" fill="#f97316" stroke="#ffffff" strokeWidth="2" />
          {/* Door & Window */}
          <rect x="42" y="94" width="16" height="26" rx="8" fill="#78350f" />
          <circle cx="50" cy="72" r="7" fill="#67e8f9" stroke="#0891b2" strokeWidth="1.5" />
          {/* Windmill Center Pin */}
          <circle cx="50" cy="50" r="5" fill="#f59e0b" stroke="#ffffff" strokeWidth="2" />
        </svg>

        {/* Rotating Citrus Slice Windmill Sails */}
        <div className="absolute top-[32px] left-[32px] w-[36px] h-[36px] animate-windmill">
          <svg viewBox="0 0 80 80" className="w-full h-full drop-shadow-md">
            {/* 4 Citrus Slice Blades */}
            {[0, 90, 180, 270].map((deg) => (
              <g key={deg} transform={`rotate(${deg} 40 40)`}>
                {/* Sail Arm */}
                <line x1="40" y1="40" x2="40" y2="8" stroke="#ca8a04" strokeWidth="3" strokeLinecap="round" />
                {/* Lemon slice blade */}
                <path d="M 40 8 A 20 20 0 0 1 54 28 L 40 28 Z" fill="#fde047" stroke="#ffffff" strokeWidth="1.5" />
                <path d="M 42 12 A 16 16 0 0 1 51 26 L 42 26 Z" fill="#eab308" />
              </g>
            ))}
            <circle cx="40" cy="40" r="6" fill="#f97316" stroke="#ffffff" strokeWidth="2" />
          </svg>
        </div>
      </div>

      {/* 2. Floating Hot-Air Fruit Balloon (Right flank, Y: 1180) */}
      <div className="absolute top-[1180px] right-[14px] w-20 pointer-events-none animate-float">
        <svg viewBox="0 0 80 110" className="w-full h-auto drop-shadow-[0_8px_18px_rgba(244,63,94,0.4)]">
          {/* Strawberry Shaped Balloon Envelope */}
          <path
            d="M 40 10 C 15 10 10 35 25 65 C 32 75 40 82 40 82 C 40 82 48 75 55 65 C 70 35 65 10 40 10 Z"
            fill="#f43f5e"
            stroke="#ffffff"
            strokeWidth="2.5"
          />
          {/* White Strawberry Seeds */}
          <circle cx="32" cy="30" r="2" fill="#fef08a" />
          <circle cx="48" cy="30" r="2" fill="#fef08a" />
          <circle cx="40" cy="45" r="2" fill="#fef08a" />
          <circle cx="30" cy="55" r="1.8" fill="#fef08a" />
          <circle cx="50" cy="55" r="1.8" fill="#fef08a" />
          {/* Leaf Crown on Top */}
          <polygon points="40,4 32,14 48,14" fill="#22c55e" stroke="#ffffff" strokeWidth="1.5" />
          {/* Balloon Ropes */}
          <line x1="28" y1="80" x2="34" y2="94" stroke="#78350f" strokeWidth="1.5" />
          <line x1="52" y1="80" x2="46" y2="94" stroke="#78350f" strokeWidth="1.5" />
          {/* Cute Wicker Basket */}
          <rect x="33" y="94" width="14" height="12" rx="3" fill="#b45309" stroke="#ffffff" strokeWidth="1.5" />
        </svg>
      </div>

      {/* 3. Giant 3D Cartoon Strawberries & Peppermint Candy Canes (Y: 1400 - 1550) */}
      <div className="absolute top-[1420px] left-[16px] w-22 pointer-events-none">
        <svg viewBox="0 0 90 90" className="w-full h-auto drop-shadow-lg">
          {/* Striped Candy Cane Stuck in Ground */}
          <path
            d="M 68 85 L 68 35 Q 68 15 50 15 Q 32 15 32 30"
            fill="none"
            stroke="#ffffff"
            strokeWidth="10"
            strokeLinecap="round"
          />
          <path
            d="M 68 85 L 68 35 Q 68 15 50 15 Q 32 15 32 30"
            fill="none"
            stroke="#ef4444"
            strokeWidth="10"
            strokeDasharray="6 8"
            strokeLinecap="round"
          />
          {/* Giant Glossy Strawberry */}
          <path
            d="M 30 45 C 10 45 6 65 18 80 C 24 88 30 92 30 92 C 30 92 36 88 42 80 C 54 65 50 45 30 45 Z"
            fill="#e11d48"
            stroke="#ffffff"
            strokeWidth="2"
          />
          {/* Strawberry Highlights */}
          <ellipse cx="22" cy="54" rx="4" ry="2" fill="#ffffff" opacity="0.6" transform="rotate(-20 22 54)" />
          {/* Green Leaves */}
          <polygon points="30,42 22,48 30,46 38,48" fill="#10b981" stroke="#ffffff" strokeWidth="1" />
        </svg>
      </div>

      {/* Giant Cartoon Orange Slice with Juicy Pulp (Right flank, Y: 1680) */}
      <div className="absolute top-[1680px] right-[14px] w-24 pointer-events-none drop-shadow-[0_6px_18px_rgba(249,115,22,0.45)]">
        <svg viewBox="0 0 100 100" className="w-full h-auto">
          {/* Orange Rind Outer Circle */}
          <circle cx="50" cy="50" r="44" fill="#f97316" stroke="#ffffff" strokeWidth="3" />
          {/* White Pith Ring */}
          <circle cx="50" cy="50" r="38" fill="#ffffff" />
          {/* Orange Segments */}
          <circle cx="50" cy="50" r="35" fill="#ea580c" />
          {[0, 45, 90, 135, 180, 225, 270, 315].map((deg) => (
            <g key={deg} transform={`rotate(${deg} 50 50)`}>
              <line x1="50" y1="50" x2="50" y2="15" stroke="#ffffff" strokeWidth="2.5" />
              <path d="M 48 20 Q 50 16 52 20 L 51 45 L 49 45 Z" fill="#fbbf24" />
            </g>
          ))}
          {/* Center Hub */}
          <circle cx="50" cy="50" r="6" fill="#ffffff" />
          <circle cx="50" cy="50" r="3" fill="#fed7aa" />
        </svg>
      </div>

      {/* Striped Candy Cane (Left, Y: 1880) */}
      <div className="absolute top-[1880px] left-[15px] w-18 pointer-events-none">
        <svg viewBox="0 0 70 80" className="w-full h-auto drop-shadow-md">
          <path
            d="M 22 75 L 22 30 Q 22 12 38 12 Q 54 12 54 26"
            fill="none"
            stroke="#ffffff"
            strokeWidth="9"
            strokeLinecap="round"
          />
          <path
            d="M 22 75 L 22 30 Q 22 12 38 12 Q 54 12 54 26"
            fill="none"
            stroke="#10b981"
            strokeWidth="9"
            strokeDasharray="5 7"
            strokeLinecap="round"
          />
        </svg>
      </div>

      {/* =========================================================================
          TIER 3: RAINBOW VALLEY & SWEET CASCADES (Y: 1950 to 2950)
          ========================================================================= */}
      {/* 1. Cartoon Candy Waterfall (Right flank, Y: 2080 to 2260) */}
      <div className="absolute top-[2080px] right-[10px] w-28 pointer-events-none">
        <svg viewBox="0 0 110 180" className="w-full h-auto drop-shadow-[0_8px_20px_rgba(6,182,212,0.5)]">
          {/* Candy Cliff Rock Formation */}
          <path
            d="M 40 10 Q 80 15 105 40 L 105 170 L 10 170 Q 25 100 40 10 Z"
            fill="#a855f7"
            stroke="#ffffff"
            strokeWidth="2"
          />
          <path
            d="M 50 18 Q 80 22 98 42 L 98 160 L 25 160 Z"
            fill="#7e22ce"
          />

          {/* Cascading Soda Waterfall */}
          <g className="animate-water-shimmer">
            <path
              d="M 55 20 Q 50 80 45 155 L 75 155 Q 70 80 75 20 Z"
              fill="#22d3ee"
              opacity="0.9"
            />
            {/* White Sparkling Water Streaks */}
            <line x1="58" y1="25" x2="52" y2="150" stroke="#ffffff" strokeWidth="2.5" strokeDasharray="14 10" />
            <line x1="68" y1="28" x2="66" y2="148" stroke="#ffffff" strokeWidth="2" strokeDasharray="10 8" />
          </g>

          {/* Frothy Splash Bubble Pool at Base */}
          <ellipse cx="60" cy="158" rx="35" ry="12" fill="#38bdf8" stroke="#ffffff" strokeWidth="2" />
          <circle cx="45" cy="154" r="5" fill="#ffffff" opacity="0.8" />
          <circle cx="62" cy="152" r="6" fill="#ffffff" opacity="0.9" />
          <circle cx="78" cy="155" r="4.5" fill="#ffffff" opacity="0.8" />
        </svg>
      </div>

      {/* 2. Vibrant Cartoon Rainbow Bridge (Spanning Left to Right across Valley, Y: 2360) */}
      <div className="absolute top-[2360px] left-1/2 -translate-x-1/2 w-[370px] pointer-events-none drop-shadow-[0_10px_24px_rgba(236,72,153,0.5)] animate-rainbow">
        <svg viewBox="0 0 370 110" className="w-full h-auto">
          {/* Main Rainbow Arch */}
          <path
            d="M 15 100 Q 185 10 355 100"
            fill="none"
            stroke="url(#rainbowGrad)"
            strokeWidth="18"
            strokeLinecap="round"
          />
          {/* Bridge Railing / Wafer Balustrade */}
          <path
            d="M 22 96 Q 185 18 348 96"
            fill="none"
            stroke="#ffffff"
            strokeWidth="3.5"
            strokeDasharray="6 8"
          />
          {/* Cloud Anchors at both ends */}
          <ellipse cx="25" cy="98" rx="20" ry="12" fill="#ffffff" stroke="#f472b6" strokeWidth="2" />
          <ellipse cx="345" cy="98" rx="20" ry="12" fill="#ffffff" stroke="#f472b6" strokeWidth="2" />
        </svg>
      </div>

      {/* 3. Glowing Rock Crystals & Singing Cartoon Bird (Left flank, Y: 2580) */}
      <div className="absolute top-[2580px] left-[14px] w-24 pointer-events-none">
        <svg viewBox="0 0 90 90" className="w-full h-auto drop-shadow-[0_6px_16px_rgba(168,85,247,0.5)]">
          {/* Faceted Crystal Gem Clustered Rocks */}
          <polygon points="35,80 15,50 30,25 50,45" fill="#ec4899" stroke="#ffffff" strokeWidth="2" />
          <polygon points="35,80 50,45 65,58 55,82" fill="#a855f7" stroke="#ffffff" strokeWidth="2" />
          <polygon points="55,82 65,58 85,68 75,85" fill="#38bdf8" stroke="#ffffff" strokeWidth="1.5" />
          {/* Crystal Gleam Highlights */}
          <polygon points="28,35 22,48 32,44" fill="#ffffff" opacity="0.75" />

          {/* Cute Little Cartoon Bird Perched on Crystal */}
          <g transform="translate(42, 16)">
            {/* Round Body */}
            <circle cx="16" cy="14" r="10" fill="#facc15" stroke="#1c1917" strokeWidth="1.5" />
            {/* Eye */}
            <circle cx="20" cy="12" r="2.5" fill="#1c1917" />
            <circle cx="21" cy="11" r="0.8" fill="#ffffff" />
            {/* Cute Beak */}
            <polygon points="25,13 32,15 25,17" fill="#f97316" stroke="#1c1917" strokeWidth="1" />
            {/* Wing */}
            <ellipse cx="12" cy="16" rx="5" ry="3.5" fill="#fb923c" transform="rotate(-15 12 16)" />
            {/* Musical Note Floating */}
            <text x="24" y="6" fontSize="12" fill="#ffffff" fontWeight="bold">♪</text>
          </g>
        </svg>
      </div>

      {/* Giant Candy Heart Lollipop (Right flank, Y: 2780) */}
      <div className="absolute top-[2780px] right-[14px] w-20 pointer-events-none animate-flower-bob">
        <svg viewBox="0 0 80 100" className="w-full h-auto drop-shadow-md">
          {/* Stick */}
          <line x1="40" y1="45" x2="40" y2="95" stroke="#ffffff" strokeWidth="4" strokeLinecap="round" />
          {/* Heart Swirl Candy */}
          <path
            d="M 40 22 C 40 10 20 8 16 26 C 12 40 40 56 40 56 C 40 56 68 40 64 26 C 60 8 40 10 40 22 Z"
            fill="#ec4899"
            stroke="#ffffff"
            strokeWidth="2.5"
          />
          <path
            d="M 40 26 C 40 16 26 15 23 28 C 20 38 40 50 40 50 C 40 50 60 38 57 28 C 54 15 40 16 40 26 Z"
            fill="#f472b6"
          />
          <ellipse cx="28" cy="24" rx="4" ry="2" fill="#ffffff" opacity="0.7" transform="rotate(-20 28 24)" />
        </svg>
      </div>

      {/* =========================================================================
          TIER 2: MUSHROOM VILLAGE & CRYSTAL BROOK (Y: 2950 to 3950)
          ========================================================================= */}
      {/* 1. Giant Red Magical Polka-Dot Mushroom Cottage (Left flank, Y: 3080) */}
      <div className="absolute top-[3080px] left-[12px] w-28 pointer-events-none drop-shadow-[0_8px_20px_rgba(239,68,68,0.5)]">
        <svg viewBox="0 0 110 130" className="w-full h-auto">
          {/* Cute Curved Chimney with Smoke Puff */}
          <rect x="68" y="16" width="10" height="22" rx="2" fill="#78350f" stroke="#ffffff" strokeWidth="1" />
          <ellipse cx="73" cy="12" rx="4" ry="2" fill="#e2e8f0" opacity="0.8" />
          <ellipse cx="76" cy="6" rx="6" ry="3.5" fill="#f1f5f9" opacity="0.6" />

          {/* Mushroom Cottage Stem/Base */}
          <ellipse cx="55" cy="100" rx="24" ry="22" fill="#fef08a" stroke="#ca8a04" strokeWidth="2.5" />
          {/* Arched Wooden Door with Round Knob */}
          <path d="M 46 118 L 46 95 Q 55 88 64 95 L 64 118 Z" fill="#92400e" stroke="#ffffff" strokeWidth="1.5" />
          <circle cx="60" cy="108" r="1.8" fill="#facc15" />
          {/* Round Glowing Window */}
          <circle cx="55" cy="80" r="7" fill="#67e8f9" stroke="#0891b2" strokeWidth="1.5" />
          <line x1="55" y1="73" x2="55" y2="87" stroke="#0891b2" strokeWidth="1.2" />
          <line x1="48" y1="80" x2="62" y2="80" stroke="#0891b2" strokeWidth="1.2" />

          {/* Giant Glossy Red Mushroom Cap */}
          <path
            d="M 12 60 Q 55 10 98 60 Q 55 68 12 60 Z"
            fill="#ef4444"
            stroke="#ffffff"
            strokeWidth="3"
          />
          {/* White Glowing Polka Dots */}
          <circle cx="34" cy="42" r="7" fill="#ffffff" />
          <circle cx="55" cy="30" r="8" fill="#ffffff" />
          <circle cx="76" cy="44" r="6.5" fill="#ffffff" />
          <circle cx="55" cy="52" r="5" fill="#ffffff" />
          <circle cx="20" cy="54" r="3.5" fill="#ffffff" />
          <circle cx="90" cy="54" r="3.5" fill="#ffffff" />
          {/* Gloss Sheen on Cap */}
          <ellipse cx="44" cy="24" rx="14" ry="4" fill="#ffffff" opacity="0.45" transform="rotate(-15 44 24)" />
        </svg>
      </div>

      {/* 2. Meandering Crystal Creek with Animated Water Lilies (Right flank, Y: 3340 to 3520) */}
      <div className="absolute top-[3340px] right-[10px] w-28 pointer-events-none">
        <svg viewBox="0 0 110 160" className="w-full h-auto drop-shadow-md">
          {/* Meandering Creek Bed */}
          <path
            d="M 85 10 Q 50 60 70 100 Q 90 140 60 160 L 95 160 Q 115 130 95 80 Q 80 40 105 10 Z"
            fill="#06b6d4"
            opacity="0.8"
          />
          <path
            d="M 88 15 Q 55 65 74 105 Q 92 142 68 155"
            fill="none"
            stroke="#ffffff"
            strokeWidth="2.5"
            strokeDasharray="8 8"
            className="animate-water-shimmer"
          />
          {/* Water Lily Pad & Pink Flower */}
          <ellipse cx="64" cy="90" rx="14" ry="7" fill="#10b981" stroke="#ffffff" strokeWidth="1.5" />
          <polygon points="64,80 61,86 67,86" fill="#f43f5e" stroke="#ffffff" strokeWidth="1" />
          <circle cx="64" cy="85" r="2" fill="#fef08a" />
        </svg>
      </div>

      {/* 3. Friendly Cartoon Snail with Swirly Lollipop Shell (Left flank, Y: 3580) */}
      <div className="absolute top-[3580px] left-[14px] w-20 pointer-events-none drop-shadow-md">
        <svg viewBox="0 0 80 60" className="w-full h-auto">
          {/* Snail Foot/Body */}
          <path
            d="M 12 50 Q 20 45 40 46 Q 65 46 72 50 Q 75 52 70 54 Q 40 55 12 54 Q 8 52 12 50 Z"
            fill="#a7f3d0"
            stroke="#059669"
            strokeWidth="1.5"
          />
          {/* Snail Head & Eye Stalks */}
          <ellipse cx="68" cy="44" rx="6" ry="7" fill="#a7f3d0" stroke="#059669" strokeWidth="1.5" />
          <line x1="66" y1="38" x2="63" y2="28" stroke="#059669" strokeWidth="1.5" />
          <circle cx="63" cy="27" r="2.5" fill="#ffffff" stroke="#1c1917" strokeWidth="1" />
          <circle cx="63.5" cy="26.5" r="1" fill="#1c1917" />
          <line x1="71" y1="38" x2="74" y2="28" stroke="#059669" strokeWidth="1.5" />
          <circle cx="74" cy="27" r="2.5" fill="#ffffff" stroke="#1c1917" strokeWidth="1" />
          <circle cx="74.5" cy="26.5" r="1" fill="#1c1917" />
          {/* Cute Smile */}
          <path d="M 68 47 Q 71 50 73 47" fill="none" stroke="#059669" strokeWidth="1.2" />

          {/* Swirly Rainbow Lollipop Shell */}
          <circle cx="42" cy="34" r="18" fill="#f472b6" stroke="#ffffff" strokeWidth="2.5" />
          <circle cx="42" cy="34" r="13" fill="#facc15" />
          <circle cx="42" cy="34" r="8" fill="#38bdf8" />
          <circle cx="42" cy="34" r="4" fill="#a855f7" />
        </svg>
      </div>

      {/* 4. Purple Glowing Magical Mushroom (Right flank, Y: 3780) */}
      <div className="absolute top-[3780px] right-[14px] w-22 pointer-events-none drop-shadow-[0_6px_16px_rgba(168,85,247,0.5)]">
        <svg viewBox="0 0 90 90" className="w-full h-auto">
          {/* Stem */}
          <path d="M 38 85 L 42 45 L 48 45 L 52 85 Z" fill="#fef08a" stroke="#ca8a04" strokeWidth="2" />
          {/* Purple Cap */}
          <path
            d="M 15 50 Q 45 12 75 50 Q 45 56 15 50 Z"
            fill="#a855f7"
            stroke="#ffffff"
            strokeWidth="2.5"
          />
          {/* Glowing spots */}
          <circle cx="35" cy="34" r="5" fill="#fbcfe8" />
          <circle cx="55" cy="32" r="6" fill="#fbcfe8" />
          <circle cx="45" cy="42" r="4" fill="#ffffff" />
          {/* Cute Little Cartoon Ladybug on Mushroom Cap */}
          <g transform="translate(56, 20)">
            <ellipse cx="6" cy="6" rx="5" ry="4" fill="#ef4444" stroke="#1c1917" strokeWidth="1" />
            <circle cx="3" cy="5" r="1" fill="#1c1917" />
            <circle cx="7" cy="4" r="1" fill="#1c1917" />
            <circle cx="6" cy="7" r="1" fill="#1c1917" />
            <circle cx="10" cy="5" r="2" fill="#1c1917" />
          </g>
        </svg>
      </div>

      {/* =========================================================================
          TIER 1: BASE (Y: 3950 to totalHeight) - CANDY FOREST & BLOSSOM MEADOW
          ========================================================================= */}
      {/* 1. Cute Strawberry Gingerbread Cottage (Left flank, Y: 4080) */}
      <div className="absolute top-[4080px] left-[10px] w-28 pointer-events-none drop-shadow-[0_8px_20px_rgba(0,0,0,0.4)]">
        <svg viewBox="0 0 110 120" className="w-full h-auto">
          {/* Chimney with Heart Smoke */}
          <rect x="75" y="16" width="12" height="24" rx="2" fill="#b91c1c" stroke="#ffffff" strokeWidth="1.5" />
          <path
            d="M 81 12 C 81 8 76 7 74 11 C 72 15 81 19 81 19 C 81 19 90 15 88 11 C 86 7 81 8 81 12 Z"
            fill="#f472b6"
            opacity="0.8"
          />

          {/* Gingerbread Walls */}
          <rect x="22" y="55" width="66" height="55" rx="6" fill="#b45309" stroke="#ffffff" strokeWidth="2.5" />
          {/* Frosted Strawberry Roof with Scalloped Icing */}
          <polygon points="55,18 10,58 100,58" fill="#f43f5e" stroke="#ffffff" strokeWidth="3" />
          {/* Scalloped White Icing along Roof Edge */}
          <path
            d="M 10 58 Q 20 66 30 58 Q 40 66 50 58 Q 60 66 70 58 Q 80 66 90 58 Q 95 64 100 58"
            fill="none"
            stroke="#ffffff"
            strokeWidth="3.5"
            strokeLinecap="round"
          />

          {/* Arched Cookie Door */}
          <path d="M 44 110 L 44 82 Q 55 74 66 82 L 66 110 Z" fill="#78350f" stroke="#fef08a" strokeWidth="2" />
          <circle cx="61" cy="96" r="2.5" fill="#facc15" />
          {/* Heart Window on Gable */}
          <circle cx="55" cy="42" r="7" fill="#fef08a" stroke="#ffffff" strokeWidth="1.5" />
        </svg>
      </div>

      {/* 2. Fluttering Cartoon Butterflies (Meadow air, Y: 4220 & 4460) */}
      <div className="absolute top-[4220px] right-[24px] w-12 pointer-events-none animate-flutter">
        <svg viewBox="0 0 50 40" className="w-full h-auto drop-shadow-md">
          {/* Wings */}
          <ellipse cx="16" cy="14" rx="12" ry="9" fill="#f43f5e" stroke="#ffffff" strokeWidth="1.5" />
          <ellipse cx="18" cy="26" rx="9" ry="7" fill="#fb923c" stroke="#ffffff" strokeWidth="1.5" />
          <ellipse cx="34" cy="14" rx="12" ry="9" fill="#f43f5e" stroke="#ffffff" strokeWidth="1.5" />
          <ellipse cx="32" cy="26" rx="9" ry="7" fill="#fb923c" stroke="#ffffff" strokeWidth="1.5" />
          {/* Butterfly Body */}
          <rect x="23" y="10" width="4" height="20" rx="2" fill="#1e1b4b" />
          <line x1="24" y1="10" x2="20" y2="4" stroke="#1e1b4b" strokeWidth="1.2" />
          <line x1="26" y1="10" x2="30" y2="4" stroke="#1e1b4b" strokeWidth="1.2" />
        </svg>
      </div>

      <div className="absolute top-[4460px] left-[26px] w-12 pointer-events-none animate-flutter" style={{ animationDelay: '0.18s' }}>
        <svg viewBox="0 0 50 40" className="w-full h-auto drop-shadow-md">
          <ellipse cx="16" cy="14" rx="12" ry="9" fill="#38bdf8" stroke="#ffffff" strokeWidth="1.5" />
          <ellipse cx="18" cy="26" rx="9" ry="7" fill="#a855f7" stroke="#ffffff" strokeWidth="1.5" />
          <ellipse cx="34" cy="14" rx="12" ry="9" fill="#38bdf8" stroke="#ffffff" strokeWidth="1.5" />
          <ellipse cx="32" cy="26" rx="9" ry="7" fill="#a855f7" stroke="#ffffff" strokeWidth="1.5" />
          <rect x="23" y="10" width="4" height="20" rx="2" fill="#1e1b4b" />
        </svg>
      </div>

      {/* 3. Lollipop Swirl Tree (Right flank, Y: 4320) */}
      <div className="absolute top-[4320px] right-[14px] w-24 pointer-events-none animate-flower-bob">
        <svg viewBox="0 0 90 120" className="w-full h-auto drop-shadow-lg">
          {/* Candy Trunk */}
          <rect x="40" y="55" width="10" height="60" rx="4" fill="#ffffff" stroke="#e2e8f0" strokeWidth="2" />
          {/* Swirl Spiral Candy Crown */}
          <circle cx="45" cy="45" r="36" fill="#f43f5e" stroke="#ffffff" strokeWidth="3" />
          {/* Swirl Spiral Lines */}
          <path
            d="M 45 45 M 45 15 A 30 30 0 0 1 75 45 A 25 25 0 0 1 50 70 A 20 20 0 0 1 30 50 A 15 15 0 0 1 45 35 A 10 10 0 0 1 55 45"
            fill="none"
            stroke="#ffffff"
            strokeWidth="5"
            strokeLinecap="round"
          />
          {/* 3D Bubble Shine */}
          <ellipse cx="32" cy="26" rx="8" ry="4" fill="#ffffff" opacity="0.6" transform="rotate(-30 32 26)" />
        </svg>
      </div>

      {/* 4. Cute Peeking Cartoon Bunny behind Meadow Hill (Left flank, Y: 4580) */}
      <div className="absolute top-[4580px] left-[16px] w-20 pointer-events-none drop-shadow-md">
        <svg viewBox="0 0 80 80" className="w-full h-auto">
          {/* Bunny Long Ears */}
          <ellipse cx="30" cy="24" rx="7" ry="20" fill="#ffffff" stroke="#e2e8f0" strokeWidth="2" />
          <ellipse cx="30" cy="24" rx="4" ry="15" fill="#fbcfe8" />
          <ellipse cx="50" cy="24" rx="7" ry="20" fill="#ffffff" stroke="#e2e8f0" strokeWidth="2" />
          <ellipse cx="50" cy="24" rx="4" ry="15" fill="#fbcfe8" />

          {/* Fluffy Bunny Head */}
          <circle cx="40" cy="50" r="22" fill="#ffffff" stroke="#e2e8f0" strokeWidth="2" />
          {/* Big Cartoon Eyes */}
          <ellipse cx="32" cy="48" rx="3.5" ry="5" fill="#1c1917" />
          <circle cx="33.5" cy="46" r="1.5" fill="#ffffff" />
          <ellipse cx="48" cy="48" rx="3.5" ry="5" fill="#1c1917" />
          <circle cx="49.5" cy="46" r="1.5" fill="#ffffff" />
          {/* Cute Pink Heart Nose */}
          <polygon points="40,54 37,51 43,51" fill="#f43f5e" />
          {/* Twitchy Whiskers */}
          <line x1="26" y1="53" x2="16" y2="51" stroke="#cbd5e1" strokeWidth="1.5" />
          <line x1="26" y1="56" x2="16" y2="58" stroke="#cbd5e1" strokeWidth="1.5" />
          <line x1="54" y1="53" x2="64" y2="51" stroke="#cbd5e1" strokeWidth="1.5" />
          <line x1="54" y1="56" x2="64" y2="58" stroke="#cbd5e1" strokeWidth="1.5" />
          {/* Rosy Cheeks */}
          <circle cx="27" cy="54" r="3.5" fill="#f472b6" opacity="0.6" />
          <circle cx="53" cy="54" r="3.5" fill="#f472b6" opacity="0.6" />
          {/* Front Paws Peeking over Hill */}
          <ellipse cx="28" cy="70" rx="6" ry="4" fill="#ffffff" stroke="#cbd5e1" strokeWidth="1.5" />
          <ellipse cx="52" cy="70" rx="6" ry="4" fill="#ffffff" stroke="#cbd5e1" strokeWidth="1.5" />
        </svg>
      </div>

      {/* 5. Smiling Giant Daisy & Tulip Flowers (Right flank, Y: 4760) */}
      <div className="absolute top-[4760px] right-[14px] w-24 pointer-events-none animate-flower-bob">
        <svg viewBox="0 0 90 90" className="w-full h-auto drop-shadow-md">
          {/* Stem & Leaves */}
          <line x1="45" y1="50" x2="45" y2="88" stroke="#10b981" strokeWidth="3.5" strokeLinecap="round" />
          <ellipse cx="32" cy="70" rx="8" ry="4" fill="#10b981" transform="rotate(-30 32 70)" />
          <ellipse cx="58" cy="65" rx="8" ry="4" fill="#10b981" transform="rotate(30 58 65)" />

          {/* 8 Daisy White Petals */}
          {[0, 45, 90, 135, 180, 225, 270, 315].map((deg) => (
            <ellipse
              key={deg}
              cx="45"
              cy="25"
              rx="6"
              ry="14"
              fill="#ffffff"
              stroke="#e2e8f0"
              strokeWidth="1.5"
              transform={`rotate(${deg} 45 45)`}
            />
          ))}

          {/* Smiling Yellow Flower Center */}
          <circle cx="45" cy="45" r="14" fill="#facc15" stroke="#f59e0b" strokeWidth="2" />
          <circle cx="40" cy="42" r="2" fill="#1c1917" />
          <circle cx="50" cy="42" r="2" fill="#1c1917" />
          <circle cx="37" cy="46" r="2" fill="#f43f5e" opacity="0.6" />
          <circle cx="53" cy="46" r="2" fill="#f43f5e" opacity="0.6" />
          <path d="M 41 46 Q 45 50 49 46" fill="none" stroke="#1c1917" strokeWidth="1.5" strokeLinecap="round" />
        </svg>
      </div>

      {/* 6. Base Welcome Arch & Flower Garden (Base of Batch, Y: totalHeight - 120) */}
      <div
        className="absolute left-1/2 -translate-x-1/2 w-[360px] pointer-events-none"
        style={{ top: `${totalHeight - 110}px` }}
      >
        <svg viewBox="0 0 360 80" className="w-full h-auto drop-shadow-md">
          {/* Flower Garden Meadow Strip */}
          <ellipse cx="40" cy="50" rx="28" ry="14" fill="#10b981" />
          <ellipse cx="100" cy="55" rx="35" ry="14" fill="#059669" />
          <ellipse cx="260" cy="55" rx="35" ry="14" fill="#059669" />
          <ellipse cx="320" cy="50" rx="28" ry="14" fill="#10b981" />

          {/* Little colorful flowers popping up */}
          <circle cx="35" cy="42" r="5" fill="#f43f5e" stroke="#ffffff" strokeWidth="1" />
          <circle cx="50" cy="45" r="4" fill="#facc15" stroke="#ffffff" strokeWidth="1" />
          <circle cx="95" cy="48" r="4.5" fill="#38bdf8" stroke="#ffffff" strokeWidth="1" />
          <circle cx="265" cy="48" r="4.5" fill="#f43f5e" stroke="#ffffff" strokeWidth="1" />
          <circle cx="310" cy="44" r="4" fill="#a855f7" stroke="#ffffff" strokeWidth="1" />
          <circle cx="325" cy="42" r="5" fill="#facc15" stroke="#ffffff" strokeWidth="1" />
        </svg>
      </div>
    </div>
  );
};
