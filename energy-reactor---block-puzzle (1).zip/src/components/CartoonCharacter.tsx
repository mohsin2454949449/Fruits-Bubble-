import React, { useMemo } from 'react';

interface CartoonCharacterProps {
  levelNumber: number;
  size?: number;
  isCurrent?: boolean;
  isCompleted?: boolean;
  isLocked?: boolean;
}

// Deterministic pseudo-random generator
function getSeedValue(seed: number, offset: number): number {
  const x = Math.sin(seed * 127.1 + offset * 311.7) * 43758.5453;
  return x - Math.floor(x);
}

/**
 * Cartoon Character Component for Level Icons
 * Features distinctive, original child-friendly cartoon heroes and companions:
 * - Plump comedy hero ("Bholu" style: yellow vest, cute mustache, eating snack)
 * - Slim brainy buddy ("Chotu" style: spectacles, blue tunic, clever smirk)
 * - Young super-adventurer ("Shivoo" style: cape, hero headband, thumbs-up)
 * - Wonder robo boy ("Veero" style: robot helmet, glowing visor, antennae)
 * - Kid magic sorcerer ("Rudro" style: purple wizard cape, star wand)
 * - Plus cute animal & fruit buddies (Leo the cub, Rexy the dino, Ninja Berry)
 * With funny poses and playful expressions that fit neatly inside the level icon.
 */
export const CartoonCharacter: React.FC<CartoonCharacterProps> = ({
  levelNumber,
  size = 36,
  isCurrent = false,
  isCompleted = false,
  isLocked = false,
}) => {
  const charData = useMemo(() => {
    const r1 = getSeedValue(levelNumber, 1);
    const r2 = getSeedValue(levelNumber, 2);
    const r3 = getSeedValue(levelNumber, 3);
    const r4 = getSeedValue(levelNumber, 4);

    // 8 distinct character archetypes
    const archetype = Math.floor(r1 * 8); // 0-7
    const expression = Math.floor(r2 * 8); // 0-7
    const pose = Math.floor(r3 * 8); // 0-7
    const accessory = Math.floor(r4 * 6); // 0-5

    return { archetype, expression, pose, accessory };
  }, [levelNumber]);

  const animationClass = isCurrent
    ? 'animate-bounce'
    : isCompleted
    ? 'animate-float'
    : '';

  return (
    <div
      className={`relative flex items-center justify-center shrink-0 select-none ${animationClass}`}
      style={{ width: `${size}px`, height: `${size}px` }}
    >
      <svg
        viewBox="0 0 100 100"
        className="w-full h-full drop-shadow-sm overflow-visible"
        style={{
          filter: isLocked ? 'grayscale(0.65) brightness(0.65) opacity(0.7)' : undefined,
        }}
      >
        <defs>
          <linearGradient id={`charGrad-${levelNumber}`} x1="0%" y1="0%" x2="0%" y2="100%">
            {getArchetypeGradient(charData.archetype)}
          </linearGradient>

          <linearGradient id={`goldGrad-${levelNumber}`} x1="0%" y1="0%" x2="0%" y2="100%">
            <stop offset="0%" stopColor="#fde047" />
            <stop offset="100%" stopColor="#eab308" />
          </linearGradient>
        </defs>

        {/* 1. BACK ACCESSORY / CAPE (IF ANY) */}
        {renderBackAccessory(charData.archetype, charData.accessory)}

        {/* 2. BACK LIMBS & FEET */}
        {renderBackLimbs(charData.pose)}

        {/* 3. CHARACTER BODY & HEAD */}
        {renderArchetypeBody(charData.archetype, levelNumber)}

        {/* 4. FACIAL EXPRESSION (EYES, NOSE, MOUTH) */}
        {renderExpression(charData.archetype, charData.expression)}

        {/* 5. FRONT LIMBS & POSE (HANDS / GESTURES) */}
        {renderFrontLimbs(charData.pose, charData.archetype)}

        {/* 6. FRONT HEADGEAR & ACCESSORIES */}
        {renderFrontAccessory(charData.archetype, charData.accessory)}
      </svg>
    </div>
  );
};

// Gradients for each character archetype
function getArchetypeGradient(archetype: number) {
  switch (archetype) {
    case 0: // Plump Comedy Hero: warm peach/gold tone
      return (
        <>
          <stop offset="0%" stopColor="#fed7aa" />
          <stop offset="100%" stopColor="#f97316" />
        </>
      );
    case 1: // Slim Brainy Buddy: bright sky blue / indigo
      return (
        <>
          <stop offset="0%" stopColor="#67e8f9" />
          <stop offset="100%" stopColor="#0284c7" />
        </>
      );
    case 2: // Young Super Adventurer: vibrant coral red & gold
      return (
        <>
          <stop offset="0%" stopColor="#fb7185" />
          <stop offset="100%" stopColor="#e11d48" />
        </>
      );
    case 3: // Wonder Robo Boy: metallic cyan & silver
      return (
        <>
          <stop offset="0%" stopColor="#a5f3fc" />
          <stop offset="100%" stopColor="#0891b2" />
        </>
      );
    case 4: // Kid Magic Sorcerer: royal purple & magenta
      return (
        <>
          <stop offset="0%" stopColor="#e879f9" />
          <stop offset="100%" stopColor="#9333ea" />
        </>
      );
    case 5: // Brave Lion Cub: golden amber
      return (
        <>
          <stop offset="0%" stopColor="#fde047" />
          <stop offset="100%" stopColor="#f59e0b" />
        </>
      );
    case 6: // Dino Buddy: bright lime & emerald green
      return (
        <>
          <stop offset="0%" stopColor="#86efac" />
          <stop offset="100%" stopColor="#16a34a" />
        </>
      );
    default: // Ninja Berry: strawberry ruby red
      return (
        <>
          <stop offset="0%" stopColor="#f43f5e" />
          <stop offset="100%" stopColor="#be123c" />
        </>
      );
  }
}

// Render Main Body for each distinct character archetype
function renderArchetypeBody(archetype: number, levelNumber: number) {
  const grad = `url(#charGrad-${levelNumber})`;

  switch (archetype) {
    case 0: // Plump Comedy Hero: Chubby round face, yellow hero vest
      return (
        <g>
          {/* Chubby Round Head */}
          <circle cx="50" cy="50" r="32" fill="#fed7aa" stroke="#ffffff" strokeWidth="3" />
          {/* Yellow/Red Vest */}
          <path d="M 26 58 Q 50 78 74 58 L 74 76 Q 50 82 26 76 Z" fill="#eab308" stroke="#ffffff" strokeWidth="2" />
          <path d="M 44 60 L 56 60 L 53 78 L 47 78 Z" fill="#ef4444" />
          {/* Cute Little Black Mustache */}
          <path d="M 42 59 Q 46 56 50 58 Q 54 56 58 59 Q 54 62 50 60 Q 46 62 42 59 Z" fill="#1c1917" />
          {/* Soft Cheeks */}
          <circle cx="30" cy="54" r="5" fill="#f43f5e" opacity="0.45" />
          <circle cx="70" cy="54" r="5" fill="#f43f5e" opacity="0.45" />
        </g>
      );

    case 1: // Slim Brainy Buddy: Rounded spectacles, blue tunic
      return (
        <g>
          <ellipse cx="50" cy="50" rx="28" ry="32" fill="#fde68a" stroke="#ffffff" strokeWidth="3" />
          {/* Blue Tunic Collar */}
          <polygon points="32,70 50,82 68,70 65,82 35,82" fill="#2563eb" stroke="#ffffff" strokeWidth="2" />
          {/* Round Spectacles */}
          <circle cx="38" cy="46" r="10" fill="none" stroke="#1c1917" strokeWidth="2.5" />
          <circle cx="62" cy="46" r="10" fill="none" stroke="#1c1917" strokeWidth="2.5" />
          <line x1="48" y1="46" x2="52" y2="46" stroke="#1c1917" strokeWidth="2.5" />
          {/* Glasses Lens Glint */}
          <line x1="33" y1="41" x2="37" y2="45" stroke="#ffffff" strokeWidth="1.5" strokeLinecap="round" />
          <line x1="57" y1="41" x2="61" y2="45" stroke="#ffffff" strokeWidth="1.5" strokeLinecap="round" />
        </g>
      );

    case 2: // Young Super Adventurer: Hero headband, courageous face
      return (
        <g>
          <circle cx="50" cy="52" r="30" fill="#fed7aa" stroke="#ffffff" strokeWidth="3" />
          {/* Red Hero Headband */}
          <path d="M 22 36 Q 50 30 78 36 L 76 43 Q 50 37 24 43 Z" fill="#ef4444" stroke="#ffffff" strokeWidth="1.5" />
          {/* Golden Star/Lightning Crest on Headband */}
          <circle cx="50" cy="38" r="4.5" fill="#facc15" stroke="#ffffff" strokeWidth="1" />
          {/* Cheerful Spiky Hair Tufts on Top */}
          <path d="M 38 28 L 44 20 L 48 27 L 54 18 L 58 27" fill="none" stroke="#78350f" strokeWidth="3" strokeLinecap="round" />
        </g>
      );

    case 3: // Wonder Robo Boy: Red/Cyan Robotic Helmet & Visor
      return (
        <g>
          {/* Robot Head Outer Helmet */}
          <rect x="22" y="24" width="56" height="54" rx="16" fill={grad} stroke="#ffffff" strokeWidth="3" />
          {/* Glowing Digital Eye Screen Visor */}
          <rect x="28" y="36" width="44" height="24" rx="8" fill="#0f172a" stroke="#ffffff" strokeWidth="2" />
          {/* Twin Robotic Antennae with Glowing Bulbs */}
          <line x1="30" y1="24" x2="26" y2="12" stroke="#ffffff" strokeWidth="2.5" strokeLinecap="round" />
          <circle cx="26" cy="11" r="3.5" fill="#facc15" stroke="#ffffff" strokeWidth="1" />
          <line x1="70" y1="24" x2="74" y2="12" stroke="#ffffff" strokeWidth="2.5" strokeLinecap="round" />
          <circle cx="74" cy="11" r="3.5" fill="#facc15" stroke="#ffffff" strokeWidth="1" />
          {/* Chest Light Indicator */}
          <circle cx="50" cy="72" r="3" fill="#22d3ee" stroke="#ffffff" strokeWidth="1" />
        </g>
      );

    case 4: // Kid Magic Sorcerer: Royal purple hood & mystic cloak
      return (
        <g>
          {/* Magic Hood Body */}
          <ellipse cx="50" cy="52" rx="30" ry="32" fill={grad} stroke="#ffffff" strokeWidth="3" />
          {/* Inner Face Opening */}
          <ellipse cx="50" cy="50" rx="20" ry="20" fill="#fde68a" stroke="#ffffff" strokeWidth="2" />
          {/* Pointy Magic Wizard Tip on Top */}
          <path d="M 38 26 L 50 10 L 62 26 Z" fill="#9333ea" stroke="#ffffff" strokeWidth="2" />
          <circle cx="50" cy="10" r="3" fill="#fbbf24" />
        </g>
      );

    case 5: // Brave Lion Cub: Golden fur & round cub ears
      return (
        <g>
          {/* Cub Ears */}
          <circle cx="26" cy="32" r="10" fill="#f59e0b" stroke="#ffffff" strokeWidth="2" />
          <circle cx="26" cy="32" r="5" fill="#fde68a" />
          <circle cx="74" cy="32" r="10" fill="#f59e0b" stroke="#ffffff" strokeWidth="2" />
          <circle cx="74" cy="32" r="5" fill="#fde68a" />
          {/* Round Head */}
          <circle cx="50" cy="52" r="28" fill="#fbbf24" stroke="#ffffff" strokeWidth="3" />
          {/* Soft Muzzle */}
          <ellipse cx="50" cy="62" rx="12" ry="8" fill="#fef3c7" />
          <polygon points="50,57 46,54 54,54" fill="#78350f" />
        </g>
      );

    case 6: // Dino Buddy: Green baby dinosaur
      return (
        <g>
          {/* Dino Soft Crest Spikes on Top */}
          <polygon points="40,24 44,14 48,24" fill="#facc15" stroke="#ffffff" strokeWidth="1.5" />
          <polygon points="52,24 56,14 60,24" fill="#facc15" stroke="#ffffff" strokeWidth="1.5" />
          {/* Plump Dino Head */}
          <circle cx="50" cy="50" r="30" fill={grad} stroke="#ffffff" strokeWidth="3" />
          {/* Cute Yellow Snout */}
          <ellipse cx="50" cy="60" rx="14" ry="9" fill="#fef08a" />
          <circle cx="46" cy="58" r="1.5" fill="#15803d" />
          <circle cx="54" cy="58" r="1.5" fill="#15803d" />
        </g>
      );

    default: // Ninja Berry: Strawberry fruit ninja with headband
      return (
        <g>
          {/* Strawberry Body */}
          <path
            d="M 50 82 C 24 72 18 48 24 34 C 28 24 42 26 50 32 C 58 26 72 24 76 34 C 82 48 76 72 50 82 Z"
            fill={grad}
            stroke="#ffffff"
            strokeWidth="3"
          />
          {/* Black Ninja Mask Band */}
          <rect x="22" y="38" width="56" height="18" rx="6" fill="#1e1b4b" stroke="#ffffff" strokeWidth="1.5" />
          {/* Green Leaf Crown */}
          <polygon points="50,22 42,30 50,28 58,30" fill="#22c55e" stroke="#ffffff" strokeWidth="1.5" />
        </g>
      );
  }
}

// Render Facial Expressions (Eyes, Mouth, Smiles, Winks)
function renderExpression(archetype: number, expr: number) {
  // If Robo Boy (archetype 3), digital LED visor expressions
  if (archetype === 3) {
    switch (expr % 3) {
      case 0: // Happy curve eyes ^^
        return (
          <g stroke="#22d3ee" strokeWidth="3" strokeLinecap="round" fill="none">
            <path d="M 36 48 Q 42 42 48 48" />
            <path d="M 52 48 Q 58 42 64 48" />
          </g>
        );
      case 1: // Winking digital eye
        return (
          <g>
            <circle cx="42" cy="48" r="4" fill="#22d3ee" />
            <line x1="54" y1="48" x2="64" y2="48" stroke="#22d3ee" strokeWidth="3" strokeLinecap="round" />
          </g>
        );
      default: // Star eyes
        return (
          <g fill="#22d3ee">
            <polygon points="42,42 44,47 49,47 45,50 47,55 42,52 37,55 39,50 35,47 40,47" />
            <polygon points="58,42 60,47 65,47 61,50 63,55 58,52 53,55 55,50 51,47 56,47" />
          </g>
        );
    }
  }

  // General cartoon expressions
  switch (expr) {
    case 0: // Big hearty open mouth laugh
      return (
        <g>
          {/* Arched Happy Eyes */}
          <path d="M 34 44 Q 40 38 46 44" stroke="#1c1917" strokeWidth="2.5" strokeLinecap="round" fill="none" />
          <path d="M 54 44 Q 60 38 66 44" stroke="#1c1917" strokeWidth="2.5" strokeLinecap="round" fill="none" />
          {/* Big Open Laughing Mouth */}
          <path d="M 38 52 Q 50 66 62 52 Z" fill="#e11d48" stroke="#ffffff" strokeWidth="2" />
          <path d="M 44 58 Q 50 62 56 58" stroke="#fda4af" strokeWidth="2" fill="none" />
        </g>
      );

    case 1: // Cheeky wink
      return (
        <g>
          {/* Open Round Eye */}
          <circle cx="38" cy="44" r="5" fill="#1c1917" stroke="#ffffff" strokeWidth="1.5" />
          <circle cx="36" cy="42" r="1.8" fill="#ffffff" />
          {/* Winking Curved Eye */}
          <path d="M 54 44 Q 60 38 66 44" stroke="#1c1917" strokeWidth="3" strokeLinecap="round" fill="none" />
          {/* Toothy Smirk */}
          <path d="M 40 56 Q 50 64 60 56" stroke="#1c1917" strokeWidth="2.5" strokeLinecap="round" fill="none" />
        </g>
      );

    case 2: // Funny Tongue-out Face
      return (
        <g>
          <circle cx="36" cy="44" r="5" fill="#1c1917" stroke="#ffffff" strokeWidth="1.5" />
          <circle cx="64" cy="44" r="5" fill="#1c1917" stroke="#ffffff" strokeWidth="1.5" />
          <path d="M 40 56 Q 50 56 60 56" stroke="#1c1917" strokeWidth="2" fill="none" />
          {/* Pink Tongue Poking Out */}
          <path d="M 47 56 Q 47 66 52 66 Q 57 66 57 56 Z" fill="#f43f5e" stroke="#ffffff" strokeWidth="1.2" />
        </g>
      );

    case 3: // Starry-Eyed Excitement
      return (
        <g>
          <polygon points="38,38 40,43 45,43 41,46 43,51 38,48 33,51 35,46 31,43 36,43" fill="#fbbf24" stroke="#ffffff" strokeWidth="1" />
          <polygon points="62,38 64,43 69,43 65,46 67,51 62,48 57,51 59,46 55,43 60,43" fill="#fbbf24" stroke="#ffffff" strokeWidth="1" />
          <path d="M 40 54 Q 50 66 60 54 Z" fill="#be123c" stroke="#ffffff" strokeWidth="2" />
        </g>
      );

    case 4: // Cute Buck-Teeth Grin
      return (
        <g>
          <circle cx="38" cy="44" r="4.5" fill="#1c1917" stroke="#ffffff" strokeWidth="1.5" />
          <circle cx="37" cy="42" r="1.5" fill="#ffffff" />
          <circle cx="62" cy="44" r="4.5" fill="#1c1917" stroke="#ffffff" strokeWidth="1.5" />
          <circle cx="61" cy="42" r="1.5" fill="#ffffff" />
          <path d="M 40 56 Q 50 62 60 56" stroke="#1c1917" strokeWidth="2.5" strokeLinecap="round" fill="none" />
          {/* Two White Teeth */}
          <rect x="46" y="57" width="3.5" height="4" fill="#ffffff" rx="0.5" stroke="#1c1917" strokeWidth="0.8" />
          <rect x="50.5" y="57" width="3.5" height="4" fill="#ffffff" rx="0.5" stroke="#1c1917" strokeWidth="0.8" />
        </g>
      );

    case 5: // Cool Hero Goggles / Confident Grin
      return (
        <g>
          <circle cx="38" cy="44" r="5" fill="#1c1917" stroke="#ffffff" strokeWidth="1.5" />
          <circle cx="62" cy="44" r="5" fill="#1c1917" stroke="#ffffff" strokeWidth="1.5" />
          <path d="M 42 56 Q 52 64 62 55" stroke="#1c1917" strokeWidth="2.5" strokeLinecap="round" fill="none" />
        </g>
      );

    case 6: // Puffed Chubby Eating Cheeks
      return (
        <g>
          <path d="M 34 44 Q 40 40 46 44" stroke="#1c1917" strokeWidth="2.5" strokeLinecap="round" fill="none" />
          <path d="M 54 44 Q 60 40 66 44" stroke="#1c1917" strokeWidth="2.5" strokeLinecap="round" fill="none" />
          <ellipse cx="50" cy="58" rx="6" ry="4" fill="#e11d48" stroke="#ffffff" strokeWidth="1.5" />
          {/* Puffed Cheeks */}
          <circle cx="28" cy="54" r="6" fill="#f43f5e" opacity="0.6" />
          <circle cx="72" cy="54" r="6" fill="#f43f5e" opacity="0.6" />
        </g>
      );

    default: // Joyful Sparkling Eyes
      return (
        <g>
          <circle cx="38" cy="44" r="5" fill="#1c1917" stroke="#ffffff" strokeWidth="1.5" />
          <circle cx="36" cy="41" r="2" fill="#ffffff" />
          <circle cx="62" cy="44" r="5" fill="#1c1917" stroke="#ffffff" strokeWidth="1.5" />
          <circle cx="60" cy="41" r="2" fill="#ffffff" />
          <path d="M 40 56 Q 50 64 60 56" stroke="#1c1917" strokeWidth="2.5" strokeLinecap="round" fill="none" />
        </g>
      );
  }
}

// Back Limbs (Feet)
function renderBackLimbs(pose: number) {
  return (
    <g fill="#ffffff" stroke="#0f172a" strokeWidth="2">
      {pose === 3 ? (
        <>
          <ellipse cx="30" cy="82" rx="7" ry="4.5" transform="rotate(-25 30 82)" />
          <ellipse cx="70" cy="82" rx="7" ry="4.5" transform="rotate(25 70 82)" />
        </>
      ) : (
        <>
          <ellipse cx="38" cy="82" rx="7" ry="4.5" />
          <ellipse cx="62" cy="82" rx="7" ry="4.5" />
        </>
      )}
    </g>
  );
}

// Front Limbs & Funny Poses (Hands, Snack, Magic Wand, Peace Sign)
function renderFrontLimbs(pose: number, archetype: number) {
  // If archetype 0 (Plump hero), often holding a snack!
  if (archetype === 0 && (pose % 2 === 0)) {
    return (
      <g>
        {/* Hand holding golden samosa / treat */}
        <circle cx="22" cy="62" r="6" fill="#ffffff" stroke="#1c1917" strokeWidth="1.8" />
        <circle cx="78" cy="62" r="6" fill="#ffffff" stroke="#1c1917" strokeWidth="1.8" />
        {/* Golden Triangular Snack / Samosa */}
        <polygon points="78,54 70,66 86,66" fill="#f59e0b" stroke="#ffffff" strokeWidth="1.5" />
      </g>
    );
  }

  // If archetype 4 (Sorcerer), holding magic star wand
  if (archetype === 4) {
    return (
      <g>
        <circle cx="20" cy="60" r="5.5" fill="#ffffff" stroke="#1c1917" strokeWidth="1.8" />
        {/* Right hand holding wand */}
        <circle cx="80" cy="50" r="5.5" fill="#ffffff" stroke="#1c1917" strokeWidth="1.8" />
        <line x1="80" y1="52" x2="88" y2="28" stroke="#facc15" strokeWidth="3" strokeLinecap="round" />
        <polygon points="88,24 90,29 95,29 91,32 93,37 88,34 83,37 85,32 81,29 86,29" fill="#facc15" stroke="#ffffff" strokeWidth="1" />
      </g>
    );
  }

  switch (pose) {
    case 0: // Victory V-Signs
      return (
        <g fill="#ffffff" stroke="#0f172a" strokeWidth="2">
          <circle cx="16" cy="42" r="6" />
          <line x1="13" y1="38" x2="11" y2="30" stroke="#ffffff" strokeWidth="2.5" strokeLinecap="round" />
          <line x1="18" y1="38" x2="20" y2="30" stroke="#ffffff" strokeWidth="2.5" strokeLinecap="round" />
          <circle cx="84" cy="42" r="6" />
          <line x1="81" y1="38" x2="79" y2="30" stroke="#ffffff" strokeWidth="2.5" strokeLinecap="round" />
          <line x1="86" y1="38" x2="88" y2="30" stroke="#ffffff" strokeWidth="2.5" strokeLinecap="round" />
        </g>
      );

    case 1: // Superhero Flex Biceps
      return (
        <g fill="#ffffff" stroke="#0f172a" strokeWidth="2">
          <circle cx="15" cy="45" r="7" />
          <circle cx="85" cy="45" r="7" />
        </g>
      );

    case 2: // Thumbs Up
      return (
        <g fill="#ffffff" stroke="#0f172a" strokeWidth="2">
          <circle cx="18" cy="60" r="6" />
          <circle cx="82" cy="52" r="6" />
          <line x1="82" y1="50" x2="82" y2="42" stroke="#ffffff" strokeWidth="3" strokeLinecap="round" />
        </g>
      );

    case 3: // Big Enthusiastic Wave
      return (
        <g fill="#ffffff" stroke="#0f172a" strokeWidth="2">
          <circle cx="18" cy="62" r="6" />
          <circle cx="84" cy="34" r="6.5" />
          <path d="M 90 28 Q 94 34 90 40" stroke="#38bdf8" strokeWidth="2" strokeLinecap="round" fill="none" />
        </g>
      );

    case 4: // High Fist Pump
      return (
        <g fill="#ffffff" stroke="#0f172a" strokeWidth="2">
          <circle cx="22" cy="62" r="6" />
          <circle cx="80" cy="24" r="7" />
        </g>
      );

    case 5: // Thinking Hand on Chin (Brainy style)
      return (
        <g fill="#ffffff" stroke="#0f172a" strokeWidth="2">
          <circle cx="24" cy="62" r="6" />
          <circle cx="56" cy="64" r="5.5" />
        </g>
      );

    case 6: // Peeking Hands on Cheeks
      return (
        <g fill="#ffffff" stroke="#0f172a" strokeWidth="2">
          <circle cx="24" cy="54" r="6" />
          <circle cx="76" cy="54" r="6" />
        </g>
      );

    default: // Playful Hands on Hips
      return (
        <g fill="#ffffff" stroke="#0f172a" strokeWidth="2">
          <circle cx="18" cy="58" r="6" />
          <circle cx="82" cy="58" r="6" />
        </g>
      );
  }
}

// Back Accessories (Capes)
function renderBackAccessory(archetype: number, accessory: number) {
  // If adventurer (archetype 2), fluttering hero cape
  if (archetype === 2 || accessory === 1) {
    return (
      <path
        d="M 28 44 Q 10 65 14 80 Q 50 86 86 80 Q 90 65 72 44 Z"
        fill="#ef4444"
        stroke="#ffffff"
        strokeWidth="2"
      />
    );
  }
  // Sorcerer cape
  if (archetype === 4) {
    return (
      <path
        d="M 26 44 Q 8 68 12 84 Q 50 90 88 84 Q 92 68 74 44 Z"
        fill="#7e22ce"
        stroke="#ffffff"
        strokeWidth="2"
      />
    );
  }
  return null;
}

// Front Headgear Accessories (Crowns, Star Hats, Party Hats)
function renderFrontAccessory(archetype: number, accessory: number) {
  if (archetype === 3) return null; // Robot has its own helmet antennae

  switch (accessory) {
    case 2: // Golden Hero Crown
      return (
        <g>
          <path d="M 38 22 L 42 12 L 50 18 L 58 12 L 62 22 Z" fill="#facc15" stroke="#ffffff" strokeWidth="2" />
          <circle cx="42" cy="12" r="1.5" fill="#ef4444" />
          <circle cx="50" cy="18" r="1.5" fill="#3b82f6" />
          <circle cx="58" cy="12" r="1.5" fill="#10b981" />
        </g>
      );
    case 3: // Party Hat
      return (
        <g>
          <polygon points="42,24 50,6 58,24" fill="#ec4899" stroke="#ffffff" strokeWidth="2" />
          <circle cx="50" cy="6" r="3" fill="#fde047" />
        </g>
      );
    case 4: // Green Sprout Leaves
      return (
        <g stroke="#ffffff" strokeWidth="1.5">
          <path d="M 50 22 Q 56 12 64 14 Q 58 22 50 22 Z" fill="#22c55e" />
          <path d="M 50 22 Q 44 12 36 14 Q 42 22 50 22 Z" fill="#22c55e" />
          <circle cx="50" cy="22" r="2" fill="#84cc16" />
        </g>
      );
    default:
      return null;
  }
}
