import React from 'react';
import { GamePiece } from '../types/game';
import { ReactorBlock } from './ReactorBlock';
import { AlertCircle, Zap, RotateCw } from 'lucide-react';

interface PieceTrayProps {
  pieces: GamePiece[];
  selectedPieceId: string | null;
  draggedPieceId: string | null;
  onPieceSelect: (piece: GamePiece) => void;
  onRotatePiece: (piece: GamePiece) => void;
  onDragStart: (piece: GamePiece, clientX: number, clientY: number) => void;
  hammerCount?: number;
  refreshCount?: number;
  hammerActive?: boolean;
  onToggleHammer?: () => void;
  onRerollTray?: () => void;
  blockSkin?: string;
}

export const PieceTray: React.FC<PieceTrayProps> = ({
  pieces,
  selectedPieceId,
  draggedPieceId,
  onPieceSelect,
  onRotatePiece,
  onDragStart,
  hammerCount = 0,
  refreshCount = 0,
  hammerActive = false,
  onToggleHammer,
  onRerollTray,
  blockSkin = 'core_fruit_bubble',
}) => {
  const selectedPiece = pieces.find((p) => p.id === selectedPieceId && !p.used);

  return (
    <div className="w-full select-none">
      {/* Power-Up Mini Bar & Quick Rotate Action */}
      <div className="flex items-center justify-between mb-1 px-1 gap-2">
        {/* Left: Rotate Selected Core Button or Instruction Guide */}
        {selectedPiece && !selectedPiece.used ? (
          <button
            onClick={() => onRotatePiece(selectedPiece)}
            className="flex items-center gap-1.5 px-2.5 py-1 rounded-xl text-[10px] font-black bg-pink-500/25 border border-pink-400 text-pink-200 hover:bg-pink-500/40 active:scale-95 transition-all cursor-pointer shadow-sm animate-pulse-glow"
            title="Rotate selected core 90° clockwise"
          >
            <RotateCw className="w-3 h-3 text-pink-300" />
            <span>Rotate ({selectedPiece.rotation || 0}°)</span>
          </button>
        ) : (
          <div className="flex items-center gap-1 text-[9px] font-mono font-bold text-pink-300/80 tracking-wide uppercase">
            <RotateCw className="w-2.5 h-2.5 text-pink-400" />
            <span>Tap Core To Rotate 90°</span>
          </div>
        )}

        {/* Right: Hammer & Reroll Tools */}
        {(onToggleHammer || onRerollTray) && (
          <div className="flex items-center gap-1.5">
            {onToggleHammer && (
              <button
                onClick={onToggleHammer}
                className={`flex items-center gap-1.5 px-2.5 py-1 rounded-xl text-[10px] font-black transition-all cursor-pointer active:scale-95 ${
                  hammerActive
                    ? 'bg-rose-500 text-white shadow-[0_0_14px_rgba(244,63,94,0.8)] ring-2 ring-rose-300'
                    : 'bg-white/[0.08] border border-rose-400/40 text-rose-300 hover:border-rose-300'
                }`}
                title="Pop any fruit bubble on board"
              >
                <Zap className="w-3 h-3 fill-current" />
                <span>Hammer ({hammerCount})</span>
              </button>
            )}

            {onRerollTray && (
              <button
                onClick={onRerollTray}
                className="flex items-center gap-1.5 px-2.5 py-1 rounded-xl text-[10px] font-black bg-white/[0.08] border border-purple-400/40 text-purple-300 hover:border-purple-300 transition-all cursor-pointer active:scale-95"
                title="Reroll tray pieces"
              >
                <RotateCw className="w-3 h-3" />
                <span>Reroll ({refreshCount})</span>
              </button>
            )}
          </div>
        )}
      </div>

      {/* 3 Fruit Bubble Chambers */}
      <div className="grid grid-cols-3 gap-1.5 sm:gap-2 p-1.5 sm:p-2 rounded-2xl sm:rounded-3xl glass-panel-colorful shadow-[0_12px_36px_rgba(18,6,32,0.7)]">
        {pieces.map((piece, index) => {
          if (piece.used) {
            return (
              <div
                key={piece.id}
                className="h-[76px] sm:h-[88px] rounded-xl sm:rounded-2xl border-2 border-dashed border-pink-400/20 bg-[#140b28]/40 flex flex-col items-center justify-center text-pink-300/30"
              >
                <div className="w-5 h-5 rounded-full border border-pink-400/30 flex items-center justify-center text-[9px] font-mono font-bold">
                  {index + 1}
                </div>
                <span className="text-[8px] sm:text-[9px] font-bold tracking-wider uppercase mt-1">EMPTY</span>
              </div>
            );
          }

          const isSelected = selectedPieceId === piece.id;
          const isBeingDragged = draggedPieceId === piece.id;
          const cannotFit = !piece.canFit;
          const currentRotation = piece.rotation || 0;

          return (
            <div
              key={piece.id}
              onPointerDown={(e) => {
                if (e.button !== 0 && e.pointerType === 'mouse') return;
                const startX = e.clientX;
                const startY = e.clientY;
                let hasDragged = false;

                const handlePointerMove = (moveEvent: PointerEvent) => {
                  if (!hasDragged) {
                    const dist = Math.hypot(moveEvent.clientX - startX, moveEvent.clientY - startY);
                    if (dist > 7) {
                      hasDragged = true;
                      onDragStart(piece, moveEvent.clientX, moveEvent.clientY);
                    }
                  }
                };

                const handlePointerUp = () => {
                  window.removeEventListener('pointermove', handlePointerMove);
                  window.removeEventListener('pointerup', handlePointerUp);
                  window.removeEventListener('pointercancel', handlePointerUp);

                  if (!hasDragged) {
                    // Tap / click: Rotate this core piece 90° clockwise!
                    onRotatePiece(piece);
                  }
                };

                window.addEventListener('pointermove', handlePointerMove, { passive: false });
                window.addEventListener('pointerup', handlePointerUp);
                window.addEventListener('pointercancel', handlePointerUp);
              }}
              className={`relative h-[76px] sm:h-[88px] rounded-xl sm:rounded-2xl flex items-center justify-center p-1 cursor-grab active:cursor-grabbing transition-all duration-200 select-none ${
                isSelected
                  ? 'ring-2 ring-pink-300 bg-pink-950/60 shadow-[0_0_24px_rgba(244,63,94,0.5)] scale-105'
                  : 'bg-gradient-to-b from-[#25103c]/75 to-[#160928]/85 hover:from-[#31154f] hover:to-[#1e0d36] border border-white/12 hover:border-pink-400/60 shadow-[0_4px_16px_rgba(0,0,0,0.35)]'
              } ${isBeingDragged ? 'opacity-25' : ''} ${
                cannotFit ? 'opacity-40 grayscale-[35%]' : ''
              }`}
              style={{ touchAction: 'none' }}
            >
              {/* Subtle Corner Bubble Accents */}
              <div className="absolute top-1.5 left-1.5 w-1.5 h-1.5 rounded-full bg-pink-400/40" />

              {/* Warning tag if piece cannot fit anywhere currently */}
              {cannotFit && (
                <div className="absolute top-1.5 right-1.5 z-10 flex items-center gap-0.5 px-1.5 py-0.5 rounded-full bg-rose-950/95 border border-rose-500/60 text-[8px] text-rose-300 font-mono shadow-sm">
                  <AlertCircle className="w-2.5 h-2.5" />
                  <span>BLOCKED</span>
                </div>
              )}

              {/* Rotation Angle Corner Badge & Quick Rotate Touch Target */}
              <button
                type="button"
                onPointerDown={(e) => e.stopPropagation()}
                onClick={(e) => {
                  e.stopPropagation();
                  onRotatePiece(piece);
                }}
                className={`absolute bottom-1 right-1 z-10 flex items-center gap-0.5 px-1.5 py-0.5 rounded-lg border text-[8px] font-mono font-bold active:scale-90 transition-transform cursor-pointer shadow-sm ${
                  isSelected
                    ? 'bg-pink-500/40 border-pink-300 text-white'
                    : 'bg-black/60 hover:bg-pink-900/80 border-pink-400/40 text-pink-200'
                }`}
                title="Tap to rotate 90° clockwise"
              >
                <RotateCw className="w-2.5 h-2.5 text-pink-300" />
                <span>{currentRotation}°</span>
              </button>

              {/* Render Shape Matrix with Fruit Bubble components & smooth 90-degree snap animation */}
              <div
                key={`${piece.id}-${currentRotation}`}
                className="grid gap-0.5 sm:gap-1 items-center justify-center animate-rotate-pop pointer-events-none"
                style={{
                  gridTemplateColumns: `repeat(${piece.shape.width}, minmax(0, 1fr))`,
                  gridTemplateRows: `repeat(${piece.shape.height}, minmax(0, 1fr))`,
                }}
              >
                {piece.shape.matrix.map((row, r) =>
                  row.map((val, c) => (
                    <div
                      key={`${r}-${c}`}
                      className="w-[18px] h-[18px] sm:w-[20px] sm:h-[20px] flex items-center justify-center"
                    >
                      {val === 1 && (
                        <ReactorBlock
                          color={piece.color}
                          theme={blockSkin}
                          size="100%"
                          glow={false}
                        />
                      )}
                    </div>
                  ))
                )}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
