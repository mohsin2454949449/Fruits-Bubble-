import React from 'react';
import { RotateCcw, Zap, Flame, Grid3X3, Award, Sparkles, Home, Layers, Compass } from 'lucide-react';
import { GameStats } from '../types/game';
import { ReactorBlock } from './ReactorBlock';
import { sound } from '../utils/audio';

interface GameOverModalProps {
  level: number;
  targetScore: number;
  stats: GameStats;
  isNewRecord: boolean;
  onRestart: () => void;
  onHome: () => void;
  onLevels: () => void;
}

export const GameOverModal: React.FC<GameOverModalProps> = ({
  level,
  targetScore,
  stats,
  isNewRecord,
  onRestart,
  onHome,
  onLevels,
}) => {
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-xl animate-fade-in select-none">
      <div className="relative w-full max-w-sm rounded-3xl glass-panel-colorful p-6 text-center overflow-hidden shadow-[0_0_60px_rgba(168,85,247,0.4)]">
        {/* Ambient Top Glow Orbs */}
        <div className="absolute -top-12 left-1/2 -translate-x-1/2 w-52 h-32 bg-gradient-to-r from-cyan-400/35 via-fuchsia-500/40 to-pink-500/35 blur-2xl pointer-events-none" />

        {/* Futuristic Corner Brackets */}
        <div className="absolute top-3 left-3 w-3 h-3 border-t-2 border-l-2 border-cyan-300 drop-shadow-[0_0_8px_rgba(0,240,255,0.9)]" />
        <div className="absolute top-3 right-3 w-3 h-3 border-t-2 border-r-2 border-cyan-300 drop-shadow-[0_0_8px_rgba(0,240,255,0.9)]" />
        <div className="absolute bottom-3 left-3 w-3 h-3 border-b-2 border-l-2 border-cyan-300 drop-shadow-[0_0_8px_rgba(0,240,255,0.9)]" />
        <div className="absolute bottom-3 right-3 w-3 h-3 border-b-2 border-r-2 border-cyan-300 drop-shadow-[0_0_8px_rgba(0,240,255,0.9)]" />

        {/* Core Icon */}
        <div className="w-16 h-16 mx-auto mb-2 flex items-center justify-center drop-shadow-[0_0_18px_rgba(255,45,85,0.8)]">
          <ReactorBlock color="red" size={56} />
        </div>

        {/* Status Badge */}
        <div className="inline-block px-3 py-0.5 mb-1.5 rounded-full bg-rose-950/90 border border-rose-500/60 text-[10px] font-mono font-bold tracking-widest text-rose-300 uppercase shadow-md">
          OUT OF SPACE — LEVEL {level}
        </div>

        {/* Title Lockup */}
        <h2 className="text-2xl font-black tracking-wider text-white font-['Chakra_Petch',sans-serif] uppercase mb-0.5 drop-shadow-[0_2px_10px_rgba(0,0,0,0.8)]">
          NO MOVES LEFT
        </h2>
        <p className="text-[10px] font-extrabold tracking-[0.22em] text-pink-300 uppercase font-mono mb-3">
          TARGET: {targetScore.toLocaleString()} PTS
        </p>

        {/* New Record Banner */}
        {isNewRecord && (
          <div className="mb-3 p-2 rounded-2xl bg-gradient-to-r from-amber-500/25 via-yellow-400/30 to-amber-500/25 border-1.5 border-amber-300/70 flex items-center justify-center gap-2 text-amber-200 font-black text-xs uppercase tracking-wider animate-bounce shadow-[0_0_20px_rgba(251,191,36,0.4)]">
            <Award className="w-4 h-4 text-yellow-300 fill-amber-400" />
            <span>New Best Score Record!</span>
            <Sparkles className="w-3.5 h-3.5 text-yellow-200" />
          </div>
        )}

        {/* Final Score Showcase */}
        <div className="p-3 mb-3 rounded-2xl score-panel-vibrant shadow-inner">
          <span className="block text-[10px] font-extrabold text-pink-200/90 uppercase tracking-widest font-mono">
            Juice Score Achieved
          </span>
          <span className="text-2xl sm:text-3xl font-black text-white font-mono tracking-tight drop-shadow-[0_0_16px_rgba(255,45,85,0.8)]">
            {stats.score.toLocaleString()} PTS
          </span>
        </div>

        {/* Mission Stats Breakdown */}
        <div className="grid grid-cols-3 gap-1.5 mb-4 text-center">
          <div className="p-2 rounded-2xl btn-arcade">
            <span className="block text-[8px] text-pink-200/80 uppercase font-mono font-bold">Lines Cleared</span>
            <div className="flex items-center justify-center gap-1 text-xs font-black text-white font-mono mt-0.5">
              <Sparkles className="w-3 h-3 text-pink-300 fill-pink-400" />
              <span>{stats.linesCleared}</span>
            </div>
          </div>
          <div className="p-2 rounded-2xl btn-arcade">
            <span className="block text-[8px] text-pink-200/80 uppercase font-mono font-bold">Fruits Placed</span>
            <div className="flex items-center justify-center gap-1 text-xs font-black text-white font-mono mt-0.5">
              <Grid3X3 className="w-3 h-3 text-pink-300 fill-pink-400" />
              <span>{stats.blocksPlaced}</span>
            </div>
          </div>
          <div className="p-2 rounded-2xl btn-arcade">
            <span className="block text-[8px] text-pink-200/80 uppercase font-mono font-bold">Max Multiplier</span>
            <div className="flex items-center justify-center gap-1 text-xs font-black text-amber-300 font-mono mt-0.5">
              <Flame className="w-3 h-3 text-amber-400 fill-amber-500" />
              <span>×{stats.maxCombo > 0 ? Math.min(stats.maxCombo, 4) : 1}</span>
            </div>
          </div>
        </div>

        {/* Action Buttons */}
        <button
          onClick={() => {
            sound.playClick();
            onRestart();
          }}
          className="w-full py-3.5 px-4 mb-2 rounded-2xl font-black text-sm uppercase tracking-wider text-white btn-cta-glow flex items-center justify-center gap-2 cursor-pointer shadow-[0_8px_30px_rgba(255,51,102,0.6)] active:scale-95 transition-transform"
        >
          <RotateCcw className="w-4 h-4 text-white stroke-[3]" />
          <span>Retry Level {level}</span>
        </button>

        <div className="grid grid-cols-2 gap-2">
          <button
            onClick={() => {
              sound.playClick();
              onLevels();
            }}
            className="py-2.5 px-3 rounded-2xl btn-arcade flex items-center justify-center gap-1.5 text-xs font-bold text-pink-200 uppercase active:scale-95 transition-transform cursor-pointer"
          >
            <Compass className="w-3.5 h-3.5 text-pink-300" />
            <span>Roadmap</span>
          </button>

          <button
            onClick={() => {
              sound.playClick();
              onHome();
            }}
            className="py-2.5 px-3 rounded-2xl btn-arcade flex items-center justify-center gap-1.5 text-xs font-bold text-pink-200 uppercase active:scale-95 transition-transform cursor-pointer"
          >
            <Home className="w-3.5 h-3.5 text-pink-300" />
            <span>Home</span>
          </button>
        </div>
      </div>
    </div>
  );
};
