import React from 'react';
import {
  Play,
  Layers,
  Compass,
  ShoppingBag,
  Gift,
  Trophy,
  User,
  Settings as SettingsIcon,
  Coins,
  Star,
  Zap,
  Sparkles,
  Flame,
  Tv,
} from 'lucide-react';
import { PlayerProfile } from '../types/game';
import { ReactorBlock } from './ReactorBlock';
import { getLevelTarget } from '../utils/levelData';
import { isDailyGiftClaimable } from '../utils/saveManager';
import { ACHIEVEMENTS } from '../utils/gameContent';

interface HomeScreenProps {
  profile: PlayerProfile;
  onPlayGame: () => void;
  onNavigate: (screen: 'levels' | 'store' | 'daily' | 'settings' | 'profile' | 'achievements') => void;
  onOpenWatchAd?: () => void;
}

export const HomeScreen: React.FC<HomeScreenProps> = ({
  profile,
  onPlayGame,
  onNavigate,
  onOpenWatchAd,
}) => {
  const currentTarget = getLevelTarget(profile.level);
  const dailyGiftAvailable = isDailyGiftClaimable(profile.lastDailyClaimDate);
  const totalStars = Object.values(profile.completedLevels).reduce(
    (acc, lvl) => acc + (lvl?.stars || (lvl?.completed ? 3 : 0)),
    0
  );

  // Count unclaimed achievements
  const unclaimedAchievementsCount = ACHIEVEMENTS.filter((ach) => {
    let progress = 0;
    if (ach.id === 'ach_first_clear') progress = profile.totalLines > 0 ? 1 : 0;
    else if (ach.id === 'ach_lines_25') progress = profile.totalLines;
    else if (ach.id === 'ach_lines_100') progress = profile.totalLines;
    else if (ach.id === 'ach_combo_3') progress = profile.maxCombo;
    else if (ach.id === 'ach_level_5') progress = profile.level > 5 ? 5 : Object.keys(profile.completedLevels).length;
    else if (ach.id === 'ach_level_10') progress = profile.level > 10 ? 10 : Object.keys(profile.completedLevels).length;
    else if (ach.id === 'ach_score_5000') progress = profile.highScore;
    else if (ach.id === 'ach_blocks_100') progress = profile.totalBlocks;
    return progress >= ach.target && !profile.claimedAchievements.includes(ach.id);
  }).length;

  return (
    <div className="relative w-full h-[100dvh] max-h-[100dvh] flex flex-col justify-between px-3.5 pt-[max(10px,env(safe-area-inset-top))] pb-[max(12px,env(safe-area-inset-bottom))] text-white select-none overflow-hidden animate-fade-in max-w-[430px] mx-auto">
      {/* Top Header: Currencies, Level Badge & Quick Settings */}
      <header className="w-full flex items-center justify-between shrink-0 mb-1 z-20">
        {/* Level Indicator Badge */}
        <button
          onClick={() => onNavigate('levels')}
          className="flex items-center gap-1.5 px-3 py-1.5 rounded-2xl bg-white/[0.08] border border-pink-400/40 backdrop-blur-md shadow-sm active:scale-95 transition-transform cursor-pointer"
        >
          <div className="w-5 h-5 rounded-lg bg-pink-500/20 border border-pink-400/50 flex items-center justify-center text-pink-300">
            <Sparkles className="w-3.5 h-3.5 fill-current" />
          </div>
          <div className="text-left leading-tight">
            <div className="text-[9px] font-bold text-pink-300 uppercase">LEVEL</div>
            <div className="text-xs font-black text-white font-mono">LVL {profile.level}</div>
          </div>
        </button>

        {/* Currency Vault & Settings */}
        <div className="flex items-center gap-2">
          {/* Coins with +Ad option */}
          <button
            onClick={onOpenWatchAd}
            className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-2xl bg-amber-950/60 border border-amber-400/40 hover:border-amber-400/70 backdrop-blur-md shadow-sm active:scale-95 transition-all cursor-pointer group"
            title="Watch Video Ad for Free Bonus Coins"
          >
            <Coins className="w-3.5 h-3.5 text-amber-300 fill-amber-400" />
            <span className="text-xs font-black font-mono text-amber-200">
              {profile.coins.toLocaleString()}
            </span>
            <span className="text-[9px] font-black text-amber-400 bg-amber-400/20 px-1 py-0.2 rounded-full flex items-center gap-0.5">
              <Tv className="w-2.5 h-2.5" />
              <span>+Ad</span>
            </span>
          </button>

          {/* Level Stars */}
          <div className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-2xl bg-yellow-950/60 border border-yellow-400/40 backdrop-blur-md shadow-sm">
            <Star className="w-3.5 h-3.5 text-yellow-300 fill-yellow-400" />
            <span className="text-xs font-black font-mono text-yellow-200">
              {totalStars}
            </span>
          </div>

          {/* Settings Quick Button */}
          <button
            onClick={() => onNavigate('settings')}
            className="w-8 h-8 rounded-2xl btn-arcade flex items-center justify-center text-pink-300 active:scale-95 transition-transform cursor-pointer"
            aria-label="Settings"
          >
            <SettingsIcon className="w-4 h-4 text-pink-200" />
          </button>
        </div>
      </header>

      {/* Main Center Hero: Animated Logo, Title & Tagline */}
      <div className="flex-1 flex flex-col items-center justify-center my-auto text-center z-10 py-1">
        {/* Animated 3D Fruit Bubble Logo Lockup */}
        <div className="relative mb-3 flex items-center justify-center">
          {/* Ambient Juicy Bloom Behind Logo */}
          <div className="absolute w-36 h-36 rounded-full bg-gradient-to-tr from-pink-500/35 via-rose-500/30 to-amber-500/30 blur-2xl pointer-events-none" />
          
          {/* Rotating Outer Fruit Bubbles Ring */}
          <div className="relative w-20 h-20 sm:w-24 sm:h-24 flex items-center justify-center animate-spin-slow">
            <div className="absolute inset-0 rounded-3xl border-2 border-dashed border-pink-400/40" />
            <div className="absolute inset-1.5 rounded-2xl border border-purple-400/40" />
          </div>

          {/* Floating Hero Fruit Bubble */}
          <div className="absolute animate-float drop-shadow-[0_0_25px_rgba(255,45,85,0.7)]">
            <ReactorBlock color="red" size={56} glow={true} />
          </div>
        </div>

        {/* Title */}
        <h1 className="text-3xl sm:text-4xl font-black tracking-wider bg-gradient-to-r from-pink-200 via-rose-300 to-amber-200 bg-clip-text text-transparent font-['Chakra_Petch',sans-serif] drop-shadow-[0_2px_16px_rgba(255,45,85,0.6)] leading-none uppercase mb-1">
          FRUIT BUBBLE
        </h1>

        {/* Tagline */}
        <p className="text-[11px] sm:text-xs font-extrabold tracking-[0.25em] bg-gradient-to-r from-pink-300 via-purple-300 to-amber-300 bg-clip-text text-transparent uppercase font-mono mb-4">
          POP YOUR PUZZLE
        </p>

        {/* Current Level Objective Banner */}
        <div className="w-full max-w-[320px] p-2.5 rounded-2xl bg-white/[0.06] border border-pink-400/30 backdrop-blur-md mb-2.5 flex items-center justify-center gap-2.5 shadow-lg">
          <div className="p-1.5 rounded-xl bg-pink-500/20 text-pink-300">
            <Flame className="w-4 h-4 fill-pink-400" />
          </div>
          <div className="text-left">
            <div className="text-[10px] font-mono font-bold text-pink-300 uppercase">
              TARGET SCORE
            </div>
            <div className="text-sm font-black text-white font-mono leading-none">
              {currentTarget.toLocaleString()} PTS
            </div>
          </div>
        </div>

        {/* Optional Voluntary Ad Coin Boost Banner */}
        {onOpenWatchAd && (
          <button
            onClick={onOpenWatchAd}
            className="w-full max-w-[320px] mb-3 py-2 px-3 rounded-2xl bg-gradient-to-r from-amber-500/20 via-yellow-500/25 to-amber-500/20 border border-amber-400/40 hover:border-amber-400 flex items-center justify-between text-amber-200 active:scale-95 transition-all cursor-pointer shadow-sm group"
          >
            <div className="flex items-center gap-2">
              <div className="w-6 h-6 rounded-lg bg-amber-400/25 flex items-center justify-center text-yellow-300">
                <Tv className="w-3.5 h-3.5" />
              </div>
              <span className="text-[11px] font-extrabold uppercase tracking-wider text-white">
                Free Coins (Watch Ad)
              </span>
            </div>
            <div className="flex items-center gap-1 px-2 py-0.5 rounded-full bg-amber-400/25 text-yellow-300 font-mono text-[10px] font-black">
              <Coins className="w-3 h-3 fill-amber-400" />
              <span>+500 / +1,000</span>
            </div>
          </button>
        )}

        {/* Primary Action Button: PLAY GAME */}
        <button
          onClick={onPlayGame}
          className="w-full max-w-[320px] py-4 px-6 rounded-2xl btn-cta-glow flex items-center justify-center gap-2.5 text-white font-black text-base uppercase tracking-wider shadow-[0_8px_30px_rgba(255,51,102,0.65)] active:scale-95 transition-all cursor-pointer group"
        >
          <div className="w-6 h-6 rounded-xl bg-black/20 flex items-center justify-center">
            <Play className="w-4 h-4 text-white fill-white" />
          </div>
          <span>PLAY GAME</span>
          <span className="text-xs font-mono font-extrabold px-2 py-0.5 rounded-full bg-white/20 text-white">
            LVL {profile.level}
          </span>
        </button>
      </div>

      {/* Bottom Menu Navigation Grid: 5 Core Arcade Features */}
      <footer className="w-full shrink-0 z-20">
        <div className="grid grid-cols-4 gap-2 mb-2">
          {/* ROADMAP / LEVELS */}
          <button
            onClick={() => onNavigate('levels')}
            className="relative flex flex-col items-center justify-center p-2 rounded-2xl btn-arcade text-center active:scale-95 transition-transform cursor-pointer"
          >
            <div className="w-8 h-8 rounded-xl bg-cyan-400/15 border border-cyan-400/30 flex items-center justify-center text-cyan-300 mb-1">
              <Compass className="w-4 h-4" />
            </div>
            <span className="text-[10px] font-bold text-white uppercase tracking-wider">Roadmap</span>
            <span className="text-[8px] font-mono text-cyan-300/80">Lvl {profile.level}</span>
          </button>

          {/* STORE */}
          <button
            onClick={() => onNavigate('store')}
            className="relative flex flex-col items-center justify-center p-2 rounded-2xl btn-arcade text-center active:scale-95 transition-transform cursor-pointer"
          >
            <div className="w-8 h-8 rounded-xl bg-purple-400/15 border border-purple-400/30 flex items-center justify-center text-purple-300 mb-1">
              <ShoppingBag className="w-4 h-4" />
            </div>
            <span className="text-[10px] font-bold text-white uppercase tracking-wider">Store</span>
            <span className="text-[8px] font-mono text-purple-300/80">Skins</span>
          </button>

          {/* DAILY GIFTS */}
          <button
            onClick={() => onNavigate('daily')}
            className="relative flex flex-col items-center justify-center p-2 rounded-2xl btn-arcade text-center active:scale-95 transition-transform cursor-pointer"
          >
            {dailyGiftAvailable && (
              <span className="absolute -top-1 -right-1 w-3 h-3 rounded-full bg-rose-500 border border-white animate-ping" />
            )}
            {dailyGiftAvailable && (
              <span className="absolute -top-1 -right-1 w-3 h-3 rounded-full bg-rose-500 border border-white" />
            )}
            <div className="w-8 h-8 rounded-xl bg-amber-400/15 border border-amber-400/30 flex items-center justify-center text-amber-300 mb-1">
              <Gift className="w-4 h-4" />
            </div>
            <span className="text-[10px] font-bold text-white uppercase tracking-wider">Daily</span>
            <span className="text-[8px] font-mono text-amber-300/80">
              {dailyGiftAvailable ? 'Claim!' : 'Day ' + (profile.dailyStreak || 1)}
            </span>
          </button>

          {/* ACHIEVEMENTS */}
          <button
            onClick={() => onNavigate('achievements')}
            className="relative flex flex-col items-center justify-center p-2 rounded-2xl btn-arcade text-center active:scale-95 transition-transform cursor-pointer"
          >
            {unclaimedAchievementsCount > 0 && (
              <span className="absolute -top-1 -right-1 px-1.5 py-0.2 rounded-full bg-rose-500 text-[8px] font-mono font-black text-white border border-white shadow">
                {unclaimedAchievementsCount}
              </span>
            )}
            <div className="w-8 h-8 rounded-xl bg-pink-400/15 border border-pink-400/30 flex items-center justify-center text-pink-300 mb-1">
              <Trophy className="w-4 h-4" />
            </div>
            <span className="text-[10px] font-bold text-white uppercase tracking-wider">Trophies</span>
            <span className="text-[8px] font-mono text-pink-300/80">Rewards</span>
          </button>
        </div>

        {/* Secondary Bar: Profile & All-Time High Score Pill */}
        <div className="flex items-center justify-between gap-2">
          {/* Profile Card */}
          <button
            onClick={() => onNavigate('profile')}
            className="flex-1 flex items-center gap-2 p-2 rounded-2xl bg-white/[0.04] border border-white/10 hover:border-cyan-400/30 backdrop-blur-md active:scale-95 transition-all cursor-pointer"
          >
            <div className="w-7 h-7 rounded-xl bg-gradient-to-tr from-cyan-500 to-purple-600 flex items-center justify-center text-white">
              <User className="w-3.5 h-3.5" />
            </div>
            <div className="text-left truncate">
              <div className="text-[10px] font-black text-white truncate">Bubble Master</div>
              <div className="text-[8px] font-mono text-pink-300/80">
                {Object.keys(profile.completedLevels).length} Levels Done
              </div>
            </div>
          </button>

          {/* High Score Preview Pill */}
          <div className="flex items-center gap-1.5 px-3 py-2 rounded-2xl bg-amber-950/40 border border-amber-400/30 backdrop-blur-md">
            <Sparkles className="w-3.5 h-3.5 text-yellow-300" />
            <div className="text-right">
              <div className="text-[8px] font-mono font-bold text-amber-300/80">BEST SCORE</div>
              <div className="text-xs font-black font-mono text-amber-200 leading-none">
                {profile.highScore.toLocaleString()}
              </div>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
};
