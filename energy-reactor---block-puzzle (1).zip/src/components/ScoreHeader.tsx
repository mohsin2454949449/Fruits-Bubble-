import React, { useEffect, useState } from 'react';
import {
  Volume2,
  VolumeX,
  RotateCcw,
  Settings,
  Zap,
  Trophy,
  Sparkles,
  Flame,
  ArrowLeft,
  CheckCircle2,
  Target,
} from 'lucide-react';
import { ScoreBreakdown } from '../types/game';

interface ScoreHeaderProps {
  level: number;
  targetScore: number;
  score: number;
  highScore: number;
  comboStreak: number;
  lastScoreInfo: (ScoreBreakdown & { linesCount: number }) | null;
  isMuted: boolean;
  onToggleSound: () => void;
  onRestart: () => void;
  onOpenSettings: () => void;
  onHome: () => void;
}

export const ScoreHeader: React.FC<ScoreHeaderProps> = ({
  level,
  targetScore,
  score,
  highScore,
  comboStreak,
  lastScoreInfo,
  isMuted,
  onToggleSound,
  onRestart,
  onOpenSettings,
  onHome,
}) => {
  // Smooth score-counting animation
  const [displayScore, setDisplayScore] = useState<number>(score);

  useEffect(() => {
    if (displayScore === score) return;
    const diff = score - displayScore;
    const duration = 280;
    const startTime = performance.now();
    const startVal = displayScore;

    let animId: number;
    const tick = (now: number) => {
      const elapsed = now - startTime;
      const progress = Math.min(elapsed / duration, 1);
      const eased = 1 - Math.pow(1 - progress, 3);
      const current = Math.round(startVal + diff * eased);
      setDisplayScore(current);

      if (progress < 1) {
        animId = requestAnimationFrame(tick);
      }
    };

    animId = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(animId);
  }, [score, displayScore]);

  // Combo multiplier label
  const activeMultiplier = comboStreak > 0 ? Math.min(comboStreak, 4) : 1;
  const progressPercent = Math.min(Math.round((score / targetScore) * 100), 100);
  const isTargetReached = score >= targetScore;

  return (
    <div className="w-full select-none mb-1">
      {/* Top Utility Bar: Navigation, Level Badge & Quick Controls */}
      <div className="flex items-center justify-between mb-1.5">
        {/* Home / Back Button & Sector Level Badge */}
        <div className="flex items-center gap-1.5">
          <button
            onClick={onHome}
            aria-label="Return to Main Menu"
            className="w-8 h-8 rounded-xl sm:rounded-2xl btn-arcade flex items-center justify-center text-pink-300 transition-all cursor-pointer active:scale-95"
            title="Main Menu"
          >
            <ArrowLeft className="w-4 h-4 text-pink-200" />
          </button>

          <div className="flex items-center gap-1.5 px-2.5 py-1 rounded-xl bg-white/[0.08] border border-pink-400/40">
            <Sparkles className="w-3.5 h-3.5 text-pink-400 fill-pink-400" />
            <span className="text-xs font-black font-['Chakra_Petch',sans-serif] text-white tracking-wide">
              LEVEL {level}
            </span>
          </div>
        </div>

        {/* Action Controls */}
        <div className="flex items-center gap-1 sm:gap-1.5">
          <button
            onClick={onToggleSound}
            aria-label="Toggle Sound"
            className="w-8 h-8 sm:w-9 sm:h-9 rounded-xl sm:rounded-2xl btn-arcade flex items-center justify-center text-pink-300 transition-all cursor-pointer"
            title={isMuted ? 'Unmute Sound' : 'Mute Sound'}
          >
            {isMuted ? <VolumeX className="w-3.5 h-3.5 text-rose-400" /> : <Volume2 className="w-3.5 h-3.5 text-pink-200" />}
          </button>

          <button
            onClick={onRestart}
            aria-label="Restart Level"
            className="w-8 h-8 sm:w-9 sm:h-9 rounded-xl sm:rounded-2xl btn-arcade flex items-center justify-center text-pink-300 transition-all cursor-pointer"
            title="Restart Level"
          >
            <RotateCcw className="w-3.5 h-3.5 text-pink-200" />
          </button>

          <button
            onClick={onOpenSettings}
            aria-label="Settings"
            className="w-8 h-8 sm:w-9 sm:h-9 rounded-xl sm:rounded-2xl btn-arcade flex items-center justify-center text-pink-300 transition-all cursor-pointer"
            title="Settings"
          >
            <Settings className="w-3.5 h-3.5 text-pink-200" />
          </button>
        </div>
      </div>

      {/* Level Target Progress Bar */}
      <div className="w-full p-1.5 rounded-xl bg-white/[0.05] border border-pink-400/30 mb-1.5 backdrop-blur-md">
        <div className="flex items-center justify-between text-[9px] font-mono font-bold mb-1 px-1">
          <div className="flex items-center gap-1 text-pink-300">
            <Target className="w-3 h-3 text-pink-400" />
            <span>LEVEL OBJECTIVE</span>
          </div>
          <div className="flex items-center gap-1.5">
            <span className={isTargetReached ? 'text-emerald-300 font-black' : 'text-amber-200'}>
              {displayScore.toLocaleString()} / {targetScore.toLocaleString()} PTS
            </span>
            <span className="text-white/60">({progressPercent}%)</span>
            {isTargetReached && (
              <CheckCircle2 className="w-3 h-3 text-emerald-400 fill-emerald-950" />
            )}
          </div>
        </div>

        {/* Progress Bar Track */}
        <div className="w-full h-2 rounded-full bg-black/50 overflow-hidden p-0.5 border border-white/10">
          <div
            className={`h-full rounded-full transition-all duration-300 ${
              isTargetReached
                ? 'bg-gradient-to-r from-emerald-400 via-teal-300 to-cyan-400 shadow-[0_0_10px_rgba(52,211,153,0.8)]'
                : 'bg-gradient-to-r from-pink-500 via-rose-400 to-amber-400 shadow-[0_0_8px_rgba(244,63,94,0.6)]'
            }`}
            style={{ width: `${progressPercent}%` }}
          />
        </div>
      </div>

      {/* Two Attractive Score Panels Side by Side */}
      <div className="grid grid-cols-2 gap-2 sm:gap-2.5">
        {/* FIRST PANEL: LEVEL SCORE */}
        <div className="relative p-2 sm:p-2.5 rounded-xl sm:rounded-2xl score-panel-vibrant overflow-hidden flex flex-col justify-center">
          <div className="flex items-center justify-between text-[10px] sm:text-[11px] font-extrabold text-pink-200 uppercase tracking-wider mb-0.5">
            <span className="flex items-center gap-1 drop-shadow-[0_1px_4px_rgba(0,0,0,0.8)]">
              <Sparkles className="w-3 h-3 text-pink-300 fill-pink-400" />
              LEVEL SCORE
            </span>
            {comboStreak >= 1 && (
              <span
                className={`px-1.5 py-0.2 rounded-full text-[8px] sm:text-[9px] font-black flex items-center gap-0.5 shadow-md font-mono tracking-tight animate-pulse ${
                  activeMultiplier >= 4
                    ? 'bg-gradient-to-r from-purple-500 to-rose-500 text-white shadow-purple-500/50'
                    : activeMultiplier === 3
                    ? 'bg-gradient-to-r from-rose-500 to-amber-500 text-white shadow-rose-500/50'
                    : activeMultiplier === 2
                    ? 'bg-gradient-to-r from-amber-400 to-orange-500 text-black shadow-amber-500/40'
                    : 'bg-pink-500/35 text-pink-200 border border-pink-300/60'
                }`}
              >
                {activeMultiplier >= 2 && <Flame className="w-2.5 h-2.5 fill-current" />}
                ×{activeMultiplier}
              </span>
            )}
          </div>

          {/* Large Numbers */}
          <div className="text-xl sm:text-2xl font-black text-white tracking-tight tabular-nums font-mono drop-shadow-[0_0_14px_rgba(244,63,94,0.7)] leading-none my-0.5">
            {displayScore.toLocaleString()}
          </div>

          {/* Base Points Feedback */}
          {lastScoreInfo && lastScoreInfo.finalPoints > 0 ? (
            <div className="text-[8px] sm:text-[9px] font-mono font-bold text-pink-200 tracking-wide mt-0.5 truncate drop-shadow-[0_1px_2px_rgba(0,0,0,0.8)]">
              +{lastScoreInfo.finalPoints} ({lastScoreInfo.baseScore} × {lastScoreInfo.multiplier})
            </div>
          ) : (
            <div className="text-[8px] sm:text-[9px] font-mono text-pink-300/50 tracking-wider mt-0.5">
              POP FRUITS FOR PTS
            </div>
          )}

          {/* Bottom Glossy Energy Highlight */}
          <div className="absolute bottom-0 left-0 right-0 h-1 bg-gradient-to-r from-pink-500 via-rose-400 to-amber-400" />
        </div>

        {/* SECOND PANEL: HIGHER SCORE */}
        <div className="relative p-2 sm:p-2.5 rounded-xl sm:rounded-2xl higher-score-panel overflow-hidden flex flex-col justify-center">
          <div className="flex items-center justify-between text-[10px] sm:text-[11px] font-extrabold text-amber-200 uppercase tracking-wider mb-0.5">
            <span className="flex items-center gap-1 drop-shadow-[0_1px_4px_rgba(0,0,0,0.8)]">
              <Trophy className="w-3 h-3 text-amber-300 fill-amber-400" />
              HIGHER SCORE
            </span>
            <span className="text-[9px] text-amber-300/80 font-mono flex items-center gap-0.5">
              <Sparkles className="w-2 h-2 text-yellow-300" /> PEAK
            </span>
          </div>

          {/* Large Numbers */}
          <div className="text-xl sm:text-2xl font-black text-amber-100 tracking-tight tabular-nums font-mono drop-shadow-[0_0_14px_rgba(251,191,36,0.65)] leading-none my-0.5">
            {highScore.toLocaleString()}
          </div>

          <div className="text-[8px] sm:text-[9px] font-mono font-bold text-amber-300/70 tracking-wider mt-0.5">
            ALL-TIME BEST
          </div>

          {/* Bottom Glossy Energy Highlight */}
          <div className="absolute bottom-0 left-0 right-0 h-1 bg-gradient-to-r from-amber-400 via-yellow-300 to-amber-500" />
        </div>
      </div>
    </div>
  );
};
