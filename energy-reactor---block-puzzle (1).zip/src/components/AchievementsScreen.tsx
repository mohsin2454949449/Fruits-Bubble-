import React, { useState } from 'react';
import {
  ArrowLeft,
  Trophy,
  Coins,
  CheckCircle2,
  Zap,
  Flame,
  Sparkles,
  Grid3X3,
  Award,
} from 'lucide-react';
import { PlayerProfile, Achievement } from '../types/game';
import { ACHIEVEMENTS } from '../utils/gameContent';
import { sound } from '../utils/audio';

interface AchievementsScreenProps {
  profile: PlayerProfile;
  onClaimAchievement: (achievement: Achievement) => void;
  onBack: () => void;
}

export const AchievementsScreen: React.FC<AchievementsScreenProps> = ({
  profile,
  onClaimAchievement,
  onBack,
}) => {
  const [claimFeedback, setClaimFeedback] = useState<string | null>(null);

  const getProgress = (ach: Achievement): number => {
    if (ach.id === 'ach_first_clear') return profile.totalLines > 0 ? 1 : 0;
    if (ach.id === 'ach_lines_25') return profile.totalLines;
    if (ach.id === 'ach_lines_100') return profile.totalLines;
    if (ach.id === 'ach_combo_3') return profile.maxCombo;
    if (ach.id === 'ach_level_5') return profile.level > 5 ? 5 : Object.keys(profile.completedLevels).length;
    if (ach.id === 'ach_level_10') return profile.level > 10 ? 10 : Object.keys(profile.completedLevels).length;
    if (ach.id === 'ach_score_5000') return profile.highScore;
    if (ach.id === 'ach_blocks_100') return profile.totalBlocks;
    return 0;
  };

  const handleClaim = (ach: Achievement) => {
    sound.playCoin();
    onClaimAchievement(ach);
    setClaimFeedback(`Claimed +${ach.rewardCoins} Coins!`);
    setTimeout(() => setClaimFeedback(null), 2500);
  };

  const getIcon = (iconName: string) => {
    switch (iconName) {
      case 'Zap':
        return <Zap className="w-5 h-5 text-cyan-300" />;
      case 'Flame':
        return <Flame className="w-5 h-5 text-amber-400" />;
      case 'Sparkles':
        return <Sparkles className="w-5 h-5 text-yellow-300" />;
      case 'Grid3X3':
        return <Grid3X3 className="w-5 h-5 text-purple-300" />;
      case 'Award':
        return <Award className="w-5 h-5 text-rose-300" />;
      default:
        return <Trophy className="w-5 h-5 text-yellow-400" />;
    }
  };

  return (
    <div className="relative w-full h-[100dvh] max-h-[100dvh] flex flex-col justify-between px-3.5 pt-[max(10px,env(safe-area-inset-top))] pb-[max(12px,env(safe-area-inset-bottom))] text-white select-none overflow-hidden animate-fade-in max-w-[430px] mx-auto">
      {/* Top Header */}
      <header className="w-full flex items-center justify-between shrink-0 mb-3 z-20">
        <button
          onClick={onBack}
          className="w-9 h-9 rounded-2xl btn-arcade flex items-center justify-center text-pink-300 active:scale-95 transition-transform cursor-pointer"
          aria-label="Back"
        >
          <ArrowLeft className="w-4 h-4 text-pink-200" />
        </button>

        <div className="text-center">
          <h2 className="text-lg font-black font-['Chakra_Petch',sans-serif] tracking-wider text-white uppercase drop-shadow-[0_2px_10px_rgba(255,51,102,0.4)]">
            TROPHIES & CHALLENGES
          </h2>
          <p className="text-[9px] font-mono font-bold tracking-widest text-pink-300 uppercase">
            EARN COINS & CHALLENGES
          </p>
        </div>

        <div className="flex items-center gap-1.5">
          <div className="flex items-center gap-1 px-2 py-1 rounded-xl bg-amber-950/60 border border-amber-400/40 text-[11px] font-black font-mono text-amber-200">
            <Coins className="w-3 h-3 text-amber-300 fill-amber-400" />
            <span>{profile.coins.toLocaleString()}</span>
          </div>
        </div>
      </header>

      {/* Floating Notice */}
      {claimFeedback && (
        <div className="w-full py-1.5 px-3 mb-2 rounded-xl bg-gradient-to-r from-amber-500/30 to-yellow-400/30 border border-amber-400 text-amber-200 text-xs font-mono font-black text-center animate-bounce-in shadow-lg z-30">
          {claimFeedback}
        </div>
      )}

      {/* Achievements List */}
      <div className="flex-1 overflow-y-auto space-y-2.5 pr-1 z-10 overscroll-contain">
        {ACHIEVEMENTS.map((ach) => {
          const rawProgress = getProgress(ach);
          const current = Math.min(rawProgress, ach.target);
          const isDone = rawProgress >= ach.target;
          const isClaimed = profile.claimedAchievements.includes(ach.id);
          const percentage = Math.round((current / ach.target) * 100);

          return (
            <div
              key={ach.id}
              className={`p-3.5 rounded-2xl border transition-all flex items-center justify-between gap-3 ${
                isClaimed
                  ? 'bg-white/[0.02] border-white/5 opacity-70'
                  : isDone
                  ? 'bg-gradient-to-r from-cyan-950/70 via-purple-950/60 to-black/80 border-cyan-400 shadow-[0_0_18px_rgba(0,240,255,0.3)] ring-1 ring-cyan-300/40'
                  : 'bg-white/[0.04] border-white/10'
              }`}
            >
              {/* Icon & Details */}
              <div className="flex items-center gap-3 flex-1 min-w-0">
                <div
                  className={`w-11 h-11 rounded-2xl flex items-center justify-center shrink-0 border ${
                    isDone
                      ? 'bg-cyan-500/20 border-cyan-400/60 shadow-md'
                      : 'bg-white/[0.06] border-white/10'
                  }`}
                >
                  {getIcon(ach.icon)}
                </div>

                <div className="text-left flex-1 min-w-0">
                  <div className="flex items-center gap-1.5">
                    <span className="text-sm font-black text-white font-['Chakra_Petch',sans-serif] truncate">
                      {ach.title}
                    </span>
                  </div>
                  <p className="text-[10px] text-purple-200/80 leading-tight truncate">
                    {ach.description}
                  </p>

                  {/* Progress Bar */}
                  <div className="mt-1.5 w-full">
                    <div className="flex items-center justify-between text-[9px] font-mono text-cyan-300/80 mb-0.5">
                      <span>Progress</span>
                      <span>
                        {current.toLocaleString()} / {ach.target.toLocaleString()}
                      </span>
                    </div>
                    <div className="w-full h-1.5 rounded-full bg-white/10 overflow-hidden">
                      <div
                        className={`h-full rounded-full transition-all duration-300 ${
                          isDone
                            ? 'bg-gradient-to-r from-cyan-400 to-sky-300'
                            : 'bg-gradient-to-r from-purple-500 to-cyan-500'
                        }`}
                        style={{ width: `${percentage}%` }}
                      />
                    </div>
                  </div>
                </div>
              </div>

              {/* Action Column */}
              <div className="shrink-0">
                {isClaimed ? (
                  <div className="flex items-center gap-1 text-[10px] font-mono font-bold text-emerald-400 px-2 py-1 rounded-xl bg-emerald-950/40 border border-emerald-500/30">
                    <CheckCircle2 className="w-3.5 h-3.5" />
                    <span>DONE</span>
                  </div>
                ) : isDone ? (
                  <button
                    onClick={() => handleClaim(ach)}
                    className="px-3 py-2 rounded-xl btn-cta-glow text-black font-black text-xs uppercase flex items-center gap-1 shadow-md active:scale-95 transition-transform cursor-pointer"
                  >
                    <Coins className="w-3.5 h-3.5 text-black fill-black" />
                    <span>CLAIM</span>
                  </button>
                ) : (
                  <div className="text-right text-[10px] font-mono font-bold text-amber-300/70">
                    +{ach.rewardCoins}C
                  </div>
                )}
              </div>
            </div>
          );
        })}
      </div>

      {/* Bottom Back Button */}
      <footer className="w-full pt-3 shrink-0 z-20 border-t border-white/10">
        <button
          onClick={onBack}
          className="w-full py-3 px-4 rounded-2xl btn-arcade flex items-center justify-center gap-2 text-xs font-black uppercase text-cyan-300 active:scale-95 transition-transform cursor-pointer"
        >
          <ArrowLeft className="w-4 h-4 text-cyan-200" />
          <span>Back to Main Menu</span>
        </button>
      </footer>
    </div>
  );
};
