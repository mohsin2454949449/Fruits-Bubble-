import React from 'react';
import { BoardMatrix, PlacementPreview, ReactorColor } from '../types/game';
import { ReactorBlock } from './ReactorBlock';
import { Sparkles } from 'lucide-react';

import { CORE_BOX_THEMES } from '../utils/boxThemes';

interface GameBoardProps {
  board: BoardMatrix;
  preview: PlacementPreview | null;
  draggedPieceColor: ReactorColor | null;
  boardRef: React.RefObject<HTMLDivElement | null>;
  onCellClick?: (row: number, col: number) => void;
  hammerActive?: boolean;
  boardTheme?: string;
  blockSkin?: string;
}

export const GameBoard: React.FC<GameBoardProps> = ({
  board,
  preview,
  draggedPieceColor,
  boardRef,
  onCellClick,
  hammerActive = false,
  boardTheme = 'board_default',
  blockSkin = 'core_fruit_bubble',
}) => {
  // Find active Core Box Theme
  const activeBoxTheme = React.useMemo(() => {
    return (
      CORE_BOX_THEMES.find(
        (b) => b.id === boardTheme || (boardTheme === 'board_default' && b.id === 'box_default')
      ) || CORE_BOX_THEMES[0]
    );
  }, [boardTheme]);

  // Set of cells that are part of the preview piece
  const previewCells = React.useMemo(() => {
    const set = new Set<string>();
    if (preview && preview.valid) {
      preview.cells.forEach(({ r, c }) => set.add(`${r},${c}`));
    }
    return set;
  }, [preview]);

  // Set of rows that will clear on drop
  const clearingRows = React.useMemo(() => {
    return new Set(preview?.clearingRows || []);
  }, [preview]);

  // Set of columns that will clear on drop
  const clearingCols = React.useMemo(() => {
    return new Set(preview?.clearingCols || []);
  }, [preview]);

  const casingStyle = activeBoxTheme.casingStyle;
  const gridBorderColor = activeBoxTheme.gridBorderColor;
  const emptyCellBorder = activeBoxTheme.emptyCellBorder;

  return (
    <div
      className={`relative game-board-container aspect-square mx-auto p-1.5 sm:p-2 rounded-2xl sm:rounded-3xl bg-gradient-to-b ${casingStyle} border-2 shadow-[inset_0_1px_1px_rgba(255,255,255,0.3)] backdrop-blur-xl select-none transition-all duration-300`}
    >
      {/* Decorative Corner Fruit Bubble Dots */}
      <div className={`absolute top-2 left-2 w-2.5 h-2.5 rounded-full bg-gradient-to-br ${activeBoxTheme.cornerDots[0]} shadow-[0_0_8px_rgba(255,75,130,0.8)] pointer-events-none`} />
      <div className={`absolute top-2 right-2 w-2.5 h-2.5 rounded-full bg-gradient-to-br ${activeBoxTheme.cornerDots[1]} shadow-[0_0_8px_rgba(56,189,248,0.8)] pointer-events-none`} />
      <div className={`absolute bottom-2 left-2 w-2.5 h-2.5 rounded-full bg-gradient-to-br ${activeBoxTheme.cornerDots[2]} shadow-[0_0_8px_rgba(52,211,153,0.8)] pointer-events-none`} />
      <div className={`absolute bottom-2 right-2 w-2.5 h-2.5 rounded-full bg-gradient-to-br ${activeBoxTheme.cornerDots[3]} shadow-[0_0_8px_rgba(251,191,36,0.8)] pointer-events-none`} />

      {/* Hammer Mode Active Banner Indicator */}
      {hammerActive && (
        <div className="absolute -top-3.5 left-1/2 -translate-x-1/2 z-30 px-3 py-0.5 rounded-full bg-rose-950 border border-rose-400 text-[9px] font-mono font-black text-rose-200 tracking-wider uppercase animate-bounce shadow-lg flex items-center gap-1">
          <Sparkles className="w-3 h-3 text-rose-300 animate-spin" />
          <span>TAP ANY FRUIT TO POP</span>
        </div>
      )}

      {/* 7x7 Fruit Bubble Grid Container (49 cells) */}
      <div
        ref={boardRef}
        className={`w-full h-full grid grid-cols-7 grid-rows-7 gap-1 p-1 sm:p-1.5 bg-[#0b0518]/90 rounded-xl sm:rounded-2xl border ${gridBorderColor} relative overflow-hidden shadow-inner`}
        style={{
          touchAction: 'none',
          gridTemplateColumns: 'repeat(7, minmax(0, 1fr))',
          gridTemplateRows: 'repeat(7, minmax(0, 1fr))',
        }}
      >
        {board.map((row, r) =>
          row.map((cell, c) => {
            const isPreviewCell = previewCells.has(`${r},${c}`);
            const willClear = clearingRows.has(r) || clearingCols.has(c);

            return (
              <div
                key={`${r}-${c}`}
                onClick={() => onCellClick?.(r, c)}
                className={`relative aspect-square rounded-[6px] sm:rounded-[8px] flex items-center justify-center transition-all duration-150 cursor-pointer overflow-hidden ${
                  cell.filled
                    ? hammerActive
                      ? 'ring-2 ring-rose-400 border border-rose-500 shadow-[0_0_12px_rgba(244,63,94,0.8)] animate-pulse'
                      : 'bg-transparent border border-transparent'
                    : willClear
                    ? 'bg-pink-400/35 border-2 border-pink-300 shadow-[0_0_14px_rgba(244,63,94,0.7)]'
                    : `bg-[#180e32]/85 border ${emptyCellBorder} shadow-[inset_0_2px_4px_rgba(0,0,0,0.55)]`
                }`}
                data-row={r}
                data-col={c}
              >
                {/* Placed Fruit Bubble */}
                {cell.filled && cell.color && (
                  <div
                    className={`w-full h-full transition-transform duration-200 ${
                      willClear ? 'animate-pulse scale-95 brightness-125' : ''
                    }`}
                  >
                    <ReactorBlock
                      color={cell.color}
                      theme={blockSkin}
                      isClearing={cell.clearing}
                      glow={!cell.clearing}
                    />
                  </div>
                )}

                {/* Ghost Placement Preview Bubble */}
                {isPreviewCell && draggedPieceColor && (
                  <div className="w-full h-full animate-pulse pointer-events-none">
                    <ReactorBlock
                      color={draggedPieceColor}
                      theme={blockSkin}
                      isGhost={true}
                      glow={false}
                    />
                  </div>
                )}

                {/* Clearing line highlight overlay */}
                {willClear && (
                  <div className="absolute inset-0 bg-gradient-to-r from-pink-400/30 via-purple-300/30 to-pink-400/30 rounded pointer-events-none animate-pulse" />
                )}
              </div>
            );
          })
        )}
      </div>
    </div>
  );
};

