import React from 'react';
import {
  Trophy,
  Coins,
  ArrowRight,
  Home,
  RotateCcw,
  Star,
  Sparkles,
  Zap,
  Gift,
  Tv,
  CheckCircle2,
} from 'lucide-react';
import { LevelData } from '../types/game';
import { sound } from '../utils/audio';

interface LevelCompleteModalProps {
  levelData: LevelData;
  score: number;
  rewardCoins: number;
  onContinue: () => void;
  onReplay: () => void;
  onHome: () => void;
  isMilestone?: boolean;
  onOpenMilestoneChest?: () => void;
  onWatchBonusAd?: () => void;
  hasClaimedAdBonus?: boolean;
}

export const LevelCompleteModal: React.FC<LevelCompleteModalProps> = ({
  levelData,
  score,
  rewardCoins,
  onContinue,
  onReplay,
  onHome,
  isMilestone = false,
  onOpenMilestoneChest,
  onWatchBonusAd,
  hasClaimedAdBonus = false,
}) => {
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/90 backdrop-blur-xl animate-fade-in select-none">
      <div className="relative w-full max-w-sm rounded-3xl glass-panel-colorful p-6 text-center overflow-hidden shadow-[0_0_70px_rgba(0,240,255,0.45)] border border-cyan-400/50">
        {/* Ambient Top Glow Orbs */}
        <div className="absolute -top-16 left-1/2 -translate-x-1/2 w-64 h-36 bg-gradient-to-r from-cyan-400/40 via-amber-400/40 to-pink-500/40 blur-3xl pointer-events-none" />

        {/* Futuristic Corner Brackets */}
        <div className="absolute top-3 left-3 w-3 h-3 border-t-2 border-l-2 border-cyan-300 drop-shadow-[0_0_8px_rgba(0,240,255,0.9)]" />
        <div className="absolute top-3 right-3 w-3 h-3 border-t-2 border-r-2 border-cyan-300 drop-shadow-[0_0_8px_rgba(0,240,255,0.9)]" />
        <div className="absolute bottom-3 left-3 w-3 h-3 border-b-2 border-l-2 border-cyan-300 drop-shadow-[0_0_8px_rgba(0,240,255,0.9)]" />
        <div className="absolute bottom-3 right-3 w-3 h-3 border-b-2 border-r-2 border-cyan-300 drop-shadow-[0_0_8px_rgba(0,240,255,0.9)]" />

        {/* Trophy Hero Icon with Golden Burst */}
        <div className="relative w-20 h-20 mx-auto mb-2 flex items-center justify-center">
          <div className="absolute inset-0 rounded-full bg-gradient-to-tr from-amber-400/30 to-yellow-300/30 blur-xl animate-pulse" />
          <div className="w-16 h-16 rounded-3xl bg-gradient-to-tr from-amber-400 to-yellow-500 flex items-center justify-center text-black shadow-[0_0_25px_rgba(251,191,36,0.8)] animate-bounce-in">
            <Trophy className="w-9 h-9 text-black fill-black" />
          </div>
        </div>

        {/* Stars Display */}
        <div className="flex items-center justify-center gap-2 mb-2 animate-bounce-in">
          {[1, 2, 3].map((starIndex) => (
            <div
              key={starIndex}
              className="p-1 rounded-xl bg-white/10 border border-yellow-400/50 shadow-md"
            >
              <Star className="w-6 h-6 text-yellow-300 fill-yellow-400 animate-pulse" />
            </div>
          ))}
        </div>

        {/* Heading & Tag */}
        <div className="inline-block px-3 py-0.5 mb-1.5 rounded-full bg-pink-950/90 border border-pink-400/70 text-[10px] font-mono font-bold tracking-widest text-pink-200 uppercase shadow-md">
          LEVEL {levelData.levelNumber} CLEARED
        </div>

        <h2 className="text-2xl sm:text-3xl font-black tracking-wider text-white font-['Chakra_Petch',sans-serif] uppercase mb-0.5 drop-shadow-[0_2px_14px_rgba(255,51,102,0.8)]">
          SWEET VICTORY!
        </h2>
        <p className="text-[10px] font-extrabold tracking-[0.22em] text-pink-300 uppercase font-mono mb-4">
          TARGET {levelData.targetScore.toLocaleString()} PTS REACHED
        </p>

        {/* Score & Rewards Card */}
        <div className="p-3.5 mb-4 rounded-2xl score-panel-vibrant shadow-inner space-y-2">
          <div>
            <span className="block text-[9px] font-extrabold text-pink-200/90 uppercase tracking-widest font-mono">
              Final Juice Score
            </span>
            <span className="text-2xl sm:text-3xl font-black text-white font-mono tracking-tight drop-shadow-[0_0_16px_rgba(255,45,85,0.8)]">
              {score.toLocaleString()} PTS
            </span>
          </div>

          {/* Rewards Badge: Coins & Level Stars */}
          <div className="pt-2 border-t border-pink-400/30 flex items-center justify-center gap-3">
            <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-amber-950/70 border border-amber-400/50 shadow-sm">
              <Coins className="w-4 h-4 text-amber-300 fill-amber-400" />
              <span className="text-xs font-black font-mono text-amber-200">
                +{rewardCoins} Coins
              </span>
            </div>
            <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-yellow-950/70 border border-yellow-400/50 shadow-sm">
              <Star className="w-4 h-4 text-yellow-300 fill-yellow-400" />
              <span className="text-xs font-black font-mono text-yellow-200">
                +3 Stars
              </span>
            </div>
          </div>
        </div>

        {/* Milestone Mystery Chest Action */}
        {isMilestone && onOpenMilestoneChest && (
          <button
            onClick={() => {
              sound.playClick();
              onOpenMilestoneChest();
            }}
            className="w-full py-3.5 px-4 mb-2.5 rounded-2xl font-black text-sm uppercase tracking-wider text-black bg-gradient-to-r from-amber-300 via-yellow-400 to-amber-500 border border-yellow-200 flex items-center justify-center gap-2 cursor-pointer shadow-[0_6px_25px_rgba(251,191,36,0.7)] animate-pulse active:scale-95 transition-transform"
          >
            <Gift className="w-5 h-5 fill-black" />
            <span>Open Milestone {levelData.levelNumber} Chest!</span>
          </button>
        )}

        {/* Optional Voluntary Rewarded Ad Bonus */}
        {onWatchBonusAd && (
          <div className="mb-2.5">
            {hasClaimedAdBonus ? (
              <div className="w-full py-2.5 px-3 rounded-2xl bg-emerald-950/60 border border-emerald-400/40 flex items-center justify-center gap-2 text-emerald-300 text-xs font-black uppercase font-mono">
                <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                <span>+500 Bonus Ad Coins Claimed!</span>
              </div>
            ) : (
              <button
                onClick={() => {
                  sound.playClick();
                  onWatchBonusAd();
                }}
                className="w-full py-2.5 px-3 rounded-2xl bg-amber-950/60 border border-amber-400/50 hover:border-amber-300 flex items-center justify-between text-amber-200 active:scale-95 transition-all cursor-pointer shadow-sm"
              >
                <div className="flex items-center gap-2">
                  <div className="p-1 rounded-lg bg-amber-400/20 text-amber-300">
                    <Tv className="w-3.5 h-3.5" />
                  </div>
                  <span className="text-[11px] font-black uppercase tracking-wider">
                    Watch Ad for Bonus
                  </span>
                </div>
                <div className="flex items-center gap-1 px-2 py-0.5 rounded-full bg-amber-400/20 text-yellow-300 font-mono text-xs font-black">
                  <Coins className="w-3 h-3 fill-amber-400" />
                  <span>+500</span>
                </div>
              </button>
            )}
          </div>
        )}

        {/* Primary Action Button: CONTINUE */}
        <button
          onClick={() => {
            sound.playClick();
            onContinue();
          }}
          className="w-full py-4 px-4 mb-2.5 rounded-2xl font-black text-sm uppercase tracking-wider text-white btn-cta-glow flex items-center justify-center gap-2 cursor-pointer shadow-[0_8px_30px_rgba(255,51,102,0.65)] active:scale-95 transition-transform"
        >
          <span>Continue to Level {levelData.levelNumber + 1}</span>
          <ArrowRight className="w-4 h-4 text-white stroke-[3]" />
        </button>

        {/* Secondary Actions: REPLAY & HOME */}
        <div className="grid grid-cols-2 gap-2">
          <button
            onClick={() => {
              sound.playClick();
              onReplay();
            }}
            className="py-2.5 px-3 rounded-2xl btn-arcade flex items-center justify-center gap-1.5 text-xs font-bold text-pink-200 uppercase active:scale-95 transition-transform cursor-pointer"
          >
            <RotateCcw className="w-3.5 h-3.5 text-pink-300" />
            <span>Replay</span>
          </button>

          <button
            onClick={() => {
              sound.playClick();
              onHome();
            }}
            className="py-2.5 px-3 rounded-2xl btn-arcade flex items-center justify-center gap-1.5 text-xs font-bold text-pink-200 uppercase active:scale-95 transition-transform cursor-pointer"
          >
            <Home className="w-3.5 h-3.5 text-pink-300" />
            <span>Home</span>
          </button>
        </div>
      </div>
    </div>
  );
};
