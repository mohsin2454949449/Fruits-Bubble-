import React, { useState } from 'react';
import {
  ArrowLeft,
  Gift,
  Coins,
  CheckCircle2,
  Sparkles,
  Calendar,
  Zap,
} from 'lucide-react';
import { PlayerProfile, DailyGift } from '../types/game';
import { DAILY_GIFTS } from '../utils/gameContent';
import { isDailyGiftClaimable } from '../utils/saveManager';
import { sound } from '../utils/audio';

interface DailyGiftsScreenProps {
  profile: PlayerProfile;
  onClaimReward: (gift: DailyGift) => void;
  onBack: () => void;
}

export const DailyGiftsScreen: React.FC<DailyGiftsScreenProps> = ({
  profile,
  onClaimReward,
  onBack,
}) => {
  const isClaimable = isDailyGiftClaimable(profile.lastDailyClaimDate);
  const currentStreak = profile.dailyStreak % 7; // 0 to 6 index (0 is Day 1)
  const todayGift = DAILY_GIFTS[currentStreak] || DAILY_GIFTS[0];

  const [claimFeedback, setClaimFeedback] = useState<string | null>(null);

  const handleClaim = () => {
    if (!isClaimable) return;
    sound.playCoin();
    onClaimReward(todayGift);
    setClaimFeedback(`Claimed +${todayGift.coins} Coins! ${todayGift.specialReward ? '(' + todayGift.specialReward + ')' : ''}`);
  };

  return (
    <div className="relative w-full h-[100dvh] max-h-[100dvh] flex flex-col justify-between px-3.5 pt-[max(10px,env(safe-area-inset-top))] pb-[max(12px,env(safe-area-inset-bottom))] text-white select-none overflow-hidden animate-fade-in max-w-[430px] mx-auto">
      {/* Top Header */}
      <header className="w-full flex items-center justify-between shrink-0 mb-3 z-20">
        <button
          onClick={onBack}
          className="w-9 h-9 rounded-2xl btn-arcade flex items-center justify-center text-pink-300 active:scale-95 transition-transform cursor-pointer"
          aria-label="Back"
        >
          <ArrowLeft className="w-4 h-4 text-pink-200" />
        </button>

        <div className="text-center">
          <h2 className="text-lg font-black font-['Chakra_Petch',sans-serif] tracking-wider text-white uppercase drop-shadow-[0_2px_10px_rgba(255,51,102,0.4)]">
            DAILY FRUIT GIFTS
          </h2>
          <p className="text-[9px] font-mono font-bold tracking-widest text-pink-300 uppercase">
            HARVEST YOUR STREAK
          </p>
        </div>

        <div className="flex items-center gap-1 px-2.5 py-1.5 rounded-2xl bg-amber-950/60 border border-amber-400/40 font-mono text-xs font-black text-amber-200">
          <Calendar className="w-3.5 h-3.5 text-amber-300" />
          <span>Day {currentStreak + 1}/7</span>
        </div>
      </header>

      {/* Floating Success Notice */}
      {claimFeedback && (
        <div className="w-full py-2 px-3 mb-2 rounded-xl bg-gradient-to-r from-amber-500/30 to-yellow-400/30 border border-amber-400 text-amber-200 text-xs font-mono font-black text-center animate-bounce-in shadow-lg z-30">
          {claimFeedback}
        </div>
      )}

      {/* 7-Day Rewards Grid */}
      <div className="flex-1 overflow-y-auto space-y-2 pr-1 z-10 overscroll-contain">
        <div className="grid grid-cols-2 gap-2.5">
          {DAILY_GIFTS.slice(0, 6).map((gift, index) => {
            const isToday = index === currentStreak;
            const isPast = index < currentStreak || (!isClaimable && isToday);

            return (
              <div
                key={gift.day}
                className={`p-3 rounded-2xl border transition-all text-center flex flex-col justify-between items-center ${
                  isToday && isClaimable
                    ? 'bg-gradient-to-b from-cyan-950/90 to-purple-950/90 border-cyan-400 shadow-[0_0_20px_rgba(0,240,255,0.4)] ring-2 ring-cyan-400/40 animate-pulse-glow'
                    : isPast
                    ? 'bg-white/[0.03] border-emerald-400/30 opacity-70'
                    : 'bg-white/[0.04] border-white/10'
                }`}
              >
                <div className="w-full flex items-center justify-between text-[10px] font-mono">
                  <span className="font-bold text-white/70">{gift.label}</span>
                  {isPast ? (
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                  ) : isToday ? (
                    <span className="px-1.5 py-0.2 rounded-full text-[8px] font-black bg-cyan-400 text-black">
                      TODAY
                    </span>
                  ) : (
                    <Gift className="w-3.5 h-3.5 text-white/30" />
                  )}
                </div>

                <div className="my-2 p-2 rounded-2xl bg-white/[0.05] border border-white/10">
                  <Gift className="w-7 h-7 text-amber-300" />
                </div>

                <div className="space-y-0.5">
                  <div className="flex items-center justify-center gap-1 text-xs font-mono font-black text-amber-300">
                    <Coins className="w-3.5 h-3.5 fill-amber-400" />
                    <span>+{gift.coins}</span>
                  </div>
                  {gift.specialReward && (
                    <div className="text-[9px] font-bold text-cyan-300 truncate">
                      {gift.specialReward}
                    </div>
                  )}
                </div>
              </div>
            );
          })}
        </div>

        {/* Day 7 Grand Jackpot Card */}
        {(() => {
          const day7 = DAILY_GIFTS[6];
          const isToday = currentStreak === 6;
          const isPast = !isClaimable && isToday;

          return (
            <div
              className={`p-3.5 rounded-2xl border transition-all text-center flex items-center justify-between gap-3 ${
                isToday && isClaimable
                  ? 'bg-gradient-to-r from-amber-950/80 via-yellow-950/80 to-purple-950/80 border-amber-400 shadow-[0_0_25px_rgba(251,191,36,0.5)] ring-2 ring-amber-300/60 animate-pulse'
                  : 'bg-white/[0.04] border-amber-400/30'
              }`}
            >
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-amber-400 to-yellow-500 flex items-center justify-center text-black shadow-lg">
                  <Sparkles className="w-6 h-6 text-black fill-black" />
                </div>
                <div className="text-left">
                  <div className="text-xs font-black text-amber-200 uppercase font-mono">
                    Day 7 Grand Mystery Cache
                  </div>
                  <div className="text-sm font-black text-white font-mono">
                    +{day7.coins.toLocaleString()} Coins {day7.specialReward ? '+ ' + day7.specialReward : ''}
                  </div>
                </div>
              </div>

              {isPast ? (
                <CheckCircle2 className="w-6 h-6 text-emerald-400" />
              ) : isToday ? (
                <span className="px-2 py-1 rounded-xl text-[9px] font-black bg-amber-400 text-black">
                  UNLOCKED
                </span>
              ) : (
                <span className="text-xs font-mono text-white/40">Locked</span>
              )}
            </div>
          );
        })()}
      </div>

      {/* Claim Action Bar */}
      <footer className="w-full pt-3 shrink-0 z-20 border-t border-white/10 space-y-2">
        <button
          onClick={handleClaim}
          disabled={!isClaimable}
          className={`w-full py-4 px-4 rounded-2xl font-black text-sm uppercase tracking-wider flex items-center justify-center gap-2 transition-all cursor-pointer ${
            isClaimable
              ? 'btn-cta-glow text-black shadow-[0_8px_25px_rgba(0,240,255,0.6)] active:scale-95'
              : 'bg-white/[0.06] border border-white/10 text-white/40 cursor-not-allowed'
          }`}
        >
          {isClaimable ? (
            <>
              <Gift className="w-4 h-4 text-black" />
              <span>Claim Today's Daily Gift</span>
            </>
          ) : (
            <>
              <CheckCircle2 className="w-4 h-4 text-emerald-400" />
              <span>Claimed! Return Tomorrow</span>
            </>
          )}
        </button>

        <button
          onClick={onBack}
          className="w-full py-2.5 px-4 rounded-2xl btn-arcade flex items-center justify-center gap-2 text-xs font-black uppercase text-cyan-300 active:scale-95 transition-transform cursor-pointer"
        >
          <ArrowLeft className="w-4 h-4 text-cyan-200" />
          <span>Back to Main Menu</span>
        </button>
      </footer>
    </div>
  );
};
