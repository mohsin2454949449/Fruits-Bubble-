import React from 'react';
import { BACKGROUND_THEMES, BgThemeItem } from '../utils/bgThemes';

interface BackgroundRendererProps {
  themeId?: string;
}

export const BackgroundRenderer: React.FC<BackgroundRendererProps> = ({
  themeId = 'bg_cosmic',
}) => {
  const currentTheme =
    BACKGROUND_THEMES.find((t) => t.id === themeId) || BACKGROUND_THEMES[0];

  return (
    <div className="fixed inset-0 pointer-events-none -z-10 overflow-hidden select-none">
      {/* 1. Base Full-Screen Gradient */}
      <div
        className={`absolute inset-0 bg-gradient-to-b ${currentTheme.gradient} transition-colors duration-700`}
      />

      {/* 2. Three Distinct Dynamic Ambient Glow Orbs */}
      <div
        className={`absolute -top-28 left-1/2 -translate-x-1/2 w-[480px] h-[320px] rounded-full blur-[105px] ${currentTheme.orb1.class} transition-all duration-700`}
        style={currentTheme.orb1.style}
      />
      <div
        className={`absolute top-1/3 -left-28 w-[360px] h-[360px] rounded-full blur-[115px] ${currentTheme.orb2.class} transition-all duration-700`}
        style={currentTheme.orb2.style}
      />
      <div
        className={`absolute bottom-8 -right-28 w-[380px] h-[380px] rounded-full blur-[115px] ${currentTheme.orb3.class} transition-all duration-700`}
        style={currentTheme.orb3.style}
      />

      {/* 3. Thematic Pattern Overlays */}
      {currentTheme.patternType === 'grid' && (
        <div className="absolute inset-0 opacity-20 bg-[linear-gradient(to_right,rgba(236,72,153,0.15)_1px,transparent_1px),linear-gradient(to_bottom,rgba(6,182,212,0.15)_1px,transparent_1px)] bg-[size:32px_32px]" />
      )}

      {currentTheme.patternType === 'stars' && (
        <div className="absolute inset-0 opacity-30 bg-[radial-gradient(rgba(255,255,255,0.22)_1px,transparent_1px)] bg-[size:36px_36px]" />
      )}

      {currentTheme.patternType === 'sparkles' && (
        <div className="absolute inset-0 opacity-25 bg-[radial-gradient(rgba(251,191,36,0.25)_1.5px,transparent_1.5px)] bg-[size:44px_44px]" />
      )}

      {currentTheme.patternType === 'leaves' && (
        <div className="absolute inset-0 opacity-20 bg-[radial-gradient(rgba(52,211,153,0.2)_1.5px,transparent_1.5px)] bg-[size:38px_38px]" />
      )}

      {currentTheme.patternType === 'clouds' && (
        <div className="absolute inset-0 opacity-25 bg-[radial-gradient(rgba(244,114,182,0.22)_2px,transparent_2px)] bg-[size:48px_48px]" />
      )}

      {(!currentTheme.patternType || currentTheme.patternType === 'bubbles') && (
        <div className="absolute inset-0 opacity-20 bg-[radial-gradient(rgba(255,255,255,0.15)_1.5px,transparent_1.5px)] bg-[size:30px_30px]" />
      )}
    </div>
  );
};
