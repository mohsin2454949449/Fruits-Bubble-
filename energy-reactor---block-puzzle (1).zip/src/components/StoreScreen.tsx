import React, { useState, useMemo } from 'react';
import {
  ArrowLeft,
  Coins,
  Star,
  Check,
  Sparkles,
  Lock,
  Eye,
  X,
  AlertCircle,
  HelpCircle,
  Layers,
  Box,
  Image as ImageIcon,
  Tv,
} from 'lucide-react';
import { PlayerProfile, ReactorColor } from '../types/game';
import { CORE_THEMES, CoreThemeItem, CoreRarity, RARITY_CONFIG } from '../utils/coreThemes';
import { CORE_BOX_THEMES, BoxThemeItem } from '../utils/boxThemes';
import { BACKGROUND_THEMES, BgThemeItem } from '../utils/bgThemes';
import { ReactorBlock } from './ReactorBlock';
import { sound } from '../utils/audio';

type StoreCategory = 'cores' | 'boxes' | 'backgrounds';

interface StoreScreenProps {
  profile: PlayerProfile;
  onPurchaseItem: (item: any) => boolean;
  onEquipItem: (item: any) => void;
  onBack: () => void;
  onOpenWatchAd?: () => void;
}

export const StoreScreen: React.FC<StoreScreenProps> = ({
  profile,
  onPurchaseItem,
  onEquipItem,
  onBack,
  onOpenWatchAd,
}) => {
  // Active Category: Core Designs, Core Box Themes, Background Themes
  const [activeCategory, setActiveCategory] = useState<StoreCategory>('cores');

  // Active Rarity Filter
  const [selectedRarity, setSelectedRarity] = useState<string>('ALL');

  // Preview / Inspection Modal State
  const [inspectingItem, setInspectingItem] = useState<{
    item: CoreThemeItem | BoxThemeItem | BgThemeItem;
    category: StoreCategory;
  } | null>(null);
  const [previewColor, setPreviewColor] = useState<ReactorColor>('red');

  // Confirmation Dialog State
  const [confirmItem, setConfirmItem] = useState<{
    item: CoreThemeItem | BoxThemeItem | BgThemeItem;
    category: StoreCategory;
  } | null>(null);

  // Notification Toast State
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  // Equipped IDs
  const equippedCoreId =
    !profile.equippedBlockSkin || profile.equippedBlockSkin === 'skin_pulse'
      ? 'core_fruit_bubble'
      : profile.equippedBlockSkin;

  const equippedBoxId =
    !profile.equippedBoardTheme || profile.equippedBoardTheme === 'board_default'
      ? 'box_default'
      : profile.equippedBoardTheme;

  const equippedBgId =
    !profile.equippedBgTheme ? 'bg_cosmic' : profile.equippedBgTheme;

  // Level Stars
  const totalStars = useMemo(() => {
    return Object.values(profile.completedLevels).reduce(
      (acc, lvl) => acc + (lvl?.stars || (lvl?.completed ? 3 : 0)),
      0
    );
  }, [profile.completedLevels]);

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 2500);
  };

  // Ownership checks
  const isItemPurchased = (
    item: CoreThemeItem | BoxThemeItem | BgThemeItem,
    category: StoreCategory
  ) => {
    if (item.price === 0) return true;
    if (category === 'cores' && item.id === 'core_fruit_bubble') return true;
    if (category === 'boxes' && (item.id === 'box_default' || item.id === 'board_default')) return true;
    if (category === 'backgrounds' && item.id === 'bg_cosmic') return true;
    return profile.purchasedItems.includes(item.id);
  };

  // Equipped check
  const isItemEquipped = (
    item: CoreThemeItem | BoxThemeItem | BgThemeItem,
    category: StoreCategory
  ) => {
    if (category === 'cores') {
      return equippedCoreId === item.id;
    } else if (category === 'boxes') {
      return (
        equippedBoxId === item.id ||
        (equippedBoxId === 'box_default' && item.id === 'board_default') ||
        (equippedBoxId === 'board_default' && item.id === 'box_default')
      );
    } else {
      return equippedBgId === item.id;
    }
  };

  // Filter items by category & rarity
  const filteredItems = useMemo(() => {
    let sourceList: (CoreThemeItem | BoxThemeItem | BgThemeItem)[] = [];
    if (activeCategory === 'cores') sourceList = CORE_THEMES;
    else if (activeCategory === 'boxes') sourceList = CORE_BOX_THEMES;
    else sourceList = BACKGROUND_THEMES;

    if (selectedRarity === 'ALL') return sourceList;
    if (selectedRarity === 'OWNED') {
      return sourceList.filter((item) => isItemPurchased(item, activeCategory));
    }
    return sourceList.filter((item) => item.rarity.toUpperCase() === selectedRarity);
  }, [activeCategory, selectedRarity, profile.purchasedItems]);

  // Open confirmation prompt
  const handleInitiateBuy = (
    item: CoreThemeItem | BoxThemeItem | BgThemeItem,
    category: StoreCategory
  ) => {
    if (profile.coins < item.price) {
      sound.playInvalid();
      showToast(`Need ${(item.price - profile.coins).toLocaleString()} more coins!`);
      return;
    }
    sound.playClick();
    setConfirmItem({ item, category });
  };

  // Confirm purchase
  const handleConfirmPurchase = () => {
    if (!confirmItem) return;
    const { item, category } = confirmItem;

    if (profile.coins < item.price) {
      sound.playInvalid();
      showToast('Insufficient coin balance!');
      setConfirmItem(null);
      return;
    }

    const type =
      category === 'cores'
        ? 'blockSkin'
        : category === 'boxes'
        ? 'boardTheme'
        : 'bgTheme';

    const storeItemAdaptor = {
      id: item.id,
      name: item.name,
      type,
      price: item.price,
      currency: 'coins',
      description: item.description,
    };

    const success = onPurchaseItem(storeItemAdaptor);
    if (success) {
      sound.playPurchase();
      showToast(`Unlocked ${item.name}! Tap USE to equip.`);
    } else {
      sound.playInvalid();
      showToast('Purchase could not be completed.');
    }

    setConfirmItem(null);
  };

  // Toggle Equip / Unequip
  const handleToggleEquip = (
    item: CoreThemeItem | BoxThemeItem | BgThemeItem,
    category: StoreCategory
  ) => {
    sound.playClick();
    const equipped = isItemEquipped(item, category);

    if (category === 'cores') {
      if (equipped) {
        onEquipItem({
          id: 'core_fruit_bubble',
          name: 'Fruit Bubble Core',
          type: 'blockSkin',
          price: 0,
          currency: 'coins',
          description: 'Original starting Fruit Bubble Core Theme.',
        });
        showToast(
          item.id === 'core_fruit_bubble'
            ? 'Fruit Bubble Core is already equipped'
            : `Unequipped ${item.name}! Reverted to default Fruit Bubble Core`
        );
      } else {
        onEquipItem({
          id: item.id,
          name: item.name,
          type: 'blockSkin',
          price: item.price,
          currency: 'coins',
          description: item.description,
        });
        showToast(`Equipped ${item.name}!`);
      }
    } else if (category === 'boxes') {
      if (equipped) {
        onEquipItem({
          id: 'box_default',
          name: 'Bubble Glass Box',
          type: 'boardTheme',
          price: 0,
          currency: 'coins',
          description: 'Default board frame.',
        });
        showToast(
          item.id === 'box_default' || item.id === 'board_default'
            ? 'Default Box is already equipped'
            : `Unequipped ${item.name}! Reverted to default Bubble Glass Box`
        );
      } else {
        onEquipItem({
          id: item.id,
          name: item.name,
          type: 'boardTheme',
          price: item.price,
          currency: 'coins',
          description: item.description,
        });
        showToast(`Equipped ${item.name}!`);
      }
    } else {
      // backgrounds
      if (equipped) {
        onEquipItem({
          id: 'bg_cosmic',
          name: 'Cosmic Blue & Violet',
          type: 'bgTheme',
          price: 0,
          currency: 'coins',
          description: 'Default cosmic background.',
        });
        showToast(
          item.id === 'bg_cosmic'
            ? 'Cosmic background is already equipped'
            : `Unequipped ${item.name}! Reverted to default Cosmic background`
        );
      } else {
        onEquipItem({
          id: item.id,
          name: item.name,
          type: 'bgTheme',
          price: item.price,
          currency: 'coins',
          description: item.description,
        });
        showToast(`Equipped ${item.name}!`);
      }
    }
  };

  return (
    <div className="relative w-full h-[100dvh] max-h-[100dvh] flex flex-col justify-between px-3 pt-[max(8px,env(safe-area-inset-top))] pb-[max(10px,env(safe-area-inset-bottom))] text-white select-none overflow-hidden animate-fade-in max-w-[430px] mx-auto bg-gradient-to-b from-[#18082c] via-[#220938] to-[#0c0418]">
      {/* Decorative Ambient Background Glows */}
      <div className="absolute inset-0 pointer-events-none overflow-hidden">
        <div className="absolute -top-24 left-1/2 -translate-x-1/2 w-[340px] h-[340px] bg-pink-500/15 rounded-full blur-[90px]" />
        <div className="absolute bottom-10 -right-20 w-[300px] h-[300px] bg-amber-500/12 rounded-full blur-[90px]" />
      </div>

      {/* ================= HEADER ================= */}
      <header className="w-full shrink-0 mb-1.5 z-20">
        {/* Top bar with Back, Title and Currencies */}
        <div className="flex items-center justify-between mb-2">
          <button
            onClick={() => {
              sound.playClick();
              onBack();
            }}
            className="w-9 h-9 rounded-2xl btn-arcade flex items-center justify-center text-pink-300 active:scale-95 transition-transform cursor-pointer"
            aria-label="Back"
          >
            <ArrowLeft className="w-4 h-4 text-pink-200" />
          </button>

          <div className="text-center">
            <h2 className="text-base font-black font-['Chakra_Petch',sans-serif] tracking-wider text-white uppercase drop-shadow-[0_2px_10px_rgba(255,51,102,0.5)]">
              PREMIUM COSMETICS
            </h2>
            <p className="text-[8px] sm:text-[9px] font-mono font-bold tracking-widest text-pink-300/80 uppercase">
              3 INDEPENDENT COLLECTIONS
            </p>
          </div>

          {/* Currencies Bar: Coins and Stars */}
          <div className="flex items-center gap-1.5">
            {onOpenWatchAd ? (
              <button
                onClick={() => {
                  sound.playClick();
                  onOpenWatchAd();
                }}
                className="flex items-center gap-1 px-2.5 py-1 rounded-xl bg-amber-500/15 border border-amber-400/40 hover:border-amber-400 text-[11px] font-black font-mono text-amber-200 shadow-sm active:scale-95 transition-all cursor-pointer group"
                title="Watch Ad for Free Coins"
              >
                <Coins className="w-3.5 h-3.5 text-amber-300 fill-amber-300" />
                <span>{profile.coins.toLocaleString()}</span>
                <span className="text-[9px] font-bold text-amber-300 bg-amber-400/20 px-1 py-0.2 rounded-full flex items-center gap-0.5">
                  <Tv className="w-2.5 h-2.5" />
                  <span>+Ad</span>
                </span>
              </button>
            ) : (
              <div className="flex items-center gap-1 px-2.5 py-1 rounded-xl bg-amber-500/15 border border-amber-400/40 text-[11px] font-black font-mono text-amber-200 shadow-sm">
                <Coins className="w-3.5 h-3.5 text-amber-300 fill-amber-300" />
                <span>{profile.coins.toLocaleString()}</span>
              </div>
            )}
            <div className="flex items-center gap-1 px-2 py-1 rounded-xl bg-yellow-500/15 border border-yellow-400/40 text-[11px] font-black font-mono text-yellow-200 shadow-sm">
              <Star className="w-3 h-3 text-yellow-300 fill-yellow-300" />
              <span>{totalStars}</span>
            </div>
          </div>
        </div>

        {/* 3 Core Category Tabs */}
        <div className="grid grid-cols-3 gap-1.5 p-1 rounded-2xl bg-black/40 border border-white/10 backdrop-blur-md mb-2">
          <button
            onClick={() => {
              sound.playClick();
              setActiveCategory('cores');
            }}
            className={`py-1.5 px-1 rounded-xl text-[10px] font-black font-['Chakra_Petch'] tracking-wide uppercase transition-all flex items-center justify-center gap-1 cursor-pointer ${
              activeCategory === 'cores'
                ? 'bg-gradient-to-r from-pink-500 to-rose-600 text-white shadow-md border border-pink-300/40'
                : 'text-white/70 hover:text-white'
            }`}
          >
            <Sparkles className="w-3 h-3" />
            <span>CORES ({CORE_THEMES.length})</span>
          </button>

          <button
            onClick={() => {
              sound.playClick();
              setActiveCategory('boxes');
            }}
            className={`py-1.5 px-1 rounded-xl text-[10px] font-black font-['Chakra_Petch'] tracking-wide uppercase transition-all flex items-center justify-center gap-1 cursor-pointer ${
              activeCategory === 'boxes'
                ? 'bg-gradient-to-r from-purple-500 to-indigo-600 text-white shadow-md border border-purple-300/40'
                : 'text-white/70 hover:text-white'
            }`}
          >
            <Box className="w-3 h-3" />
            <span>BOXES ({CORE_BOX_THEMES.length})</span>
          </button>

          <button
            onClick={() => {
              sound.playClick();
              setActiveCategory('backgrounds');
            }}
            className={`py-1.5 px-1 rounded-xl text-[10px] font-black font-['Chakra_Petch'] tracking-wide uppercase transition-all flex items-center justify-center gap-1 cursor-pointer ${
              activeCategory === 'backgrounds'
                ? 'bg-gradient-to-r from-cyan-500 to-blue-600 text-white shadow-md border border-cyan-300/40'
                : 'text-white/70 hover:text-white'
            }`}
          >
            <ImageIcon className="w-3 h-3" />
            <span>WORLDS ({BACKGROUND_THEMES.length})</span>
          </button>
        </div>

        {/* Rarity Filter Strip */}
        <div className="flex items-center gap-1 overflow-x-auto scrollbar-none pb-0.5">
          {['ALL', 'OWNED', 'BASIC', 'ADVANCED', 'RARE', 'EPIC', 'LEGENDARY', 'MYTHIC'].map(
            (tab) => {
              const active = selectedRarity === tab;
              return (
                <button
                  key={tab}
                  onClick={() => {
                    sound.playClick();
                    setSelectedRarity(tab);
                  }}
                  className={`px-2.5 py-1 rounded-xl text-[9px] font-black uppercase font-mono tracking-wider shrink-0 transition-all cursor-pointer ${
                    active
                      ? 'bg-gradient-to-r from-pink-500 to-amber-500 text-black shadow-md border border-white/40'
                      : 'bg-white/[0.05] border border-white/10 text-white/70 hover:text-white'
                  }`}
                >
                  {tab}
                </button>
              );
            }
          )}
        </div>
      </header>

      {/* Floating Notification Toast */}
      {toastMessage && (
        <div className="fixed top-24 left-1/2 -translate-x-1/2 z-50 px-4 py-2 rounded-2xl bg-black/90 border border-pink-400/60 shadow-[0_8px_30px_rgba(0,0,0,0.8)] backdrop-blur-md text-xs font-mono font-bold text-pink-200 animate-bounce-in max-w-[90%] text-center">
          {toastMessage}
        </div>
      )}

      {/* ================= ITEMS GRID ================= */}
      <div className="flex-1 overflow-y-auto pr-1 z-10 overscroll-contain pb-2">
        <div className="grid grid-cols-2 gap-2.5">
          {filteredItems.map((item) => {
            const owned = isItemPurchased(item, activeCategory);
            const equipped = isItemEquipped(item, activeCategory);
            const rarityMeta = RARITY_CONFIG[item.rarity];

            return (
              <div
                key={item.id}
                className={`relative rounded-2xl p-2.5 border transition-all duration-200 flex flex-col justify-between ${
                  equipped
                    ? 'bg-gradient-to-b from-pink-950/70 via-purple-950/80 to-black/90 border-pink-400 shadow-[0_0_22px_rgba(244,63,94,0.45)] ring-2 ring-pink-400/50'
                    : owned
                    ? 'bg-gradient-to-b from-[#211036]/80 to-[#120822]/90 border-white/15 hover:border-pink-300/40'
                    : 'bg-[#150a24]/80 border-white/10 hover:border-white/20'
                }`}
              >
                {/* Top Strip: Rarity Badge & Inspect Icon */}
                <div className="flex items-center justify-between gap-1 mb-1">
                  <span
                    className={`px-2 py-0.5 rounded-full text-[8px] font-mono font-black uppercase tracking-wider border ${rarityMeta.bg} ${rarityMeta.text} ${rarityMeta.border}`}
                  >
                    {rarityMeta.label}
                  </span>

                  <button
                    onClick={() => {
                      sound.playClick();
                      setInspectingItem({ item, category: activeCategory });
                    }}
                    className="w-5 h-5 rounded-lg bg-white/[0.08] hover:bg-white/[0.18] flex items-center justify-center text-white/70 hover:text-white transition-colors cursor-pointer"
                    title="Inspect item preview"
                  >
                    <Eye className="w-3 h-3" />
                  </button>
                </div>

                {/* Center Preview Display */}
                <div
                  onClick={() => {
                    sound.playClick();
                    setInspectingItem({ item, category: activeCategory });
                  }}
                  className="my-1.5 h-16 rounded-xl flex items-center justify-center bg-black/40 border border-white/10 relative overflow-hidden cursor-pointer group shadow-inner"
                >
                  {/* Subtle Ambient Glow Behind Preview */}
                  <div className="absolute inset-0 bg-gradient-to-tr from-pink-500/10 via-transparent to-amber-500/10 opacity-70 group-hover:opacity-100 transition-opacity" />

                  {/* 1. CORE DESIGN PREVIEW */}
                  {activeCategory === 'cores' && (
                    <div className="relative transform transition-transform group-hover:scale-110">
                      <ReactorBlock
                        color="red"
                        theme={item.id}
                        size={40}
                        glow={equipped}
                      />
                    </div>
                  )}

                  {/* 2. CORE BOX THEME PREVIEW */}
                  {activeCategory === 'boxes' && (
                    <div className={`w-14 h-14 rounded-xl p-1 bg-gradient-to-b ${(item as BoxThemeItem).casingStyle} border flex items-center justify-center transform transition-transform group-hover:scale-105 shadow-md`}>
                      <div className="grid grid-cols-2 grid-rows-2 gap-0.5 w-10 h-10 p-0.5 rounded-lg bg-black/60 border border-white/20">
                        <div className="rounded bg-pink-400/80" />
                        <div className="rounded bg-cyan-400/80" />
                        <div className="rounded bg-emerald-400/80" />
                        <div className="rounded bg-amber-400/80" />
                      </div>
                    </div>
                  )}

                  {/* 3. BACKGROUND THEME PREVIEW */}
                  {activeCategory === 'backgrounds' && (
                    <div className={`w-full h-full bg-gradient-to-b ${(item as BgThemeItem).gradient} flex items-center justify-center relative p-1`}>
                      <div className="w-6 h-6 rounded-full bg-pink-400/30 blur-sm" />
                      <Sparkles className="w-5 h-5 text-white/90 drop-shadow" />
                    </div>
                  )}
                </div>

                {/* Title & Tagline */}
                <div className="text-left mb-2">
                  <h3 className="text-xs font-black font-['Chakra_Petch'] text-white truncate">
                    {item.name}
                  </h3>
                  <p className="text-[9px] font-mono text-pink-200/70 truncate">
                    {item.tagline}
                  </p>
                </div>

                {/* Dynamic Action Button: BUY / USE / EQUIPPED */}
                <div>
                  {!owned ? (
                    <button
                      onClick={() => handleInitiateBuy(item, activeCategory)}
                      className="w-full py-2 px-2 rounded-xl bg-gradient-to-r from-amber-400 to-yellow-500 hover:from-amber-300 hover:to-yellow-400 text-black font-black font-mono text-[11px] uppercase tracking-wider flex items-center justify-center gap-1 shadow-[0_4px_14px_rgba(245,158,11,0.4)] active:scale-95 transition-all cursor-pointer"
                    >
                      <Coins className="w-3.5 h-3.5 fill-black" />
                      <span>{item.price.toLocaleString()}</span>
                    </button>
                  ) : equipped ? (
                    <button
                      onClick={() => handleToggleEquip(item, activeCategory)}
                      className="w-full py-2 px-2 rounded-xl bg-emerald-500/25 hover:bg-emerald-500/35 border border-emerald-400 text-emerald-200 font-black font-mono text-[11px] uppercase tracking-wider flex items-center justify-center gap-1 shadow-[0_0_12px_rgba(16,185,129,0.4)] active:scale-95 transition-all cursor-pointer"
                      title="Click to unequip and revert to default"
                    >
                      <Check className="w-3.5 h-3.5 text-emerald-300 stroke-[3]" />
                      <span>EQUIPPED</span>
                    </button>
                  ) : (
                    <button
                      onClick={() => handleToggleEquip(item, activeCategory)}
                      className="w-full py-2 px-2 rounded-xl bg-gradient-to-r from-pink-500 to-rose-600 hover:from-pink-400 hover:to-rose-500 text-white font-black font-mono text-[11px] uppercase tracking-wider flex items-center justify-center gap-1 shadow-[0_4px_14px_rgba(244,63,94,0.35)] active:scale-95 transition-all cursor-pointer"
                    >
                      <span>USE</span>
                    </button>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* ================= PURCHASE CONFIRMATION MODAL ================= */}
      {confirmItem && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md animate-fade-in">
          <div className="relative w-full max-w-[320px] rounded-3xl glass-panel-colorful p-5 border-2 border-amber-400/60 shadow-[0_16px_50px_rgba(0,0,0,0.85)] text-center animate-bounce-in">
            <h3 className="text-base font-black font-['Chakra_Petch'] text-amber-200 uppercase tracking-wider mb-1">
              CONFIRM PURCHASE
            </h3>
            <p className="text-xs text-white/80 mb-3">
              Unlock <span className="font-bold text-white">{confirmItem.item.name}</span> for{' '}
              <span className="font-mono font-black text-amber-300">
                {confirmItem.item.price.toLocaleString()} Coins
              </span>
              ?
            </p>

            <div className="flex items-center gap-2">
              <button
                onClick={() => setConfirmItem(null)}
                className="flex-1 py-2.5 rounded-xl btn-arcade text-white/70 font-black text-xs uppercase cursor-pointer"
              >
                Cancel
              </button>
              <button
                onClick={handleConfirmPurchase}
                className="flex-1 py-2.5 rounded-xl bg-gradient-to-r from-amber-400 to-yellow-500 text-black font-black text-xs uppercase shadow-md active:scale-95 transition-transform cursor-pointer"
              >
                Confirm
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ================= INSPECT / PREVIEW MODAL ================= */}
      {inspectingItem && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md animate-fade-in">
          <div className="relative w-full max-w-[340px] rounded-3xl glass-panel-colorful p-5 border-2 border-pink-400/60 shadow-[0_20px_50px_rgba(0,0,0,0.85)] flex flex-col items-center text-center animate-bounce-in">
            <button
              onClick={() => setInspectingItem(null)}
              className="absolute top-3.5 right-3.5 w-8 h-8 rounded-full bg-white/10 border border-white/20 flex items-center justify-center text-white/70 hover:text-white cursor-pointer"
            >
              <X className="w-4 h-4" />
            </button>

            <span className="text-[9px] font-mono font-bold px-2 py-0.5 rounded-full bg-pink-500/20 text-pink-200 border border-pink-400/30 uppercase mb-2">
              {inspectingItem.category === 'cores'
                ? 'CORE DESIGN PREVIEW'
                : inspectingItem.category === 'boxes'
                ? 'CORE BOX THEME PREVIEW'
                : 'BACKGROUND THEME PREVIEW'}
            </span>

            {/* Preview visual */}
            <div className="my-3 p-4 rounded-2xl bg-black/60 border border-white/10 flex items-center justify-center min-w-[140px] min-h-[100px]">
              {inspectingItem.category === 'cores' && (
                <ReactorBlock
                  color={previewColor}
                  theme={inspectingItem.item.id}
                  size={56}
                  glow={true}
                />
              )}

              {inspectingItem.category === 'boxes' && (
                <div className={`w-28 h-28 rounded-2xl p-1.5 bg-gradient-to-b ${(inspectingItem.item as BoxThemeItem).casingStyle} border shadow-lg flex items-center justify-center`}>
                  <div className="grid grid-cols-3 grid-rows-3 gap-1 w-20 h-20 p-1 rounded-xl bg-black/60 border border-white/20">
                    <div className="rounded bg-pink-400/80" />
                    <div className="rounded bg-cyan-400/80" />
                    <div className="rounded bg-emerald-400/80" />
                    <div className="rounded bg-amber-400/80" />
                    <div className="rounded bg-purple-400/80" />
                    <div className="rounded bg-rose-400/80" />
                    <div className="rounded bg-teal-400/80" />
                    <div className="rounded bg-yellow-400/80" />
                    <div className="rounded bg-blue-400/80" />
                  </div>
                </div>
              )}

              {inspectingItem.category === 'backgrounds' && (
                <div className={`w-36 h-24 rounded-2xl bg-gradient-to-b ${(inspectingItem.item as BgThemeItem).gradient} border border-white/20 flex items-center justify-center relative overflow-hidden shadow-lg`}>
                  <div className="w-10 h-10 rounded-full bg-pink-400/30 blur-md" />
                  <Sparkles className="w-8 h-8 text-white drop-shadow" />
                </div>
              )}
            </div>

            {/* If Core Design, show color switchers */}
            {inspectingItem.category === 'cores' && (
              <div className="flex items-center gap-1.5 mb-2">
                {(['red', 'blue', 'green', 'yellow', 'purple'] as ReactorColor[]).map((c) => (
                  <button
                    key={c}
                    onClick={() => setPreviewColor(c)}
                    className={`w-5 h-5 rounded-full border cursor-pointer ${
                      previewColor === c ? 'ring-2 ring-white scale-110' : 'opacity-70'
                    }`}
                    style={{
                      backgroundColor:
                        c === 'red'
                          ? '#ff2d55'
                          : c === 'blue'
                          ? '#0284c7'
                          : c === 'green'
                          ? '#10b981'
                          : c === 'yellow'
                          ? '#f59e0b'
                          : '#a855f7',
                    }}
                  />
                ))}
              </div>
            )}

            <h3 className="text-base font-black font-['Chakra_Petch'] text-white">
              {inspectingItem.item.name}
            </h3>
            <p className="text-[10px] font-mono text-pink-300 mb-2">
              {inspectingItem.item.tagline}
            </p>
            <p className="text-xs text-white/80 leading-relaxed mb-4">
              {inspectingItem.item.description}
            </p>

            <button
              onClick={() => setInspectingItem(null)}
              className="w-full py-2.5 rounded-xl btn-arcade text-pink-200 font-black text-xs uppercase cursor-pointer"
            >
              Close Preview
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
