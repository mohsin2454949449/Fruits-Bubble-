import React, { useState } from 'react';
import { Sparkles, Coins, Gift, Check, ArrowRight, X } from 'lucide-react';
import { MilestoneReward } from '../utils/milestoneRewards';
import { ReactorBlock } from './ReactorBlock';
import { sound } from '../utils/audio';
import { RARITY_CONFIG } from '../utils/coreThemes';

interface MilestoneChestModalProps {
  milestoneLevel: number;
  reward: MilestoneReward;
  onClaim: (reward: MilestoneReward) => void;
  onClose: () => void;
}

export const MilestoneChestModal: React.FC<MilestoneChestModalProps> = ({
  milestoneLevel,
  reward,
  onClaim,
  onClose,
}) => {
  const [stage, setStage] = useState<'closed' | 'opening' | 'opened'>('closed');

  const handleOpenChest = () => {
    sound.playLevelComplete();
    setStage('opening');
    setTimeout(() => {
      setStage('opened');
      sound.playCoin();
    }, 900);
  };

  const handleClaimReward = () => {
    sound.playClick();
    onClaim(reward);
  };

  const rarityMeta = reward.rarity ? RARITY_CONFIG[reward.rarity] : RARITY_CONFIG.Basic;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-xl animate-fade-in select-none">
      <div className="relative w-full max-w-sm rounded-3xl glass-panel-colorful p-6 text-center overflow-hidden shadow-[0_0_80px_rgba(245,158,11,0.45)] border-2 border-amber-400/50">
        {/* Ambient Top Glow Orbs */}
        <div className="absolute -top-16 left-1/2 -translate-x-1/2 w-72 h-40 bg-gradient-to-r from-amber-400/35 via-rose-500/30 to-purple-500/35 blur-3xl pointer-events-none" />

        {/* Close button (allowed if already opened or closing) */}
        {stage === 'opened' && (
          <button
            onClick={onClose}
            className="absolute top-3.5 right-3.5 w-8 h-8 rounded-full bg-white/10 hover:bg-white/20 border border-white/20 flex items-center justify-center text-white/70 hover:text-white active:scale-90 transition-transform cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        )}

        {/* Milestone Badge */}
        <div className="inline-flex items-center gap-1.5 px-3 py-1 mb-2 rounded-full bg-amber-950/80 border border-amber-400/60 text-[10px] font-mono font-black text-amber-200 uppercase tracking-widest shadow-md">
          <Sparkles className="w-3.5 h-3.5 text-amber-300 animate-spin-slow" />
          <span>MILESTONE {milestoneLevel} CHEST</span>
        </div>

        {/* ================= STAGE 1: CLOSED CHEST ================= */}
        {stage === 'closed' && (
          <div className="py-4 animate-fade-in flex flex-col items-center">
            {/* 3D Cartoon Chest Lockup */}
            <div className="relative w-28 h-28 my-3 flex items-center justify-center animate-bounce">
              <div className="absolute inset-0 rounded-full bg-amber-400/25 blur-2xl animate-pulse" />
              {/* Outer Golden Chest Box */}
              <div className="relative w-24 h-24 rounded-3xl bg-gradient-to-br from-amber-400 via-orange-500 to-amber-700 p-1 shadow-[0_12px_35px_rgba(245,158,11,0.6)] border-2 border-yellow-200 flex flex-col items-center justify-center">
                {/* Chest Lid Bands */}
                <div className="w-full h-4 rounded-t-2xl bg-amber-300/40 border-b border-amber-900/40 mb-1" />
                {/* Golden Keyhole Emblem */}
                <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-yellow-200 to-amber-400 border border-white/60 shadow-inner flex items-center justify-center">
                  <Gift className="w-6 h-6 text-amber-950 fill-amber-900" />
                </div>
                {/* Sparkle Badges */}
                <Sparkles className="absolute -top-2 -right-2 w-7 h-7 text-yellow-300 animate-spin" />
              </div>
            </div>

            <h2 className="text-xl font-black font-['Chakra_Petch'] text-white uppercase tracking-wider mb-1 drop-shadow-[0_2px_12px_rgba(245,158,11,0.6)]">
              MYSTERY CHEST READY!
            </h2>
            <p className="text-xs text-pink-200/90 mb-5 max-w-[260px] leading-relaxed">
              You mastered 10 challenging levels! Tap below to crack open your special milestone mystery reward!
            </p>

            <button
              onClick={handleOpenChest}
              className="w-full py-4 px-6 rounded-2xl btn-cta-glow text-black font-black text-sm uppercase tracking-wider flex items-center justify-center gap-2 shadow-[0_8px_28px_rgba(251,191,36,0.6)] active:scale-95 transition-transform cursor-pointer"
            >
              <Gift className="w-4 h-4 fill-black" />
              <span>Tap To Open Chest</span>
            </button>
          </div>
        )}

        {/* ================= STAGE 2: OPENING ANIMATION ================= */}
        {stage === 'opening' && (
          <div className="py-8 flex flex-col items-center">
            {/* Shaking & Glowing Radiance */}
            <div className="relative w-28 h-28 my-3 flex items-center justify-center animate-spin-slow">
              <div className="absolute inset-0 rounded-full bg-gradient-to-r from-yellow-300 to-rose-400 blur-3xl animate-ping" />
              <div className="w-24 h-24 rounded-3xl bg-gradient-to-tr from-yellow-300 to-amber-500 flex items-center justify-center shadow-[0_0_50px_rgba(251,191,36,1)] border-4 border-white animate-pulse">
                <Sparkles className="w-12 h-12 text-white animate-spin" />
              </div>
            </div>
            <h3 className="text-lg font-black font-['Chakra_Petch'] text-amber-300 uppercase tracking-widest mt-2 animate-pulse">
              OPENING CHEST...
            </h3>
          </div>
        )}

        {/* ================= STAGE 3: REVEALED REWARD ================= */}
        {stage === 'opened' && (
          <div className="py-2 animate-fade-in flex flex-col items-center">
            {/* Rarity Tag */}
            {reward.rarity && (
              <span
                className={`px-2.5 py-0.5 rounded-full text-[9px] font-mono font-black uppercase tracking-wider mb-2 border ${rarityMeta.bg} ${rarityMeta.text} ${rarityMeta.border} shadow-sm`}
              >
                {reward.rarity} REWARD
              </span>
            )}

            {/* Visual Reward Presentation */}
            <div className="relative w-24 h-24 my-2 flex items-center justify-center">
              <div className="absolute inset-0 rounded-full bg-gradient-to-tr from-amber-400/40 via-pink-500/30 to-purple-500/30 blur-2xl animate-pulse" />

              {/* COINS PRESENTATION */}
              {reward.type === 'coins' && (
                <div className="w-20 h-20 rounded-3xl bg-gradient-to-tr from-amber-400 to-yellow-500 border-2 border-white flex items-center justify-center shadow-[0_0_30px_rgba(245,158,11,0.8)] animate-bounce-in">
                  <Coins className="w-10 h-10 text-amber-950 fill-amber-900" />
                </div>
              )}

              {/* CORE DESIGN PRESENTATION */}
              {reward.type === 'coreTheme' && (
                <div className="w-20 h-20 rounded-3xl bg-black/60 border-2 border-pink-400/80 flex items-center justify-center shadow-[0_0_30px_rgba(244,63,94,0.7)] animate-bounce-in p-2">
                  <ReactorBlock color="red" theme={reward.itemId} size={48} glow={true} />
                </div>
              )}

              {/* CORE BOX THEME PRESENTATION */}
              {reward.type === 'boxTheme' && (
                <div className="w-20 h-20 rounded-3xl bg-gradient-to-br from-purple-900 via-indigo-900 to-black border-2 border-purple-400 flex items-center justify-center shadow-[0_0_30px_rgba(168,85,247,0.7)] animate-bounce-in p-2">
                  <div className="grid grid-cols-2 grid-rows-2 gap-1 w-12 h-12 p-1 rounded-xl border border-white/40">
                    <div className="rounded bg-pink-400/80" />
                    <div className="rounded bg-cyan-400/80" />
                    <div className="rounded bg-emerald-400/80" />
                    <div className="rounded bg-amber-400/80" />
                  </div>
                </div>
              )}

              {/* BACKGROUND THEME PRESENTATION */}
              {reward.type === 'bgTheme' && (
                <div className={`w-20 h-20 rounded-3xl bg-gradient-to-br ${reward.previewGradient || 'from-pink-500 to-purple-800'} border-2 border-white flex items-center justify-center shadow-[0_0_30px_rgba(236,72,153,0.7)] animate-bounce-in`}>
                  <Sparkles className="w-9 h-9 text-white drop-shadow" />
                </div>
              )}
            </div>

            {/* Category Subtext */}
            {reward.itemCategory && (
              <span className="text-[10px] font-mono font-bold text-pink-300 uppercase tracking-widest mt-1">
                {reward.itemCategory} UNLOCKED!
              </span>
            )}

            {/* Reward Title */}
            <h2 className="text-xl font-black font-['Chakra_Petch'] text-white uppercase tracking-wider my-1 drop-shadow-[0_2px_12px_rgba(255,255,255,0.4)]">
              {reward.title}
            </h2>

            {/* Description */}
            <p className="text-xs text-pink-100/80 mb-4 max-w-[280px] leading-relaxed">
              {reward.description}
            </p>

            {/* Claim Button */}
            <button
              onClick={handleClaimReward}
              className="w-full py-4 px-6 rounded-2xl btn-cta-glow text-black font-black text-sm uppercase tracking-wider flex items-center justify-center gap-2 shadow-[0_8px_28px_rgba(251,191,36,0.6)] active:scale-95 transition-transform cursor-pointer"
            >
              <Check className="w-5 h-5 stroke-[3]" />
              <span>Claim Reward</span>
            </button>
          </div>
        )}
      </div>
    </div>
  );
};
