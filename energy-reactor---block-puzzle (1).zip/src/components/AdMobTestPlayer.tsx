import React, { useState, useEffect, useRef } from 'react';
import {
  X,
  Volume2,
  VolumeX,
  Coins,
  CheckCircle2,
  AlertTriangle,
  Play,
  ShieldCheck,
  Sparkles,
} from 'lucide-react';
import { admob, ActiveAdSession } from '../services/admobService';

export const AdMobTestPlayer: React.FC = () => {
  const [session, setSession] = useState<ActiveAdSession | null>(null);
  const [secondsRemaining, setSecondsRemaining] = useState<number>(5);
  const [totalSeconds, setTotalSeconds] = useState<number>(5);
  const [isCompleted, setIsCompleted] = useState<boolean>(false);
  const [showExitConfirm, setShowExitConfirm] = useState<boolean>(false);
  const [isMuted, setIsMuted] = useState<boolean>(true);

  // Subscribe to AdMob service sessions
  useEffect(() => {
    const unsubscribe = admob.subscribe((active) => {
      setSession(active);
      if (active) {
        const duration = active.type === 'rewarded' ? 5 : 4;
        setTotalSeconds(duration);
        setSecondsRemaining(duration);
        setIsCompleted(false);
        setShowExitConfirm(false);
      }
    });
    return unsubscribe;
  }, []);

  // Timer countdown
  useEffect(() => {
    if (!session || isCompleted || showExitConfirm) return;

    if (secondsRemaining <= 0) {
      setIsCompleted(true);
      if (session.type === 'rewarded' && session.onRewardConfirmed) {
        session.onRewardConfirmed();
      }
      return;
    }

    const interval = setInterval(() => {
      setSecondsRemaining((prev) => prev - 1);
    }, 1000);

    return () => clearInterval(interval);
  }, [session, secondsRemaining, isCompleted, showExitConfirm]);

  if (!session) return null;

  const isRewarded = session.type === 'rewarded';
  const progressPercent = Math.max(
    0,
    Math.min(100, ((totalSeconds - secondsRemaining) / totalSeconds) * 100)
  );

  // Close attempt
  const handleAttemptClose = () => {
    if (isCompleted) {
      session.onClosed(true);
      return;
    }

    if (isRewarded) {
      setShowExitConfirm(true);
    } else {
      // Interstitial can be skipped/closed after countdown
      if (secondsRemaining <= 1) {
        session.onClosed(false);
      }
    }
  };

  const handleConfirmExitWithoutReward = () => {
    setShowExitConfirm(false);
    session.onClosed(false); // No reward!
  };

  return (
    <div className="fixed inset-0 z-[100] bg-black/95 flex flex-col justify-between text-white select-none animate-fade-in font-sans">
      {/* Top Banner: Google AdMob Official Test Indicator */}
      <div className="w-full bg-[#1e293b] border-b border-white/10 px-4 py-2.5 flex items-center justify-between z-20">
        <div className="flex items-center gap-2">
          {/* AdMob Colors Logo Emblem */}
          <div className="flex items-center gap-0.5">
            <span className="w-2.5 h-2.5 rounded-full bg-[#4285F4]" />
            <span className="w-2.5 h-2.5 rounded-full bg-[#EA4335]" />
            <span className="w-2.5 h-2.5 rounded-full bg-[#FBBC05]" />
            <span className="w-2.5 h-2.5 rounded-full bg-[#34A853]" />
          </div>
          <div>
            <div className="text-[11px] font-black tracking-wider uppercase text-yellow-400 flex items-center gap-1.5 leading-none">
              <span>Google AdMob Test Ad</span>
              <ShieldCheck className="w-3 h-3 text-emerald-400" />
            </div>
            <div className="text-[8px] font-mono text-slate-400 truncate max-w-[220px]">
              {session.adUnitId}
            </div>
          </div>
        </div>

        {/* Top Controls: Sound & Close */}
        <div className="flex items-center gap-2">
          <button
            onClick={() => setIsMuted(!isMuted)}
            className="p-1.5 rounded-full bg-white/10 hover:bg-white/20 text-slate-300"
          >
            {isMuted ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
          </button>

          {/* Close / Skip button */}
          <button
            onClick={handleAttemptClose}
            className={`px-2.5 py-1 rounded-full text-xs font-bold flex items-center gap-1 transition-all ${
              isCompleted || (!isRewarded && secondsRemaining <= 1)
                ? 'bg-emerald-500 text-black hover:bg-emerald-400'
                : 'bg-white/15 text-white/70 hover:bg-white/25'
            }`}
          >
            {isCompleted ? (
              <>
                <span>Done</span>
                <X className="w-3.5 h-3.5" />
              </>
            ) : !isRewarded && secondsRemaining <= 1 ? (
              <>
                <span>Skip</span>
                <X className="w-3.5 h-3.5" />
              </>
            ) : (
              <X className="w-4 h-4" />
            )}
          </button>
        </div>
      </div>

      {/* Progress Bar Header */}
      <div className="w-full bg-slate-800 h-1.5 relative overflow-hidden">
        <div
          className="h-full bg-gradient-to-r from-yellow-400 via-amber-500 to-emerald-400 transition-all duration-300 ease-linear"
          style={{ width: `${progressPercent}%` }}
        />
      </div>

      {/* Main Creative Container */}
      <div className="flex-1 flex flex-col items-center justify-center p-6 text-center relative overflow-hidden">
        {/* Ambient glow effects */}
        <div className="absolute w-72 h-72 rounded-full bg-pink-500/10 blur-3xl pointer-events-none" />
        <div className="absolute w-72 h-72 rounded-full bg-cyan-500/10 blur-3xl pointer-events-none" />

        {/* Video / Creative Simulation Card */}
        <div className="relative w-full max-w-sm rounded-3xl bg-slate-900/90 border border-white/15 p-6 shadow-2xl flex flex-col items-center">
          {/* Ad Format Badge */}
          <div className="px-3 py-1 rounded-full bg-yellow-400/20 border border-yellow-400/40 text-[10px] font-mono font-black text-yellow-300 uppercase tracking-widest mb-4">
            {isRewarded ? 'Rewarded Video Ad' : 'Interstitial Full-Screen Ad'}
          </div>

          {/* Animated Mascot / Game Preview Emblem */}
          <div className="w-24 h-24 rounded-3xl bg-gradient-to-tr from-pink-500 via-purple-600 to-indigo-600 flex items-center justify-center shadow-lg shadow-purple-500/30 mb-4 animate-bounce-in relative">
            <Sparkles className="w-12 h-12 text-yellow-200 animate-pulse" />
            <div className="absolute -bottom-2 px-2 py-0.5 rounded-full bg-black/60 border border-white/20 text-[9px] font-bold text-white">
              Fruit Bubble
            </div>
          </div>

          <h3 className="text-xl font-black text-white uppercase tracking-wide mb-1 font-['Chakra_Petch',sans-serif]">
            Fruit Bubble Puzzle
          </h3>
          <p className="text-xs text-slate-300 mb-4 max-w-xs leading-relaxed">
            Pop colorful fruit blocks, rotate tactical cores, and conquer 1,000 adventure levels!
          </p>

          {/* Status Display: Countdown or Completed */}
          {isCompleted ? (
            <div className="w-full p-4 rounded-2xl bg-emerald-950/60 border border-emerald-400/50 flex flex-col items-center gap-1.5 animate-bounce-in">
              <CheckCircle2 className="w-8 h-8 text-emerald-400" />
              <div className="text-sm font-black text-emerald-300 uppercase tracking-wider">
                {isRewarded ? 'Reward Earned!' : 'Ad Finished'}
              </div>
              {isRewarded && session.reward && (
                <div className="flex items-center gap-1.5 text-xs font-mono font-bold text-yellow-300">
                  <Coins className="w-4 h-4 fill-amber-400 text-amber-300" />
                  <span>+{session.reward.amount.toLocaleString()} Coins</span>
                </div>
              )}
            </div>
          ) : (
            <div className="w-full p-4 rounded-2xl bg-slate-800/80 border border-white/10 flex flex-col items-center gap-2">
              <div className="text-2xl font-black font-mono text-yellow-300">
                {secondsRemaining}s
              </div>
              <div className="text-[11px] font-bold text-slate-300 uppercase tracking-wider">
                {isRewarded
                  ? `Reward in ${secondsRemaining} second${secondsRemaining === 1 ? '' : 's'}`
                  : `You can skip in ${secondsRemaining}s`}
              </div>
              {isRewarded && session.reward && (
                <div className="flex items-center gap-1 text-[11px] font-mono text-yellow-400/90">
                  <span>Earn:</span>
                  <Coins className="w-3.5 h-3.5 fill-amber-400 text-amber-300" />
                  <span className="font-bold">+{session.reward.amount} Coins</span>
                </div>
              )}
            </div>
          )}
        </div>
      </div>

      {/* Bottom CTA / Claim bar */}
      <div className="w-full bg-[#1e293b] border-t border-white/10 p-4 flex flex-col items-center">
        {isCompleted ? (
          <button
            onClick={() => session.onClosed(true)}
            className="w-full max-w-sm py-3.5 px-6 rounded-2xl bg-gradient-to-r from-emerald-400 to-green-500 text-black font-black text-sm uppercase tracking-wider shadow-lg shadow-emerald-500/40 active:scale-95 transition-transform flex items-center justify-center gap-2"
          >
            <span>Claim & Return to Game</span>
            <CheckCircle2 className="w-4 h-4" />
          </button>
        ) : (
          <div className="text-center text-[11px] text-slate-400 font-medium">
            {isRewarded
              ? 'Watch this test video until the timer ends to earn bonus coins.'
              : 'Google AdMob test interstitial ad. Tap Skip or wait to finish.'}
          </div>
        )}
      </div>

      {/* Warning Confirmation Modal when user tries to close early without reward */}
      {showExitConfirm && (
        <div className="fixed inset-0 z-[110] bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="w-full max-w-xs rounded-3xl bg-slate-900 border border-rose-500/50 p-5 text-center shadow-2xl animate-bounce-in">
            <div className="w-12 h-12 rounded-2xl bg-rose-500/20 text-rose-400 flex items-center justify-center mx-auto mb-3">
              <AlertTriangle className="w-6 h-6" />
            </div>
            <h4 className="text-base font-black text-white uppercase mb-1">
              Forfeit Reward?
            </h4>
            <p className="text-xs text-slate-300 mb-4 leading-relaxed">
              If you close this video before it finishes, you will not receive your{' '}
              <span className="font-bold text-yellow-300">
                +{session.reward?.amount || 500} Coins
              </span>.
            </p>
            <div className="flex flex-col gap-2">
              <button
                onClick={() => setShowExitConfirm(false)}
                className="w-full py-3 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-500 text-black font-black text-xs uppercase tracking-wider active:scale-95 transition-transform"
              >
                Keep Watching ({secondsRemaining}s left)
              </button>
              <button
                onClick={handleConfirmExitWithoutReward}
                className="w-full py-2.5 rounded-xl bg-white/10 hover:bg-white/15 text-slate-400 font-bold text-xs uppercase tracking-wider active:scale-95 transition-transform"
              >
                Close Without Reward
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
