import React, { useEffect, useState } from 'react';
import { Sparkles, Zap, Flame, Trophy } from 'lucide-react';

export interface LineAnnouncementData {
  id: number;
  linesCount: number;
  text: string;
}

interface LineClearAnnouncementProps {
  announcement: LineAnnouncementData | null;
}

const TIER_STYLES: Record<
  number,
  {
    gradient: string;
    shadow: string;
    border: string;
    badgeBg: string;
    icon: typeof Zap;
  }
> = {
  2: {
    gradient: 'from-cyan-300 via-sky-400 to-blue-500',
    shadow: 'shadow-[0_0_35px_rgba(0,240,255,0.7)]',
    border: 'border-cyan-300/80',
    badgeBg: 'bg-cyan-950/80 text-cyan-200 border-cyan-400/60',
    icon: Zap,
  },
  3: {
    gradient: 'from-emerald-300 via-teal-400 to-cyan-400',
    shadow: 'shadow-[0_0_40px_rgba(52,211,153,0.75)]',
    border: 'border-emerald-300/80',
    badgeBg: 'bg-emerald-950/80 text-emerald-200 border-emerald-400/60',
    icon: Sparkles,
  },
  4: {
    gradient: 'from-amber-300 via-orange-400 to-rose-500',
    shadow: 'shadow-[0_0_45px_rgba(251,146,60,0.8)]',
    border: 'border-amber-300/90',
    badgeBg: 'bg-amber-950/80 text-amber-200 border-amber-400/60',
    icon: Flame,
  },
  5: {
    gradient: 'from-pink-400 via-purple-400 to-indigo-400',
    shadow: 'shadow-[0_0_50px_rgba(232,121,249,0.85)]',
    border: 'border-fuchsia-300/90',
    badgeBg: 'bg-purple-950/80 text-fuchsia-200 border-fuchsia-400/60',
    icon: Flame,
  },
  6: {
    gradient: 'from-violet-400 via-fuchsia-400 to-cyan-300',
    shadow: 'shadow-[0_0_55px_rgba(192,132,252,0.9)]',
    border: 'border-violet-300/90',
    badgeBg: 'bg-violet-950/80 text-violet-200 border-violet-400/60',
    icon: Trophy,
  },
  7: {
    gradient: 'from-yellow-200 via-amber-300 to-orange-500',
    shadow: 'shadow-[0_0_65px_rgba(253,224,71,0.95)]',
    border: 'border-yellow-200',
    badgeBg: 'bg-amber-950/90 text-yellow-200 border-yellow-300',
    icon: Trophy,
  },
};

export const LineClearAnnouncement: React.FC<LineClearAnnouncementProps> = ({
  announcement,
}) => {
  const [activeItem, setActiveItem] = useState<LineAnnouncementData | null>(null);
  const [animState, setAnimState] = useState<'enter' | 'exit' | null>(null);

  useEffect(() => {
    if (!announcement) return;

    setActiveItem(announcement);
    setAnimState('enter');

    // Display for 2 seconds, then smoothly fade out
    const exitTimer = setTimeout(() => {
      setAnimState('exit');
    }, 1800);

    const removeTimer = setTimeout(() => {
      setActiveItem(null);
      setAnimState(null);
    }, 2200);

    return () => {
      clearTimeout(exitTimer);
      clearTimeout(removeTimer);
    };
  }, [announcement]);

  if (!activeItem || !animState) return null;

  const count = Math.min(Math.max(activeItem.linesCount, 2), 7);
  const tier = TIER_STYLES[count] || TIER_STYLES[2];
  const IconComponent = tier.icon;

  return (
    <div className="fixed inset-x-0 top-[28%] sm:top-[30%] flex justify-center items-center pointer-events-none z-40 select-none px-4">
      <div
        key={activeItem.id}
        className={`relative flex flex-col items-center justify-center p-3 sm:p-4 rounded-3xl bg-black/85 backdrop-blur-xl border-2 ${
          tier.border
        } ${tier.shadow} transition-all duration-300 transform ${
          animState === 'enter'
            ? 'scale-100 opacity-100 translate-y-0 animate-bounce-in'
            : 'scale-90 opacity-0 -translate-y-4'
        }`}
      >
        {/* Ambient Plasma Glow Aura */}
        <div className="absolute inset-0 rounded-3xl bg-gradient-to-r from-cyan-500/20 via-purple-500/20 to-pink-500/20 blur-xl pointer-events-none" />

        {/* Header Badge */}
        <div
          className={`flex items-center gap-1.5 px-3 py-0.5 rounded-full text-[10px] sm:text-xs font-mono font-black uppercase tracking-widest border mb-1 shadow-md ${tier.badgeBg}`}
        >
          <IconComponent className="w-3.5 h-3.5 fill-current animate-pulse" />
          <span>{activeItem.linesCount} LINES CLEARED</span>
        </div>

        {/* Main Announcement Heading */}
        <div
          className={`text-3xl sm:text-4xl md:text-5xl font-black font-['Chakra_Petch',sans-serif] tracking-wider uppercase bg-gradient-to-r ${tier.gradient} bg-clip-text text-transparent drop-shadow-[0_4px_16px_rgba(0,0,0,0.9)]`}
        >
          {activeItem.text}
        </div>
      </div>
    </div>
  );
};
