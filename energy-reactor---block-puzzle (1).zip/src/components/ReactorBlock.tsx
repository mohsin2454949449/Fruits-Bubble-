import React, { useId } from 'react';
import { ReactorColor } from '../types/game';
import { REACTOR_COLORS } from '../utils/shapes';

export interface ReactorBlockProps {
  color: ReactorColor;
  theme?: string;
  size?: number | string;
  className?: string;
  isGhost?: boolean;
  isClearing?: boolean;
  glow?: boolean;
}

/**
 * Premium Core & Fruit Bubble Component
 * Renders the default glossy 3D Fruit Bubble or any of the 20 visually unique Core Themes:
 * 1. Crystal Core
 * 2. Diamond Core
 * 3. Galaxy Core
 * 4. Plasma Core
 * 5. Neon Energy Core
 * 6. Lava Core
 * 7. Ice Crystal Core
 * 8. Holographic Core
 * 9. Electric Core
 * 10. Rainbow Glass Core
 * 11. Cosmic Nebula Core
 * 12. Golden Royal Core
 * 13. Shadow Phantom Core
 * 14. Aqua Bubble Core
 * 15. Cyber Tech Core
 * 16. Emerald Core
 * 17. Ruby Core
 * 18. Sapphire Core
 * 19. Solar Flare Core
 * 20. Mythic Dragon Core
 * + Default Fruit Bubble Core
 */
export const ReactorBlock: React.FC<ReactorBlockProps> = ({
  color,
  theme = 'core_fruit_bubble',
  size = '100%',
  className = '',
  isGhost = false,
  isClearing = false,
  glow = true,
}) => {
  const scheme = REACTOR_COLORS[color] || REACTOR_COLORS.blue;
  const rawId = useId();
  const uid = rawId.replace(/[^a-zA-Z0-9_-]/g, '_');

  // Normalize legacy skin IDs to default
  const activeTheme =
    !theme || theme === 'skin_pulse' || theme === 'default'
      ? 'core_fruit_bubble'
      : theme;

  return (
    <div
      className={`relative inline-flex items-center justify-center select-none overflow-visible ${
        isGhost ? 'opacity-65 scale-95 transition-all' : ''
      } ${
        isClearing
          ? 'scale-125 brightness-150 animate-ping transition-all duration-300'
          : 'hover:scale-[1.03] transition-transform duration-150'
      } ${className}`}
      style={{
        width: typeof size === 'number' ? `${size}px` : size,
        height: typeof size === 'number' ? `${size}px` : size,
      }}
    >
      <svg
        viewBox="0 0 100 100"
        className="w-full h-full block overflow-visible drop-shadow-[0_4px_10px_rgba(0,0,0,0.35)]"
        xmlns="http://www.w3.org/2000/svg"
      >
        {renderThemeContent(activeTheme, scheme, uid, glow, isGhost)}
      </svg>
    </div>
  );
};

// Dispatcher to render the appropriate Core Theme SVG content
function renderThemeContent(
  theme: string,
  scheme: any,
  uid: string,
  glow: boolean,
  isGhost: boolean
) {
  switch (theme) {
    case 'core_crystal':
      return renderCrystalCore(scheme, uid, glow, isGhost);
    case 'core_diamond':
      return renderDiamondCore(scheme, uid, glow, isGhost);
    case 'core_galaxy':
      return renderGalaxyCore(scheme, uid, glow, isGhost);
    case 'core_plasma':
      return renderPlasmaCore(scheme, uid, glow, isGhost);
    case 'core_neon':
      return renderNeonCore(scheme, uid, glow, isGhost);
    case 'core_lava':
      return renderLavaCore(scheme, uid, glow, isGhost);
    case 'core_ice':
      return renderIceCore(scheme, uid, glow, isGhost);
    case 'core_holographic':
      return renderHolographicCore(scheme, uid, glow, isGhost);
    case 'core_electric':
      return renderElectricCore(scheme, uid, glow, isGhost);
    case 'core_rainbow':
      return renderRainbowCore(scheme, uid, glow, isGhost);
    case 'core_cosmic':
      return renderCosmicCore(scheme, uid, glow, isGhost);
    case 'core_gold':
      return renderGoldCore(scheme, uid, glow, isGhost);
    case 'core_shadow':
      return renderShadowCore(scheme, uid, glow, isGhost);
    case 'core_aqua':
      return renderAquaCore(scheme, uid, glow, isGhost);
    case 'core_cyber':
      return renderCyberCore(scheme, uid, glow, isGhost);
    case 'core_emerald':
      return renderEmeraldCore(scheme, uid, glow, isGhost);
    case 'core_ruby':
      return renderRubyCore(scheme, uid, glow, isGhost);
    case 'core_sapphire':
      return renderSapphireCore(scheme, uid, glow, isGhost);
    case 'core_solar':
      return renderSolarCore(scheme, uid, glow, isGhost);
    case 'core_dragon':
      return renderDragonCore(scheme, uid, glow, isGhost);
    case 'core_fruit_bubble':
    default:
      return renderFruitBubbleCore(scheme, uid, glow, isGhost);
  }
}

/* =========================================================================
   0. DEFAULT: GLOSSY 3D FRUIT BUBBLE
   ========================================================================= */
function renderFruitBubbleCore(scheme: any, uid: string, glow: boolean, isGhost: boolean) {
  const gradJuiceId = `fruit-juice-${uid}`;
  const gradGlossId = `fruit-gloss-${uid}`;
  const gradRimId = `fruit-rim-${uid}`;
  const gradCausticId = `fruit-caustic-${uid}`;

  return (
    <>
      <defs>
        <radialGradient id={gradJuiceId} cx="36%" cy="34%" r="68%">
          <stop offset="0%" stopColor={scheme.coreHighlight} stopOpacity="1" />
          <stop offset="28%" stopColor={scheme.core} stopOpacity="1" />
          <stop offset="68%" stopColor={scheme.primary} stopOpacity="0.98" />
          <stop offset="100%" stopColor={scheme.borderDark} stopOpacity="1" />
        </radialGradient>
        <linearGradient id={gradGlossId} x1="0%" y1="0%" x2="65%" y2="85%">
          <stop offset="0%" stopColor="#ffffff" stopOpacity="0.95" />
          <stop offset="40%" stopColor="#ffffff" stopOpacity="0.55" />
          <stop offset="80%" stopColor="#ffffff" stopOpacity="0.08" />
          <stop offset="100%" stopColor="#ffffff" stopOpacity="0" />
        </linearGradient>
        <linearGradient id={gradRimId} x1="20%" y1="0%" x2="80%" y2="100%">
          <stop offset="0%" stopColor="#ffffff" stopOpacity="0.75" />
          <stop offset="45%" stopColor={scheme.borderLight} stopOpacity="0.6" />
          <stop offset="80%" stopColor={scheme.primary} stopOpacity="0.4" />
          <stop offset="100%" stopColor={scheme.borderDark} stopOpacity="0.8" />
        </linearGradient>
        <radialGradient id={gradCausticId} cx="68%" cy="74%" r="45%">
          <stop offset="0%" stopColor={scheme.coreHighlight} stopOpacity="0.75" />
          <stop offset="50%" stopColor={scheme.core} stopOpacity="0.35" />
          <stop offset="100%" stopColor={scheme.primary} stopOpacity="0" />
        </radialGradient>
      </defs>

      {glow && !isGhost && (
        <rect x="4" y="4" width="92" height="92" rx="22" fill="none" stroke={scheme.plasmaGlow} strokeWidth="3.5" opacity="0.4" />
      )}
      <rect x="6" y="6" width="88" height="88" rx="22" fill={`url(#${gradJuiceId})`} stroke={`url(#${gradRimId})`} strokeWidth="2.2" />
      <rect x="12" y="12" width="76" height="76" rx="18" fill={`url(#${gradCausticId})`} pointerEvents="none" />
      <rect x="10" y="10" width="80" height="80" rx="19" fill="none" stroke={scheme.coreHighlight} strokeWidth="1" opacity="0.3" />
      <ellipse cx="34" cy="26" rx="22" ry="12" transform="rotate(-26 34 26)" fill={`url(#${gradGlossId})`} pointerEvents="none" />
      <circle cx="28" cy="22" r="4.2" fill="#ffffff" opacity="0.92" pointerEvents="none" />
      <circle cx="42" cy="18" r="2" fill="#ffffff" opacity="0.8" pointerEvents="none" />
      <path d="M 32 82 C 48 88, 70 86, 78 72 C 75 75, 54 81, 32 82 Z" fill="#ffffff" opacity="0.4" pointerEvents="none" />
    </>
  );
}

/* =========================================================================
   1. CRYSTAL CORE: Transparent faceted geometric crystal
   ========================================================================= */
function renderCrystalCore(scheme: any, uid: string, glow: boolean, isGhost: boolean) {
  const gradId = `crys-${uid}`;
  return (
    <>
      <defs>
        <linearGradient id={gradId} x1="10%" y1="10%" x2="90%" y2="90%">
          <stop offset="0%" stopColor="#ffffff" stopOpacity="0.9" />
          <stop offset="25%" stopColor={scheme.coreHighlight} stopOpacity="0.7" />
          <stop offset="70%" stopColor={scheme.primary} stopOpacity="0.5" />
          <stop offset="100%" stopColor={scheme.borderDark} stopOpacity="0.85" />
        </linearGradient>
      </defs>
      {glow && !isGhost && (
        <rect x="4" y="4" width="92" height="92" rx="16" fill="none" stroke={scheme.coreHighlight} strokeWidth="2" opacity="0.5" />
      )}
      <rect x="8" y="8" width="84" height="84" rx="14" fill={`url(#${gradId})`} stroke="#ffffff" strokeWidth="2" />
      {/* Facet lines */}
      <polygon points="50,12 88,50 50,88 12,50" fill="none" stroke="#ffffff" strokeWidth="1.5" opacity="0.6" />
      <line x1="8" y1="8" x2="50" y2="50" stroke="#ffffff" strokeWidth="1.5" opacity="0.5" />
      <line x1="92" y1="8" x2="50" y2="50" stroke="#ffffff" strokeWidth="1.5" opacity="0.5" />
      <line x1="8" y1="92" x2="50" y2="50" stroke="#ffffff" strokeWidth="1.5" opacity="0.5" />
      <line x1="92" y1="92" x2="50" y2="50" stroke="#ffffff" strokeWidth="1.5" opacity="0.5" />
      {/* 4-point sparkle */}
      <polygon points="50,22 53,30 61,30 55,35 57,43 50,38 43,43 45,35 39,30 47,30" fill="#ffffff" opacity="0.9" />
      <circle cx="50" cy="50" r="8" fill="#ffffff" opacity="0.4" />
    </>
  );
}

/* =========================================================================
   2. DIAMOND CORE: Brilliant diamond-cut glossy jewel
   ========================================================================= */
function renderDiamondCore(scheme: any, uid: string, glow: boolean, isGhost: boolean) {
  const gradId = `dia-${uid}`;
  return (
    <>
      <defs>
        <radialGradient id={gradId} cx="40%" cy="40%" r="60%">
          <stop offset="0%" stopColor="#ffffff" stopOpacity="0.98" />
          <stop offset="35%" stopColor="#e0e7ff" stopOpacity="0.8" />
          <stop offset="70%" stopColor={scheme.core} stopOpacity="0.6" />
          <stop offset="100%" stopColor="#1e1b4b" stopOpacity="0.9" />
        </radialGradient>
      </defs>
      {glow && !isGhost && (
        <rect x="4" y="4" width="92" height="92" rx="18" fill="none" stroke="#e0e7ff" strokeWidth="3" opacity="0.5" />
      )}
      <rect x="7" y="7" width="86" height="86" rx="16" fill={`url(#${gradId})`} stroke="#ffffff" strokeWidth="2.5" />
      {/* Diamond table facet & kites */}
      <polygon points="50,14 78,32 78,68 50,86 22,68 22,32" fill="#ffffff" fillOpacity="0.25" stroke="#ffffff" strokeWidth="1.8" />
      <polygon points="50,26 68,40 68,60 50,74 32,60 32,40" fill="#ffffff" fillOpacity="0.35" stroke="#ffffff" strokeWidth="1.5" />
      {/* Sparkles */}
      <polygon points="30,22 32,27 37,27 33,30 35,35 30,32 25,35 27,30 23,27 28,27" fill="#ffffff" />
      <circle cx="68" cy="30" r="3" fill="#ffffff" />
    </>
  );
}

/* =========================================================================
   3. GALAXY CORE: Deep space spiral galaxy with stars
   ========================================================================= */
function renderGalaxyCore(scheme: any, uid: string, glow: boolean, isGhost: boolean) {
  const gradId = `gal-${uid}`;
  return (
    <>
      <defs>
        <radialGradient id={gradId} cx="50%" cy="50%" r="55%">
          <stop offset="0%" stopColor="#ffffff" stopOpacity="1" />
          <stop offset="25%" stopColor={scheme.coreHighlight} stopOpacity="0.9" />
          <stop offset="60%" stopColor="#311042" stopOpacity="0.95" />
          <stop offset="100%" stopColor="#07020d" stopOpacity="1" />
        </radialGradient>
      </defs>
      {glow && !isGhost && (
        <rect x="4" y="4" width="92" height="92" rx="20" fill="none" stroke={scheme.plasmaGlow} strokeWidth="2.5" opacity="0.6" />
      )}
      <rect x="6" y="6" width="88" height="88" rx="18" fill={`url(#${gradId})`} stroke="#c084fc" strokeWidth="1.8" />
      {/* Spiral Galaxy Arms */}
      <ellipse cx="50" cy="50" rx="34" ry="14" transform="rotate(-30 50 50)" fill="none" stroke="#f472b6" strokeWidth="3" opacity="0.6" strokeDasharray="12 6" />
      <ellipse cx="50" cy="50" rx="26" ry="10" transform="rotate(45 50 50)" fill="none" stroke="#38bdf8" strokeWidth="2.5" opacity="0.6" strokeDasharray="8 5" />
      {/* Galactic Core Center */}
      <circle cx="50" cy="50" r="9" fill="#ffffff" filter="drop-shadow(0 0 6px #ffffff)" />
      {/* Field Stars */}
      <circle cx="22" cy="24" r="1.5" fill="#ffffff" />
      <circle cx="78" cy="28" r="1.8" fill="#ffffff" />
      <circle cx="30" cy="74" r="1.5" fill="#fde047" />
      <circle cx="72" cy="70" r="1.2" fill="#ffffff" />
    </>
  );
}

/* =========================================================================
   4. PLASMA CORE: High-energy kinetic plasma orb
   ========================================================================= */
function renderPlasmaCore(scheme: any, uid: string, glow: boolean, isGhost: boolean) {
  const gradId = `plas-${uid}`;
  return (
    <>
      <defs>
        <radialGradient id={gradId} cx="50%" cy="50%" r="50%">
          <stop offset="0%" stopColor="#ffffff" />
          <stop offset="40%" stopColor={scheme.coreHighlight} />
          <stop offset="75%" stopColor={scheme.primary} />
          <stop offset="100%" stopColor="#2e1065" />
        </radialGradient>
      </defs>
      {glow && !isGhost && (
        <circle cx="50" cy="50" r="44" fill="none" stroke={scheme.coreHighlight} strokeWidth="4" opacity="0.45" />
      )}
      <rect x="7" y="7" width="86" height="86" rx="20" fill="#0f051d" stroke={scheme.coreHighlight} strokeWidth="2" />
      <circle cx="50" cy="50" r="32" fill={`url(#${gradId})`} />
      {/* Kinetic Plasma Filament Rings */}
      <ellipse cx="50" cy="50" rx="28" ry="12" fill="none" stroke="#ffffff" strokeWidth="2" opacity="0.75" transform="rotate(25 50 50)" />
      <ellipse cx="50" cy="50" rx="28" ry="12" fill="none" stroke="#ffffff" strokeWidth="2" opacity="0.75" transform="rotate(-35 50 50)" />
      <circle cx="50" cy="50" r="12" fill="#ffffff" opacity="0.9" />
    </>
  );
}

/* =========================================================================
   5. NEON ENERGY CORE: Double glowing neon gas tube
   ========================================================================= */
function renderNeonCore(scheme: any, uid: string, glow: boolean, isGhost: boolean) {
  return (
    <>
      <rect x="6" y="6" width="88" height="88" rx="18" fill="#090514" stroke="#1f1435" strokeWidth="2" />
      {/* Outer Neon Tube */}
      <rect x="12" y="12" width="76" height="76" rx="14" fill="none" stroke={scheme.primary} strokeWidth="4" filter="drop-shadow(0 0 8px currentColor)" />
      <rect x="12" y="12" width="76" height="76" rx="14" fill="none" stroke="#ffffff" strokeWidth="1.5" />
      {/* Inner Neon Ring */}
      <circle cx="50" cy="50" r="18" fill="none" stroke={scheme.coreHighlight} strokeWidth="3" filter="drop-shadow(0 0 6px currentColor)" />
      <circle cx="50" cy="50" r="6" fill="#ffffff" />
      {/* Corner Electrodes */}
      <circle cx="20" cy="20" r="2.5" fill="#ffffff" />
      <circle cx="80" cy="20" r="2.5" fill="#ffffff" />
      <circle cx="20" cy="80" r="2.5" fill="#ffffff" />
      <circle cx="80" cy="80" r="2.5" fill="#ffffff" />
    </>
  );
}

/* =========================================================================
   6. LAVA CORE: Cracked volcanic obsidian crust with glowing molten magma
   ========================================================================= */
function renderLavaCore(scheme: any, uid: string, glow: boolean, isGhost: boolean) {
  const gradMagma = `lava-${uid}`;
  return (
    <>
      <defs>
        <radialGradient id={gradMagma} cx="45%" cy="45%" r="55%">
          <stop offset="0%" stopColor="#fef08a" />
          <stop offset="30%" stopColor="#f97316" />
          <stop offset="70%" stopColor="#dc2626" />
          <stop offset="100%" stopColor="#450a0a" />
        </radialGradient>
      </defs>
      {glow && !isGhost && (
        <rect x="4" y="4" width="92" height="92" rx="18" fill="none" stroke="#f97316" strokeWidth="3" opacity="0.5" />
      )}
      {/* Base Molten Magma */}
      <rect x="7" y="7" width="86" height="86" rx="16" fill={`url(#${gradMagma})`} stroke="#ea580c" strokeWidth="2.5" />
      {/* Cracked Obsidian Crust Blocks */}
      <path d="M 12 12 L 44 14 L 38 40 L 14 36 Z" fill="#1c1917" stroke="#450a0a" strokeWidth="1.5" />
      <path d="M 52 14 L 86 12 L 84 38 L 48 42 Z" fill="#292524" stroke="#450a0a" strokeWidth="1.5" />
      <path d="M 14 46 L 40 48 L 36 84 L 12 86 Z" fill="#292524" stroke="#450a0a" strokeWidth="1.5" />
      <path d="M 48 50 L 84 46 L 86 86 L 46 84 Z" fill="#1c1917" stroke="#450a0a" strokeWidth="1.5" />
      {/* Glowing Fissure Center */}
      <circle cx="44" cy="45" r="4.5" fill="#fef08a" filter="drop-shadow(0 0 5px #facc15)" />
    </>
  );
}

/* =========================================================================
   7. ICE CRYSTAL CORE: Sub-zero glacial ice with snowflake
   ========================================================================= */
function renderIceCore(scheme: any, uid: string, glow: boolean, isGhost: boolean) {
  const gradId = `ice-${uid}`;
  return (
    <>
      <defs>
        <linearGradient id={gradId} x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stopColor="#f0f9ff" />
          <stop offset="40%" stopColor="#bae6fd" />
          <stop offset="80%" stopColor="#0284c7" />
          <stop offset="100%" stopColor="#0c4a6e" />
        </linearGradient>
      </defs>
      {glow && !isGhost && (
        <rect x="4" y="4" width="92" height="92" rx="18" fill="none" stroke="#7dd3fc" strokeWidth="3" opacity="0.6" />
      )}
      <rect x="7" y="7" width="86" height="86" rx="16" fill={`url(#${gradId})`} stroke="#ffffff" strokeWidth="2.2" />
      {/* Frosty Hexagonal Snowflake Core */}
      <g stroke="#ffffff" strokeWidth="2" strokeLinecap="round">
        <line x1="50" y1="22" x2="50" y2="78" />
        <line x1="26" y1="36" x2="74" y2="64" />
        <line x1="26" y1="64" x2="74" y2="36" />
        {/* Crystal prongs */}
        <line x1="50" y1="28" x2="44" y2="34" />
        <line x1="50" y1="28" x2="56" y2="34" />
        <line x1="50" y1="72" x2="44" y2="66" />
        <line x1="50" y1="72" x2="56" y2="66" />
      </g>
      <circle cx="50" cy="50" r="5" fill="#ffffff" />
      {/* Glacial top sheen */}
      <path d="M 12 12 Q 50 20 86 14 L 82 24 Q 50 28 16 22 Z" fill="#ffffff" opacity="0.65" />
    </>
  );
}

/* =========================================================================
   8. HOLOGRAPHIC CORE: Iridescent scanlines & 3D wireframe cube
   ========================================================================= */
function renderHolographicCore(scheme: any, uid: string, glow: boolean, isGhost: boolean) {
  const gradHolo = `holo-${uid}`;
  return (
    <>
      <defs>
        <linearGradient id={gradHolo} x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stopColor="#2dd4bf" />
          <stop offset="50%" stopColor="#f472b6" />
          <stop offset="100%" stopColor="#818cf8" />
        </linearGradient>
      </defs>
      <rect x="7" y="7" width="86" height="86" rx="16" fill="#0d1117" stroke={`url(#${gradHolo})`} strokeWidth="2.5" />
      {/* Hologram Scanlines */}
      {[20, 28, 36, 44, 52, 60, 68, 76].map((y) => (
        <line key={y} x1="12" y1={y} x2="88" y2={y} stroke={`url(#${gradHolo})`} strokeWidth="1" opacity="0.4" />
      ))}
      {/* Central 3D Isometric Wireframe Cube */}
      <polygon points="50,26 72,38 50,50 28,38" fill="none" stroke="#ffffff" strokeWidth="2" opacity="0.85" />
      <polygon points="28,38 50,50 50,74 28,62" fill="none" stroke="#2dd4bf" strokeWidth="2" opacity="0.85" />
      <polygon points="72,38 50,50 50,74 72,62" fill="none" stroke="#f472b6" strokeWidth="2" opacity="0.85" />
      <circle cx="50" cy="50" r="4" fill="#ffffff" />
    </>
  );
}

/* =========================================================================
   9. ELECTRIC CORE: High-voltage jagged lightning bolt
   ========================================================================= */
function renderElectricCore(scheme: any, uid: string, glow: boolean, isGhost: boolean) {
  return (
    <>
      {glow && !isGhost && (
        <rect x="4" y="4" width="92" height="92" rx="18" fill="none" stroke="#facc15" strokeWidth="3" opacity="0.55" />
      )}
      <rect x="7" y="7" width="86" height="86" rx="16" fill="#17120a" stroke="#ca8a04" strokeWidth="2.5" />
      {/* Energy Rings */}
      <circle cx="50" cy="50" r="30" fill="none" stroke="#facc15" strokeWidth="1.5" opacity="0.4" strokeDasharray="6 4" />
      {/* Jagged Lightning Bolt */}
      <polygon
        points="54,14 32,46 48,46 36,86 68,44 52,44"
        fill="#fde047"
        stroke="#ffffff"
        strokeWidth="2"
        filter="drop-shadow(0 0 8px #eab308)"
      />
      {/* Sparks */}
      <circle cx="26" cy="34" r="2" fill="#ffffff" />
      <circle cx="74" cy="62" r="2" fill="#ffffff" />
    </>
  );
}

/* =========================================================================
   10. RAINBOW GLASS CORE: 7-band chromatic spectrum reflection
   ========================================================================= */
function renderRainbowCore(scheme: any, uid: string, glow: boolean, isGhost: boolean) {
  const gradRain = `rain-${uid}`;
  return (
    <>
      <defs>
        <linearGradient id={gradRain} x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stopColor="#ff4d4d" />
          <stop offset="18%" stopColor="#ffa500" />
          <stop offset="36%" stopColor="#ffff00" />
          <stop offset="54%" stopColor="#00e676" />
          <stop offset="72%" stopColor="#00b0ff" />
          <stop offset="90%" stopColor="#d500f9" />
          <stop offset="100%" stopColor="#ff4081" />
        </linearGradient>
      </defs>
      {glow && !isGhost && (
        <rect x="4" y="4" width="92" height="92" rx="22" fill="none" stroke={`url(#${gradRain})`} strokeWidth="3" opacity="0.6" />
      )}
      <rect x="7" y="7" width="86" height="86" rx="20" fill={`url(#${gradRain})`} stroke="#ffffff" strokeWidth="2.5" />
      {/* Transparent Glass Bubble Overlay */}
      <rect x="12" y="12" width="76" height="76" rx="16" fill="#ffffff" fillOpacity="0.2" />
      <ellipse cx="36" cy="28" rx="22" ry="12" transform="rotate(-26 36 28)" fill="#ffffff" fillOpacity="0.75" />
      <circle cx="30" cy="24" r="4" fill="#ffffff" />
      <path d="M 30 80 Q 50 86 76 74" stroke="#ffffff" strokeWidth="3" fill="none" opacity="0.6" strokeLinecap="round" />
    </>
  );
}

/* =========================================================================
   11. COSMIC NEBULA CORE: Interstellar stardust clouds & nova
   ========================================================================= */
function renderCosmicCore(scheme: any, uid: string, glow: boolean, isGhost: boolean) {
  const gradNeb = `neb-${uid}`;
  return (
    <>
      <defs>
        <radialGradient id={gradNeb} cx="50%" cy="50%" r="55%">
          <stop offset="0%" stopColor="#fdf4ff" />
          <stop offset="30%" stopColor="#d946ef" />
          <stop offset="70%" stopColor="#4c1d95" />
          <stop offset="100%" stopColor="#090214" />
        </radialGradient>
      </defs>
      <rect x="7" y="7" width="86" height="86" rx="18" fill={`url(#${gradNeb})`} stroke="#f472b6" strokeWidth="2" />
      {/* Stardust Dust Clouds */}
      <circle cx="38" cy="42" r="18" fill="#06b6d4" opacity="0.35" filter="blur(4px)" />
      <circle cx="62" cy="58" r="20" fill="#ec4899" opacity="0.4" filter="blur(4px)" />
      {/* 4-point Grand Nova Star */}
      <polygon points="50,24 53,42 71,45 54,49 57,67 48,51 31,54 45,46" fill="#ffffff" filter="drop-shadow(0 0 5px #ffffff)" />
      <circle cx="50" cy="46" r="4" fill="#fef08a" />
      <circle cx="24" cy="74" r="1.5" fill="#ffffff" />
      <circle cx="76" cy="24" r="1.5" fill="#ffffff" />
    </>
  );
}

/* =========================================================================
   12. GOLDEN ROYAL CORE: Solid 24K bullion bevel with imperial crest
   ========================================================================= */
function renderGoldCore(scheme: any, uid: string, glow: boolean, isGhost: boolean) {
  const gradGold = `gold-${uid}`;
  return (
    <>
      <defs>
        <linearGradient id={gradGold} x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stopColor="#fef08a" />
          <stop offset="25%" stopColor="#facc15" />
          <stop offset="60%" stopColor="#ca8a04" />
          <stop offset="85%" stopColor="#eab308" />
          <stop offset="100%" stopColor="#854d0e" />
        </linearGradient>
      </defs>
      {glow && !isGhost && (
        <rect x="4" y="4" width="92" height="92" rx="16" fill="none" stroke="#fbbf24" strokeWidth="3" opacity="0.6" />
      )}
      <rect x="7" y="7" width="86" height="86" rx="14" fill={`url(#${gradGold})`} stroke="#ffffff" strokeWidth="2.5" />
      {/* Inner Bevel Border */}
      <rect x="15" y="15" width="70" height="70" rx="10" fill="none" stroke="#fef08a" strokeWidth="2" strokeDasharray="8 4" />
      {/* Imperial Crown Emblem */}
      <polygon points="34,60 30,42 42,48 50,34 58,48 70,42 66,60" fill="#fef08a" stroke="#854d0e" strokeWidth="1.5" />
      <circle cx="50" cy="34" r="2.5" fill="#ffffff" />
      <circle cx="30" cy="42" r="2" fill="#ef4444" />
      <circle cx="70" cy="42" r="2" fill="#3b82f6" />
      {/* Specular Gleam Streak */}
      <line x1="20" y1="18" x2="80" y2="78" stroke="#ffffff" strokeWidth="2" opacity="0.6" strokeLinecap="round" />
    </>
  );
}

/* =========================================================================
   13. SHADOW PHANTOM CORE: Dark matter void with violet phantom flames
   ========================================================================= */
function renderShadowCore(scheme: any, uid: string, glow: boolean, isGhost: boolean) {
  const gradDark = `shad-${uid}`;
  return (
    <>
      <defs>
        <radialGradient id={gradDark} cx="50%" cy="50%" r="55%">
          <stop offset="0%" stopColor="#7c3aed" />
          <stop offset="40%" stopColor="#3b0764" />
          <stop offset="85%" stopColor="#090514" />
          <stop offset="100%" stopColor="#000000" />
        </radialGradient>
      </defs>
      {glow && !isGhost && (
        <rect x="4" y="4" width="92" height="92" rx="18" fill="none" stroke="#a855f7" strokeWidth="3" opacity="0.5" />
      )}
      <rect x="7" y="7" width="86" height="86" rx="16" fill={`url(#${gradDark})`} stroke="#a855f7" strokeWidth="2" />
      {/* Phantom Fire Wisps */}
      <path
        d="M 50 18 C 36 34 30 50 38 68 C 42 76 50 82 50 82 C 50 82 58 76 62 68 C 70 50 64 34 50 18 Z"
        fill="#c084fc"
        opacity="0.5"
      />
      <circle cx="50" cy="54" r="8" fill="#ffffff" filter="drop-shadow(0 0 6px #d8b4fe)" />
      {/* Arcane Rune Horns */}
      <path d="M 32 38 Q 42 46 50 46 Q 58 46 68 38" fill="none" stroke="#a855f7" strokeWidth="2.5" strokeLinecap="round" />
    </>
  );
}

/* =========================================================================
   14. AQUA BUBBLE CORE: Pure liquid water drop with micro-bubbles
   ========================================================================= */
function renderAquaCore(scheme: any, uid: string, glow: boolean, isGhost: boolean) {
  const gradAqua = `aqua-${uid}`;
  return (
    <>
      <defs>
        <radialGradient id={gradAqua} cx="38%" cy="36%" r="65%">
          <stop offset="0%" stopColor="#e0f2fe" />
          <stop offset="35%" stopColor="#38bdf8" />
          <stop offset="75%" stopColor="#0284c7" />
          <stop offset="100%" stopColor="#075985" />
        </radialGradient>
      </defs>
      {glow && !isGhost && (
        <rect x="4" y="4" width="92" height="92" rx="22" fill="none" stroke="#38bdf8" strokeWidth="3" opacity="0.45" />
      )}
      <rect x="7" y="7" width="86" height="86" rx="20" fill={`url(#${gradAqua})`} stroke="#bae6fd" strokeWidth="2.5" />
      {/* Floating Micro Air Bubbles */}
      <circle cx="34" cy="62" r="5" fill="#ffffff" fillOpacity="0.45" stroke="#ffffff" strokeWidth="1" />
      <circle cx="66" cy="68" r="4" fill="#ffffff" fillOpacity="0.45" stroke="#ffffff" strokeWidth="1" />
      <circle cx="56" cy="42" r="3" fill="#ffffff" fillOpacity="0.5" />
      {/* Water Gloss Sheen */}
      <ellipse cx="36" cy="24" rx="20" ry="10" transform="rotate(-20 36 24)" fill="#ffffff" opacity="0.8" />
      <circle cx="30" cy="22" r="3" fill="#ffffff" />
      {/* Bottom Caustic Wave */}
      <path d="M 24 74 Q 50 84 76 72" stroke="#ffffff" strokeWidth="2.5" fill="none" opacity="0.6" strokeLinecap="round" />
    </>
  );
}

/* =========================================================================
   15. CYBER TECH CORE: Hexagonal microchip lattice & conduits
   ========================================================================= */
function renderCyberCore(scheme: any, uid: string, glow: boolean, isGhost: boolean) {
  return (
    <>
      <rect x="7" y="7" width="86" height="86" rx="14" fill="#0b1120" stroke="#00f0ff" strokeWidth="2.5" />
      {/* Circuit Bus Lines */}
      <g stroke="#00f0ff" strokeWidth="1.8" opacity="0.65" fill="none">
        <path d="M 12 30 L 32 30 L 40 40" />
        <path d="M 88 30 L 68 30 L 60 40" />
        <path d="M 12 70 L 32 70 L 40 60" />
        <path d="M 88 70 L 68 70 L 60 60" />
        <line x1="50" y1="12" x2="50" y2="34" />
        <line x1="50" y1="88" x2="50" y2="66" />
      </g>
      {/* Central Hexagonal Chip Node */}
      <polygon points="50,36 62,43 62,57 50,64 38,57 38,43" fill="#0284c7" stroke="#ffffff" strokeWidth="2" />
      <circle cx="50" cy="50" r="5" fill="#facc15" />
      <circle cx="14" cy="30" r="2" fill="#00f0ff" />
      <circle cx="86" cy="30" r="2" fill="#00f0ff" />
      <circle cx="14" cy="70" r="2" fill="#00f0ff" />
      <circle cx="86" cy="70" r="2" fill="#00f0ff" />
    </>
  );
}

/* =========================================================================
   16. EMERALD CORE: Step-cut beryl gemstone
   ========================================================================= */
function renderEmeraldCore(scheme: any, uid: string, glow: boolean, isGhost: boolean) {
  const gradEm = `em-${uid}`;
  return (
    <>
      <defs>
        <linearGradient id={gradEm} x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stopColor="#6ee7b7" />
          <stop offset="40%" stopColor="#10b981" />
          <stop offset="80%" stopColor="#047857" />
          <stop offset="100%" stopColor="#064e3b" />
        </linearGradient>
      </defs>
      {glow && !isGhost && (
        <rect x="4" y="4" width="92" height="92" rx="16" fill="none" stroke="#34d399" strokeWidth="3" opacity="0.6" />
      )}
      <rect x="7" y="7" width="86" height="86" rx="14" fill={`url(#${gradEm})`} stroke="#a7f3d0" strokeWidth="2.5" />
      {/* Step-Cut Rectangles */}
      <rect x="18" y="18" width="64" height="64" fill="none" stroke="#ffffff" strokeWidth="2" opacity="0.75" />
      <rect x="28" y="28" width="44" height="44" fill="#34d399" fillOpacity="0.3" stroke="#ffffff" strokeWidth="1.5" />
      {/* Corner diagonal facet lines */}
      <line x1="7" y1="7" x2="28" y2="28" stroke="#ffffff" strokeWidth="1.8" opacity="0.7" />
      <line x1="93" y1="7" x2="72" y2="28" stroke="#ffffff" strokeWidth="1.8" opacity="0.7" />
      <line x1="7" y1="93" x2="28" y2="72" stroke="#ffffff" strokeWidth="1.8" opacity="0.7" />
      <line x1="93" y1="93" x2="72" y2="72" stroke="#ffffff" strokeWidth="1.8" opacity="0.7" />
      <circle cx="34" cy="34" r="3" fill="#ffffff" />
    </>
  );
}

/* =========================================================================
   17. RUBY CORE: Cushion-cut pigeon blood ruby
   ========================================================================= */
function renderRubyCore(scheme: any, uid: string, glow: boolean, isGhost: boolean) {
  const gradRuby = `rub-${uid}`;
  return (
    <>
      <defs>
        <radialGradient id={gradRuby} cx="42%" cy="40%" r="58%">
          <stop offset="0%" stopColor="#fecdd3" />
          <stop offset="35%" stopColor="#f43f5e" />
          <stop offset="75%" stopColor="#be123c" />
          <stop offset="100%" stopColor="#4c0519" />
        </radialGradient>
      </defs>
      {glow && !isGhost && (
        <rect x="4" y="4" width="92" height="92" rx="18" fill="none" stroke="#fb7185" strokeWidth="3" opacity="0.6" />
      )}
      <rect x="7" y="7" width="86" height="86" rx="16" fill={`url(#${gradRuby})`} stroke="#ffffff" strokeWidth="2.5" />
      {/* Radiant Jewel Facets */}
      <polygon points="50,15 85,50 50,85 15,50" fill="none" stroke="#ffffff" strokeWidth="2" opacity="0.75" />
      <polygon points="50,28 72,50 50,72 28,50" fill="#ffffff" fillOpacity="0.25" stroke="#ffffff" strokeWidth="1.5" />
      <circle cx="50" cy="50" r="7" fill="#ffffff" opacity="0.8" />
      <circle cx="32" cy="32" r="3.5" fill="#ffffff" />
    </>
  );
}

/* =========================================================================
   18. SAPPHIRE CORE: Royal octagonal brilliant cut
   ========================================================================= */
function renderSapphireCore(scheme: any, uid: string, glow: boolean, isGhost: boolean) {
  const gradSaph = `saph-${uid}`;
  return (
    <>
      <defs>
        <radialGradient id={gradSaph} cx="40%" cy="38%" r="60%">
          <stop offset="0%" stopColor="#dbeafe" />
          <stop offset="30%" stopColor="#3b82f6" />
          <stop offset="70%" stopColor="#1d4ed8" />
          <stop offset="100%" stopColor="#0f172a" />
        </radialGradient>
      </defs>
      {glow && !isGhost && (
        <rect x="4" y="4" width="92" height="92" rx="18" fill="none" stroke="#60a5fa" strokeWidth="3" opacity="0.6" />
      )}
      <rect x="7" y="7" width="86" height="86" rx="16" fill={`url(#${gradSaph})`} stroke="#bfdbfe" strokeWidth="2.5" />
      {/* Octagonal Table Facet */}
      <polygon points="35,16 65,16 84,35 84,65 65,84 35,84 16,65 16,35" fill="none" stroke="#ffffff" strokeWidth="2" opacity="0.75" />
      <polygon points="40,28 60,28 72,40 72,60 60,72 40,72 28,60 28,40" fill="#ffffff" fillOpacity="0.2" stroke="#ffffff" strokeWidth="1.5" />
      <circle cx="36" cy="34" r="3.5" fill="#ffffff" />
      <polygon points="66,66 69,72 75,72 70,76 72,82 66,78 60,82 62,76 57,72 63,72" fill="#ffffff" opacity="0.9" />
    </>
  );
}

/* =========================================================================
   19. SOLAR FLARE CORE: Blazing miniature star with coronal loops
   ========================================================================= */
function renderSolarCore(scheme: any, uid: string, glow: boolean, isGhost: boolean) {
  const gradSun = `sun-${uid}`;
  return (
    <>
      <defs>
        <radialGradient id={gradSun} cx="50%" cy="50%" r="50%">
          <stop offset="0%" stopColor="#ffffff" />
          <stop offset="35%" stopColor="#fef08a" />
          <stop offset="70%" stopColor="#f97316" />
          <stop offset="100%" stopColor="#9a3412" />
        </radialGradient>
      </defs>
      {glow && !isGhost && (
        <circle cx="50" cy="50" r="45" fill="none" stroke="#fbbf24" strokeWidth="4" opacity="0.5" />
      )}
      <rect x="7" y="7" width="86" height="86" rx="18" fill="#1c0a00" stroke="#f97316" strokeWidth="2" />
      <circle cx="50" cy="50" r="32" fill={`url(#${gradSun})`} filter="drop-shadow(0 0 10px #f59e0b)" />
      {/* Solar Prominence Flare Loops */}
      <path d="M 50 18 Q 62 8 68 22" fill="none" stroke="#fde047" strokeWidth="2.5" strokeLinecap="round" />
      <path d="M 82 50 Q 92 62 78 68" fill="none" stroke="#fde047" strokeWidth="2.5" strokeLinecap="round" />
      <path d="M 50 82 Q 38 92 32 78" fill="none" stroke="#fde047" strokeWidth="2.5" strokeLinecap="round" />
      <path d="M 18 50 Q 8 38 22 32" fill="none" stroke="#fde047" strokeWidth="2.5" strokeLinecap="round" />
      <circle cx="50" cy="50" r="14" fill="#ffffff" opacity="0.9" />
    </>
  );
}

/* =========================================================================
   20. MYTHIC DRAGON CORE: Scaled dragon-hide with glowing slit eye
   ========================================================================= */
function renderDragonCore(scheme: any, uid: string, glow: boolean, isGhost: boolean) {
  const gradDrag = `drag-${uid}`;
  return (
    <>
      <defs>
        <radialGradient id={gradDrag} cx="50%" cy="50%" r="55%">
          <stop offset="0%" stopColor="#fef08a" />
          <stop offset="40%" stopColor="#f97316" />
          <stop offset="80%" stopColor="#991b1b" />
          <stop offset="100%" stopColor="#1c0505" />
        </radialGradient>
      </defs>
      {glow && !isGhost && (
        <rect x="4" y="4" width="92" height="92" rx="18" fill="none" stroke="#dc2626" strokeWidth="3" opacity="0.6" />
      )}
      {/* Dragon Hide Armor */}
      <rect x="7" y="7" width="86" height="86" rx="16" fill="#180404" stroke="#dc2626" strokeWidth="2.5" />
      {/* Overlapping Dragon Scales */}
      <path d="M 16 28 Q 28 40 40 28 Q 52 40 64 28 Q 76 40 88 28" fill="none" stroke="#7f1d1d" strokeWidth="2.5" />
      <path d="M 16 50 Q 28 62 40 50 Q 52 62 64 50 Q 76 62 88 50" fill="none" stroke="#7f1d1d" strokeWidth="2.5" />
      <path d="M 16 72 Q 28 84 40 72 Q 52 84 64 72 Q 76 84 88 72" fill="none" stroke="#7f1d1d" strokeWidth="2.5" />
      {/* Glowing Golden Draconic Eye Core */}
      <ellipse cx="50" cy="50" rx="28" ry="18" fill={`url(#${gradDrag})`} stroke="#fbbf24" strokeWidth="2" filter="drop-shadow(0 0 8px #f59e0b)" />
      {/* Vertical Slit Pupil */}
      <ellipse cx="50" cy="50" rx="3.5" ry="14" fill="#000000" />
      {/* Dragonfire spark */}
      <circle cx="46" cy="44" r="2" fill="#ffffff" />
    </>
  );
}
