import React from 'react';
import {
  ArrowLeft,
  User,
  Trophy,
  Zap,
  Flame,
  Grid3X3,
  Star,
  Coins,
  Award,
  ShieldCheck,
} from 'lucide-react';
import { PlayerProfile } from '../types/game';
import { ReactorBlock } from './ReactorBlock';

interface ProfileScreenProps {
  profile: PlayerProfile;
  onBack: () => void;
}

export const ProfileScreen: React.FC<ProfileScreenProps> = ({
  profile,
  onBack,
}) => {
  const completedCount = Object.keys(profile.completedLevels).length;
  const totalStars = Object.values(profile.completedLevels).reduce(
    (acc, lvl) => acc + (lvl.stars || (lvl.completed ? 3 : 0)),
    0
  );

  let pilotRank = 'Bubble Cadet';
  if (profile.level >= 750) pilotRank = 'Fruit Grandmaster';
  else if (profile.level >= 500) pilotRank = 'Galaxy Legend';
  else if (profile.level >= 250) pilotRank = 'Citrus Champion';
  else if (profile.level >= 100) pilotRank = 'Highlands Hero';
  else if (profile.level >= 50) pilotRank = 'Meadow Explorer';
  else if (profile.level >= 25) pilotRank = 'Juice Vanguard';
  else if (profile.level >= 12) pilotRank = 'Bubble Architect';
  else if (profile.level >= 6) pilotRank = 'Grid Specialist';

  return (
    <div className="relative w-full h-[100dvh] max-h-[100dvh] flex flex-col justify-between px-3.5 pt-[max(10px,env(safe-area-inset-top))] pb-[max(12px,env(safe-area-inset-bottom))] text-white select-none overflow-hidden animate-fade-in max-w-[430px] mx-auto">
      {/* Top Header */}
      <header className="w-full flex items-center justify-between shrink-0 mb-3 z-20">
        <button
          onClick={onBack}
          className="w-9 h-9 rounded-2xl btn-arcade flex items-center justify-center text-cyan-300 active:scale-95 transition-transform cursor-pointer"
          aria-label="Back"
        >
          <ArrowLeft className="w-4 h-4 text-cyan-200" />
        </button>

        <div className="text-center">
          <h2 className="text-lg font-black font-['Chakra_Petch',sans-serif] tracking-wider text-white uppercase drop-shadow-[0_2px_10px_rgba(255,51,102,0.4)]">
            PLAYER PROFILE
          </h2>
          <p className="text-[9px] font-mono font-bold tracking-widest text-pink-300 uppercase">
            CAREER & ACHIEVEMENTS
          </p>
        </div>

        <div className="w-9 h-9" />
      </header>

      {/* Main Profile Info Card */}
      <div className="flex-1 overflow-y-auto space-y-3 pr-1 z-10 overscroll-contain">
        {/* Pilot Identity Banner */}
        <div className="p-4 rounded-3xl score-panel-vibrant flex items-center gap-4 shadow-lg">
          <div className="relative w-16 h-16 rounded-2xl bg-gradient-to-tr from-pink-400 to-purple-600 flex items-center justify-center text-white shadow-[0_0_20px_rgba(255,51,102,0.5)] shrink-0">
            <ReactorBlock color="red" size={42} glow={true} />
            <div className="absolute -bottom-1 -right-1 p-1 rounded-lg bg-black/80 border border-pink-400">
              <ShieldCheck className="w-3 h-3 text-pink-300" />
            </div>
          </div>

          <div className="text-left flex-1">
            <div className="flex items-center gap-1.5">
              <h3 className="text-lg font-black font-['Chakra_Petch',sans-serif] text-white">
                Bubble Master
              </h3>
            </div>
            <div className="text-xs font-mono font-black text-pink-300 uppercase tracking-wider">
              {pilotRank}
            </div>
            <div className="flex items-center gap-2 mt-1.5">
              <span className="px-2 py-0.5 rounded-full text-[9px] font-mono font-bold bg-white/10 text-pink-200 border border-pink-300/30">
                Level {profile.level}
              </span>
              <span className="px-2 py-0.5 rounded-full text-[9px] font-mono font-bold bg-amber-500/20 text-amber-300 border border-amber-400/40">
                ★ {totalStars} Stars
              </span>
            </div>
          </div>
        </div>

        {/* Currency Vault Showcase */}
        <div className="grid grid-cols-2 gap-2.5">
          <div className="p-3 rounded-2xl bg-amber-950/40 border border-amber-400/30 flex items-center gap-3 shadow-md">
            <div className="w-10 h-10 rounded-xl bg-amber-500/20 border border-amber-400/50 flex items-center justify-center text-amber-300">
              <Coins className="w-5 h-5 fill-amber-400" />
            </div>
            <div className="text-left">
              <div className="text-[9px] font-mono font-bold text-amber-300/80 uppercase">
                COIN VAULT
              </div>
              <div className="text-base font-black font-mono text-amber-100">
                {profile.coins.toLocaleString()}
              </div>
            </div>
          </div>

          <div className="p-3 rounded-2xl bg-yellow-950/40 border border-yellow-400/30 flex items-center gap-3 shadow-md">
            <div className="w-10 h-10 rounded-xl bg-yellow-500/20 border border-yellow-400/50 flex items-center justify-center text-yellow-300">
              <Star className="w-5 h-5 fill-yellow-400" />
            </div>
            <div className="text-left">
              <div className="text-[9px] font-mono font-bold text-yellow-300/80 uppercase">
                LEVEL STARS
              </div>
              <div className="text-base font-black font-mono text-yellow-100">
                {totalStars.toLocaleString()}
              </div>
            </div>
          </div>
        </div>

        {/* High Score Peak Card */}
        <div className="p-3.5 rounded-2xl higher-score-panel flex items-center justify-between shadow-md">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-xl bg-yellow-400/20 border border-yellow-400/40 text-yellow-300">
              <Trophy className="w-5 h-5 fill-yellow-400" />
            </div>
            <div className="text-left">
              <div className="text-[10px] font-mono font-black text-amber-200 uppercase">
                ALL-TIME HIGHEST PULSE SCORE
              </div>
              <div className="text-2xl font-black font-mono text-white leading-none">
                {profile.highScore.toLocaleString()}
              </div>
            </div>
          </div>
          <span className="text-[10px] font-mono font-bold text-amber-300/80">PEAK</span>
        </div>

        {/* Comprehensive Statistics Grid */}
        <div>
          <h4 className="text-[11px] font-mono font-bold text-cyan-300/80 uppercase tracking-wider mb-2 text-left">
            Career Metrics
          </h4>

          <div className="grid grid-cols-2 gap-2 text-left">
            <div className="p-2.5 rounded-2xl bg-white/[0.04] border border-white/10">
              <div className="flex items-center gap-1.5 text-[10px] font-bold text-white/60 mb-0.5">
                <Award className="w-3.5 h-3.5 text-cyan-400" />
                <span>COMPLETED LEVELS</span>
              </div>
              <div className="text-base font-black font-mono text-white">
                {completedCount}
              </div>
            </div>

            <div className="p-2.5 rounded-2xl bg-white/[0.04] border border-white/10">
              <div className="flex items-center gap-1.5 text-[10px] font-bold text-white/60 mb-0.5">
                <Zap className="w-3.5 h-3.5 text-sky-400" />
                <span>TOTAL LINES CLEARED</span>
              </div>
              <div className="text-base font-black font-mono text-white">
                {profile.totalLines.toLocaleString()}
              </div>
            </div>

            <div className="p-2.5 rounded-2xl bg-white/[0.04] border border-white/10">
              <div className="flex items-center gap-1.5 text-[10px] font-bold text-white/60 mb-0.5">
                <Grid3X3 className="w-3.5 h-3.5 text-purple-400" />
                <span>CORES PLACED</span>
              </div>
              <div className="text-base font-black font-mono text-white">
                {profile.totalBlocks.toLocaleString()}
              </div>
            </div>

            <div className="p-2.5 rounded-2xl bg-white/[0.04] border border-white/10">
              <div className="flex items-center gap-1.5 text-[10px] font-bold text-white/60 mb-0.5">
                <Flame className="w-3.5 h-3.5 text-amber-400" />
                <span>MAX COMBO STREAK</span>
              </div>
              <div className="text-base font-black font-mono text-amber-300">
                ×{profile.maxCombo > 0 ? Math.min(profile.maxCombo, 4) : 1}
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Bottom Back Button */}
      <footer className="w-full pt-3 shrink-0 z-20 border-t border-white/10">
        <button
          onClick={onBack}
          className="w-full py-3 px-4 rounded-2xl btn-arcade flex items-center justify-center gap-2 text-xs font-black uppercase text-cyan-300 active:scale-95 transition-transform cursor-pointer"
        >
          <ArrowLeft className="w-4 h-4 text-cyan-200" />
          <span>Back to Main Menu</span>
        </button>
      </footer>
    </div>
  );
};
