import React, { useState, useEffect, useRef, useMemo } from 'react';
import {
  ArrowLeft,
  Lock,
  Star,
  CheckCircle2,
  Trophy,
  Play,
  Gift,
  X,
  Target,
  Sparkles,
  Compass,
  ChevronLeft,
  ChevronRight,
  Layers,
} from 'lucide-react';
import { PlayerProfile, LevelData } from '../types/game';
import {
  TOTAL_LEVELS,
  BATCH_SIZE,
  TOTAL_BATCHES,
  getBatchLevels,
  getBatchForLevel,
  getBiomeForBatch,
  BiomeInfo,
} from '../utils/levelData';
import { sound } from '../utils/audio';
import { CartoonCharacter } from './CartoonCharacter';
import { RoadmapScenery } from './RoadmapScenery';

interface LevelsScreenProps {
  profile: PlayerProfile;
  onSelectLevel: (levelNumber: number) => void;
  onOpenMilestoneChest: (milestoneLevel: number) => void;
  onBack: () => void;
}

interface RoadmapNode {
  type: 'level' | 'milestone';
  levelData?: LevelData;
  milestoneLevel?: number;
  roadIndex: number;
  x: number;
  y: number;
}

export const LevelsScreen: React.FC<LevelsScreenProps> = ({
  profile,
  onSelectLevel,
  onOpenMilestoneChest,
  onBack,
}) => {
  // Current highest unlocked batch based on player's progress
  // Player must complete all 50 levels of batch N to unlock batch N+1
  const highestUnlockedBatch = useMemo(() => {
    return Math.max(1, Math.min(TOTAL_BATCHES, getBatchForLevel(profile.level)));
  }, [profile.level]);

  // Active viewing batch (defaults to the player's current unlocked batch)
  const [activeBatch, setActiveBatch] = useState<number>(() => highestUnlockedBatch);

  // Automatically sync activeBatch if player level advances into a new batch
  useEffect(() => {
    setActiveBatch((prev) => Math.max(prev, highestUnlockedBatch));
  }, [highestUnlockedBatch]);

  // Current Biome Information for the active batch
  const currentBiome: BiomeInfo = useMemo(() => {
    return getBiomeForBatch(activeBatch);
  }, [activeBatch]);

  // The 50 levels for this batch
  const batchLevels = useMemo(() => {
    return getBatchLevels(activeBatch);
  }, [activeBatch]);

  const scrollContainerRef = useRef<HTMLDivElement | null>(null);

  // Modal / Toast States
  const [selectedLevelData, setSelectedLevelData] = useState<LevelData | null>(null);
  const [selectedMilestone, setSelectedMilestone] = useState<number | null>(null);
  const [lockToast, setLockToast] = useState<string | null>(null);
  const lockToastTimeoutRef = useRef<NodeJS.Timeout | null>(null);

  // Total stars earned across all completed levels
  const totalStars = useMemo(() => {
    return Object.values(profile.completedLevels).reduce(
      (acc, curr) => acc + (curr.stars || 3),
      0
    );
  }, [profile.completedLevels]);

  const totalCompletedLevels = useMemo(() => {
    return Object.keys(profile.completedLevels).length;
  }, [profile.completedLevels]);

  // Completed levels within the active batch
  const batchCompletedCount = useMemo(() => {
    return batchLevels.filter((lvl) => !!profile.completedLevels[lvl.levelNumber]?.completed).length;
  }, [batchLevels, profile.completedLevels]);

  // Construct Roadmap Nodes (50 levels + milestones every 10 levels, ascending from bottom to top)
  const { roadmapNodes, totalHeight, svgPath } = useMemo(() => {
    const nodes: RoadmapNode[] = [];
    const Y_SPACING = 88;
    const CANVAS_WIDTH = 380;
    const PADDING_TOP = 130;
    const PADDING_BOTTOM = 130;

    interface ItemDef {
      type: 'level' | 'milestone';
      lvlNum?: number;
      milestoneNum?: number;
    }
    const itemDefs: ItemDef[] = [];

    // Build the 50 levels with milestones after every 10th level
    batchLevels.forEach((lvl) => {
      itemDefs.push({ type: 'level', lvlNum: lvl.levelNumber });
      if (lvl.levelNumber % 10 === 0) {
        itemDefs.push({ type: 'milestone', milestoneNum: lvl.levelNumber });
      }
    });

    const totalSteps = itemDefs.length;
    const calculatedHeight = PADDING_TOP + totalSteps * Y_SPACING + PADDING_BOTTOM;

    // Map each item to (x, y) coordinates. First item in batch is at the BOTTOM!
    itemDefs.forEach((item, index) => {
      const yFromTop = calculatedHeight - PADDING_BOTTOM - index * Y_SPACING;

      let x = CANVAS_WIDTH / 2;
      if (item.type === 'milestone') {
        // Milestone sits centered
        x = CANVAS_WIDTH / 2;
      } else {
        // Gentle S-curve wave for level bubbles
        x = CANVAS_WIDTH / 2 + Math.sin(index * 0.72) * 115;
      }

      if (item.type === 'level' && item.lvlNum) {
        const lvl = batchLevels.find((lv) => lv.levelNumber === item.lvlNum);
        nodes.push({
          type: 'level',
          levelData: lvl,
          roadIndex: index,
          x: Math.round(x),
          y: Math.round(yFromTop),
        });
      } else if (item.type === 'milestone' && item.milestoneNum) {
        nodes.push({
          type: 'milestone',
          milestoneLevel: item.milestoneNum,
          roadIndex: index,
          x: Math.round(x),
          y: Math.round(yFromTop),
        });
      }
    });

    // Create SVG road path string connecting from bottom (first) to top (last)
    let pathD = '';
    if (nodes.length > 0) {
      pathD = `M ${nodes[0].x} ${nodes[0].y}`;
      for (let i = 0; i < nodes.length - 1; i++) {
        const p1 = nodes[i];
        const p2 = nodes[i + 1];
        const midY = (p1.y + p2.y) / 2;
        pathD += ` C ${p1.x} ${midY}, ${p2.x} ${midY}, ${p2.x} ${p2.y}`;
      }
    }

    return {
      roadmapNodes: nodes,
      totalHeight: calculatedHeight,
      svgPath: pathD,
    };
  }, [batchLevels]);

  // Auto-scroll to Current Level or bottom on batch load
  useEffect(() => {
    const timer = setTimeout(() => {
      // If current player level is inside this active batch, scroll directly to it
      const currentElement = document.getElementById(`roadmap-node-${profile.level}`);
      if (currentElement && scrollContainerRef.current) {
        currentElement.scrollIntoView({ behavior: 'smooth', block: 'center' });
      } else if (scrollContainerRef.current) {
        // Otherwise, scroll to the bottom of the batch where stage 1 is
        scrollContainerRef.current.scrollTop = scrollContainerRef.current.scrollHeight;
      }
    }, 120);

    return () => clearTimeout(timer);
  }, [activeBatch, profile.level]);

  // Jump to Current Level Action
  const handleJumpToCurrent = () => {
    sound.playClick();
    const batchOfCurrent = getBatchForLevel(profile.level);
    if (activeBatch !== batchOfCurrent) {
      setActiveBatch(batchOfCurrent);
    } else {
      const currentElement = document.getElementById(`roadmap-node-${profile.level}`);
      if (currentElement) {
        currentElement.scrollIntoView({ behavior: 'smooth', block: 'center' });
      }
    }
  };

  // Switch Batch Handler
  const handlePrevBatch = () => {
    if (activeBatch <= 1) return;
    sound.playClick();
    setActiveBatch((prev) => prev - 1);
  };

  const handleNextBatch = () => {
    if (activeBatch >= highestUnlockedBatch) {
      sound.playInvalid();
      const nextBatchStart = activeBatch * BATCH_SIZE;
      showToast(`Complete Level ${nextBatchStart} to unlock Chapter ${activeBatch + 1}!`);
      return;
    }
    sound.playClick();
    setActiveBatch((prev) => prev + 1);
  };

  const showToast = (message: string) => {
    if (lockToastTimeoutRef.current) clearTimeout(lockToastTimeoutRef.current);
    setLockToast(message);
    lockToastTimeoutRef.current = setTimeout(() => {
      setLockToast(null);
    }, 2500);
  };

  // Level Click Handler
  const handleLevelClick = (lvl: LevelData) => {
    const isUnlocked = lvl.levelNumber <= profile.level;
    if (!isUnlocked) {
      sound.playInvalid();
      showToast(`Complete Level ${lvl.levelNumber - 1} to unlock Level ${lvl.levelNumber}!`);
      return;
    }

    sound.playClick();
    setSelectedLevelData(lvl);
  };

  // Milestone Click Handler
  const handleMilestoneClick = (milestoneLvl: number) => {
    sound.playClick();
    const isCompleted = !!profile.completedLevels[milestoneLvl]?.completed;
    const isClaimed = profile.claimedMilestones?.includes(milestoneLvl);

    if (isCompleted && !isClaimed) {
      onOpenMilestoneChest(milestoneLvl);
    } else {
      setSelectedMilestone(milestoneLvl);
    }
  };

  // Launch Game Level
  const handleStartLevel = (levelNumber: number) => {
    sound.playClick();
    setSelectedLevelData(null);
    onSelectLevel(levelNumber);
  };

  return (
    <div className="relative w-full h-[100dvh] max-h-[100dvh] flex flex-col justify-between text-white select-none overflow-hidden animate-fade-in max-w-[430px] mx-auto bg-gradient-to-b from-[#38bdf8] via-[#818cf8] to-[#047857]">
      {/* ================= STICKY TOP HEADER ================= */}
      <header className="sticky top-0 w-full z-30 px-3 pt-[max(8px,env(safe-area-inset-top))] pb-2 backdrop-blur-xl bg-[#14082c]/85 border-b border-pink-500/20 shadow-[0_8px_24px_rgba(0,0,0,0.5)] flex flex-col shrink-0">
        {/* Top Bar: Back, Title & Overall Progress Stats */}
        <div className="flex items-center justify-between mb-1.5">
          <button
            onClick={() => {
              sound.playClick();
              onBack();
            }}
            className="w-9 h-9 rounded-2xl btn-arcade flex items-center justify-center text-pink-300 active:scale-95 transition-transform cursor-pointer"
            aria-label="Back to Home"
          >
            <ArrowLeft className="w-4 h-4 text-pink-200" />
          </button>

          {/* Title & Adventure Tagline */}
          <div className="text-center px-1">
            <div className="flex items-center justify-center gap-1.5">
              <Compass className="w-4 h-4 text-amber-300 animate-spin-slow" />
              <h2 className="text-base sm:text-lg font-black font-['Chakra_Petch',sans-serif] tracking-wider text-transparent bg-clip-text bg-gradient-to-r from-pink-300 via-amber-200 to-cyan-300 uppercase drop-shadow-[0_2px_8px_rgba(255,51,102,0.4)]">
                LEVELS
              </h2>
            </div>
            <p className="text-[8px] sm:text-[9px] font-mono font-bold tracking-widest text-pink-300/80 uppercase">
              1,000 LEVEL CARTOON ADVENTURE
            </p>
          </div>

          {/* Level Progress & Stars Counter */}
          <div className="flex items-center gap-1.5">
            <div className="flex items-center gap-1 px-2.5 py-1 rounded-xl bg-amber-500/15 border border-amber-400/40 font-mono text-xs font-black text-amber-200 shadow-sm">
              <Star className="w-3.5 h-3.5 text-amber-300 fill-amber-300" />
              <span>{totalStars}</span>
            </div>

            <div className="flex items-center gap-1 px-2 py-1 rounded-xl bg-pink-500/15 border border-pink-400/40 font-mono text-xs font-black text-pink-200 shadow-sm">
              <Trophy className="w-3.5 h-3.5 text-pink-300" />
              <span>{totalCompletedLevels}/{TOTAL_LEVELS}</span>
            </div>
          </div>
        </div>

        {/* 50-Level Chapter / Biome Selector Strip */}
        <div className="w-full flex items-center justify-between px-2 py-1 rounded-xl bg-black/40 border border-white/10 backdrop-blur-md">
          {/* Previous Batch Arrow */}
          <button
            onClick={handlePrevBatch}
            disabled={activeBatch <= 1}
            className={`w-7 h-7 rounded-lg flex items-center justify-center transition-all cursor-pointer ${
              activeBatch > 1
                ? 'bg-white/10 text-white hover:bg-white/20 active:scale-95'
                : 'text-white/20 cursor-not-allowed'
            }`}
            title="Previous Chapter"
          >
            <ChevronLeft className="w-4 h-4" />
          </button>

          {/* Chapter Information */}
          <div className="flex flex-col items-center text-center px-1 overflow-hidden">
            <div className="flex items-center gap-1.5">
              <span className="text-sm">{currentBiome.themeFruit}</span>
              <span className="text-xs font-black font-['Chakra_Petch'] tracking-wide text-amber-200 truncate max-w-[210px] uppercase">
                CH. {activeBatch}: {currentBiome.name}
              </span>
            </div>
            <div className="text-[9px] font-mono font-bold text-cyan-300 flex items-center gap-1.5">
              <span>LEVELS {currentBiome.startLevel} – {currentBiome.endLevel}</span>
              <span className="text-white/40">•</span>
              <span className="text-emerald-300 font-extrabold">
                {batchCompletedCount}/{BATCH_SIZE} BEATEN
              </span>
            </div>
          </div>

          {/* Next Batch Arrow */}
          <button
            onClick={handleNextBatch}
            className={`w-7 h-7 rounded-lg flex items-center justify-center transition-all cursor-pointer ${
              activeBatch < highestUnlockedBatch
                ? 'bg-white/10 text-white hover:bg-white/20 active:scale-95'
                : 'text-white/30 hover:text-white/50'
            }`}
            title={activeBatch < highestUnlockedBatch ? 'Next Chapter' : 'Locked'}
          >
            {activeBatch < highestUnlockedBatch ? (
              <ChevronRight className="w-4 h-4" />
            ) : (
              <Lock className="w-3.5 h-3.5" />
            )}
          </button>
        </div>
      </header>

      {/* ================= MAIN SCROLLABLE 50-LEVEL ROADMAP CANVAS ================= */}
      <div
        ref={scrollContainerRef}
        className="relative flex-1 w-full overflow-y-auto overflow-x-hidden overscroll-contain z-10 scrollbar-none"
        style={{ scrollBehavior: 'smooth' }}
      >
        <div
          className="relative w-[380px] mx-auto"
          style={{ height: `${totalHeight}px` }}
        >
          {/* 1. Extreme 3D Cartoon Fantasy World Background Scenery */}
          <RoadmapScenery
            totalHeight={totalHeight}
            biome={currentBiome}
            activeBatch={activeBatch}
          />

          {/* 2. SVG Winding Cartoon Adventure Road */}
          <svg
            className="absolute inset-0 pointer-events-none z-10"
            width="380"
            height={totalHeight}
            viewBox={`0 0 380 ${totalHeight}`}
          >
            <defs>
              {/* Biome Road Gradient */}
              <linearGradient id={`biomeRoad-${activeBatch}`} x1="0%" y1="100%" x2="0%" y2="0%">
                <stop offset="0%" stopColor={currentBiome.roadGradient[0]} />
                <stop offset="50%" stopColor={currentBiome.roadGradient[1]} />
                <stop offset="100%" stopColor={currentBiome.roadGradient[2]} />
              </linearGradient>

              {/* Road Glow */}
              <filter id="roadGlow" x="-20%" y="-20%" width="140%" height="140%">
                <feDropShadow dx="0" dy="4" stdDeviation="6" floodColor={currentBiome.accentColor} floodOpacity="0.45" />
              </filter>
            </defs>

            {/* A. Deep Road Trench Shadow */}
            <path
              d={svgPath}
              fill="none"
              stroke="#0a0314"
              strokeWidth="50"
              strokeLinecap="round"
              strokeLinejoin="round"
              opacity="0.55"
            />

            {/* B. Candied Wafer / Biscuit Border */}
            <path
              d={svgPath}
              fill="none"
              stroke="#fed7aa"
              strokeWidth="44"
              strokeLinecap="round"
              strokeLinejoin="round"
            />
            {/* Biscuit Wafer Rib Grooves */}
            <path
              d={svgPath}
              fill="none"
              stroke="#b45309"
              strokeWidth="44"
              strokeDasharray="3 7"
              strokeLinecap="round"
              strokeLinejoin="round"
              opacity="0.45"
            />

            {/* C. Golden Cobblestone Curb */}
            <path
              d={svgPath}
              fill="none"
              stroke="#fbbf24"
              strokeWidth="36"
              strokeLinecap="round"
              strokeLinejoin="round"
            />

            {/* D. Main Colorful Adventure Road Path */}
            <path
              d={svgPath}
              fill="none"
              stroke={`url(#biomeRoad-${activeBatch})`}
              strokeWidth="28"
              strokeLinecap="round"
              strokeLinejoin="round"
              filter="url(#roadGlow)"
            />

            {/* E. 3D Road Top Gloss Highlight Strip */}
            <path
              d={svgPath}
              fill="none"
              stroke="#ffffff"
              strokeWidth="4"
              strokeLinecap="round"
              strokeLinejoin="round"
              opacity="0.4"
            />

            {/* F. White Cartoon Dashed Center Line */}
            <path
              d={svgPath}
              fill="none"
              stroke="#ffffff"
              strokeWidth="3.5"
              strokeDasharray="9 11"
              strokeLinecap="round"
              opacity="0.95"
            />
          </svg>

          {/* Summit Banner at Top of Batch */}
          <div
            className="absolute left-1/2 -translate-x-1/2 flex flex-col items-center pointer-events-none z-20"
            style={{ top: '30px' }}
          >
            <div className="px-3.5 py-1.5 rounded-2xl bg-gradient-to-r from-amber-400 via-yellow-300 to-amber-500 text-black font-black font-['Chakra_Petch'] text-xs tracking-wider shadow-[0_4px_20px_rgba(251,191,36,0.6)] border-2 border-white flex items-center gap-1.5 animate-bounce">
              <Sparkles className="w-4 h-4 text-black fill-black" />
              <span>
                {activeBatch === TOTAL_BATCHES
                  ? '👑 1,000 LEVEL GRAND SUMMIT'
                  : `${currentBiome.themeFruit} CHAPTER ${activeBatch} SUMMIT (LVL ${currentBiome.endLevel})`}
              </span>
            </div>
            <div className="w-1 h-7 bg-amber-400 mt-1 shadow-md" />
          </div>

          {/* Starting Banner at Base of Batch */}
          <div
            className="absolute left-1/2 -translate-x-1/2 flex flex-col items-center pointer-events-none z-20"
            style={{ top: `${totalHeight - 40}px` }}
          >
            <div className="px-4 py-1.5 rounded-full bg-emerald-600/90 border-2 border-white text-[11px] font-mono font-black text-white tracking-widest uppercase shadow-lg backdrop-blur-md">
              {currentBiome.themeFruit} {currentBiome.name} – START LVL {currentBiome.startLevel}
            </div>
          </div>

          {/* ================= ROADMAP NODES: 50 LEVELS & MILESTONES ================= */}
          {roadmapNodes.map((node) => {
            // RENDER REWARD MILESTONE NODE (Every 10 levels)
            if (node.type === 'milestone' && node.milestoneLevel) {
              const milestoneNum = node.milestoneLevel;
              const isCompleted = !!profile.completedLevels[milestoneNum]?.completed;
              const isClaimed = profile.claimedMilestones?.includes(milestoneNum);

              return (
                <div
                  key={`milestone-${milestoneNum}`}
                  id={`roadmap-milestone-${milestoneNum}`}
                  className="absolute transform -translate-x-1/2 -translate-y-1/2 z-20 flex flex-col items-center cursor-pointer"
                  style={{ left: `${node.x}px`, top: `${node.y}px` }}
                  onClick={() => handleMilestoneClick(milestoneNum)}
                >
                  <div
                    className={`relative flex flex-col items-center p-3 rounded-3xl border-2 transition-all duration-300 active:scale-95 ${
                      isClaimed
                        ? 'bg-gradient-to-b from-amber-950/70 via-purple-950/80 to-black/90 border-amber-400/50 shadow-[0_4px_16px_rgba(245,158,11,0.3)]'
                        : isCompleted
                        ? 'bg-gradient-to-b from-amber-500/40 via-yellow-500/30 to-purple-900/90 border-amber-300 shadow-[0_0_35px_rgba(251,191,36,0.7)] animate-pulse'
                        : 'bg-gradient-to-b from-purple-950/80 via-slate-900/90 to-black/90 border-purple-400/40 opacity-90 hover:opacity-100'
                    }`}
                  >
                    {/* Mystery Box Icon with Glowing ? */}
                    <div className="relative w-14 h-14 rounded-2xl bg-gradient-to-br from-amber-400 via-orange-500 to-rose-600 border-2 border-white/80 shadow-[0_4px_16px_rgba(245,158,11,0.5)] flex items-center justify-center">
                      <Gift className="w-7 h-7 text-white drop-shadow-md" />
                      <div className="absolute -top-1.5 -right-1.5 w-6 h-6 rounded-full bg-yellow-300 border-2 border-purple-950 text-purple-950 font-black flex items-center justify-center text-xs shadow-md">
                        {isClaimed ? '✓' : '?'}
                      </div>
                      <div className="absolute top-1 left-1.5 w-6 h-3 rounded-full bg-white/40 blur-[0.5px]" />
                    </div>

                    {/* STRICT REQUIREMENT: Labeled ONLY "MYSTERY REWARD" */}
                    <div className="mt-1.5 px-3 py-0.5 rounded-full bg-purple-950/90 border border-amber-400/70 text-[9px] font-black font-['Chakra_Petch'] tracking-widest text-amber-200 uppercase whitespace-nowrap shadow-md">
                      MYSTERY REWARD
                    </div>

                    <div className="text-[8px] font-mono font-bold text-pink-300/80 uppercase mt-0.5">
                      MILESTONE {milestoneNum}
                    </div>

                    {/* Status Badge */}
                    {isClaimed ? (
                      <div className="mt-1 flex items-center gap-1 text-[8px] font-mono font-black text-amber-300">
                        <CheckCircle2 className="w-3 h-3 text-amber-400 fill-amber-950" />
                        <span>CLAIMED</span>
                      </div>
                    ) : isCompleted ? (
                      <div className="mt-1 flex items-center gap-1 text-[8px] font-mono font-black text-yellow-300 animate-pulse">
                        <Sparkles className="w-3 h-3 text-yellow-300" />
                        <span>UNLOCKED! TAP</span>
                      </div>
                    ) : (
                      <div className="mt-1 flex items-center gap-1 text-[8px] font-mono font-bold text-white/50">
                        <Lock className="w-2.5 h-2.5" />
                        <span>LEVEL {milestoneNum}</span>
                      </div>
                    )}
                  </div>
                </div>
              );
            }

            // RENDER INDIVIDUAL LEVEL NODE WITH UNIQUE CARTOON CHARACTER
            if (node.type === 'level' && node.levelData) {
              const lvl = node.levelData;
              const isCompleted = !!profile.completedLevels[lvl.levelNumber]?.completed;
              const isUnlocked = lvl.levelNumber <= profile.level;
              const isCurrent = lvl.levelNumber === profile.level;
              const stars = profile.completedLevels[lvl.levelNumber]?.stars || (isCompleted ? 3 : 0);

              return (
                <div
                  key={`level-${lvl.levelNumber}`}
                  id={`roadmap-node-${lvl.levelNumber}`}
                  className="absolute transform -translate-x-1/2 -translate-y-1/2 z-20 flex flex-col items-center"
                  style={{ left: `${node.x}px`, top: `${node.y}px` }}
                >
                  {/* Bouncing "PLAY" Pointer on Current Level */}
                  {isCurrent && (
                    <div className="absolute -top-11 z-30 flex flex-col items-center pointer-events-none animate-bounce">
                      <div className="px-2.5 py-0.5 rounded-full bg-cyan-400 text-black font-black font-['Chakra_Petch'] text-[9px] tracking-widest uppercase shadow-[0_0_12px_rgba(0,240,255,0.8)] border border-white flex items-center gap-1">
                        <Play className="w-2.5 h-2.5 fill-black" />
                        <span>PLAY</span>
                      </div>
                      <div className="w-0 h-0 border-x-4 border-x-transparent border-t-5 border-t-cyan-400 -mt-0.5" />
                    </div>
                  )}

                  {/* Level Button Circular Bubble Housing the Cartoon Character */}
                  <button
                    onClick={() => handleLevelClick(lvl)}
                    className={`relative w-[66px] h-[66px] rounded-3xl flex flex-col items-center justify-between p-1.5 transition-transform active:scale-90 cursor-pointer select-none ${
                      isCurrent
                        ? 'bg-gradient-to-br from-cyan-900/90 via-purple-900/90 to-black/95 border-2 border-cyan-300 shadow-[0_0_24px_rgba(0,240,255,0.7)] ring-4 ring-cyan-400/80 animate-pulse'
                        : isCompleted
                        ? 'bg-gradient-to-br from-emerald-950/90 via-purple-950/80 to-black/90 border-2 border-emerald-400/80 shadow-[0_4px_16px_rgba(16,185,129,0.4)] hover:brightness-110'
                        : isUnlocked
                        ? 'bg-gradient-to-br from-purple-950/80 via-slate-900/90 to-black/90 border-2 border-white/40 hover:border-pink-400/80'
                        : 'bg-slate-950/90 border-2 border-white/10 opacity-60 cursor-not-allowed shadow-inner'
                    }`}
                    aria-label={`Level ${lvl.levelNumber}`}
                  >
                    {/* 3D Bubble Top Gloss */}
                    <div className="absolute top-1 left-2 w-7 h-2 rounded-full bg-white/30 blur-[0.5px] pointer-events-none" />

                    {/* UNIQUE CARTOON CHARACTER FOR EVERY LEVEL */}
                    <div className="relative w-full flex-1 flex items-center justify-center min-h-0">
                      <CartoonCharacter
                        levelNumber={lvl.levelNumber}
                        size={36}
                        isCurrent={isCurrent}
                        isCompleted={isCompleted}
                        isLocked={!isUnlocked}
                      />

                      {/* Lock overlay if locked */}
                      {!isUnlocked && (
                        <div className="absolute inset-0 flex items-center justify-center bg-black/40 rounded-full">
                          <Lock className="w-4 h-4 text-white/70 drop-shadow" />
                        </div>
                      )}
                    </div>

                    {/* Highly-Readable Level Number Pill */}
                    <div
                      className={`px-1.5 py-0.5 rounded-full font-black font-['Chakra_Petch',sans-serif] text-[8.5px] leading-tight tracking-wide uppercase shadow-md max-w-[58px] truncate text-center whitespace-nowrap ${
                        isCurrent
                          ? 'bg-cyan-400 text-black'
                          : isCompleted
                          ? 'bg-emerald-500 text-white'
                          : isUnlocked
                          ? 'bg-white/20 text-white'
                          : 'bg-black/60 text-white/40'
                      }`}
                    >
                      Level {lvl.levelNumber}
                    </div>

                    {/* Completion Checkmark Badge */}
                    {isCompleted && (
                      <div className="absolute -top-1 -right-1 w-5 h-5 rounded-full bg-emerald-500 border-2 border-white flex items-center justify-center shadow-md">
                        <CheckCircle2 className="w-3.5 h-3.5 text-white" />
                      </div>
                    )}
                  </button>

                  {/* 3 Stars Indicator Bar Underneath */}
                  <div className="mt-1 flex items-center gap-0.5 px-2 py-0.5 rounded-full bg-black/60 backdrop-blur-sm border border-white/10 shadow-sm">
                    {[1, 2, 3].map((starIndex) => {
                      const hasStar = isCompleted && starIndex <= stars;
                      return (
                        <Star
                          key={starIndex}
                          className={`w-2.5 h-2.5 ${
                            hasStar
                              ? 'text-amber-300 fill-amber-300 drop-shadow-[0_0_4px_rgba(251,191,36,0.8)]'
                              : 'text-white/20 fill-black/20'
                          }`}
                        />
                      );
                    })}
                  </div>
                </div>
              );
            }

            return null;
          })}
        </div>
      </div>

      {/* ================= FLOATING BOTTOM QUICK-ACTION BAR ================= */}
      <footer className="w-full px-4 py-2.5 z-30 shrink-0 bg-[#14082c]/90 backdrop-blur-xl border-t border-pink-500/20 flex items-center justify-between gap-3 shadow-[0_-8px_24px_rgba(0,0,0,0.5)]">
        {/* Back to Home Button */}
        <button
          onClick={() => {
            sound.playClick();
            onBack();
          }}
          className="flex-1 py-2.5 px-3 rounded-2xl btn-arcade flex items-center justify-center gap-2 text-xs font-black uppercase text-pink-200 active:scale-95 transition-transform cursor-pointer"
        >
          <ArrowLeft className="w-4 h-4 text-pink-300" />
          <span>Home</span>
        </button>

        {/* Jump to Current Player Level Button */}
        <button
          onClick={handleJumpToCurrent}
          className="px-3.5 py-2.5 rounded-2xl btn-arcade flex items-center justify-center gap-1.5 text-xs font-black uppercase text-amber-200 active:scale-95 transition-transform cursor-pointer"
          title="Scroll to current level"
        >
          <Target className="w-4 h-4 text-amber-300" />
          <span className="font-mono text-[11px]">Lvl {profile.level}</span>
        </button>

        {/* Big Juicy PLAY CURRENT LEVEL CTA Button */}
        <button
          onClick={() => handleStartLevel(profile.level)}
          className="flex-[1.3] py-2.5 px-4 rounded-2xl btn-cta-glow flex items-center justify-center gap-2 text-xs font-black uppercase text-black active:scale-95 transition-transform cursor-pointer shadow-[0_4px_16px_rgba(255,51,102,0.5)]"
        >
          <Play className="w-4 h-4 text-black fill-black" />
          <span>Play Level {profile.level}</span>
        </button>
      </footer>

      {/* ================= LEVEL PREVIEW MODAL ================= */}
      {selectedLevelData && (
        <div className="fixed inset-0 z-50 flex items-center justify-center px-4 bg-black/75 backdrop-blur-md animate-fade-in">
          <div className="relative w-full max-w-[340px] rounded-3xl glass-panel-colorful p-5 border-2 border-pink-400/50 shadow-[0_20px_50px_rgba(0,0,0,0.85)] flex flex-col items-center text-center animate-bounce-in">
            {/* Close Button */}
            <button
              onClick={() => {
                sound.playClick();
                setSelectedLevelData(null);
              }}
              className="absolute top-3.5 right-3.5 w-8 h-8 rounded-full bg-white/10 border border-white/20 flex items-center justify-center text-white/70 hover:text-white active:scale-95 cursor-pointer"
            >
              <X className="w-4 h-4" />
            </button>

            {/* Level Character Portrait */}
            <div className="w-20 h-20 rounded-3xl bg-gradient-to-br from-pink-500/30 via-purple-500/20 to-black/60 border-2 border-pink-400/60 shadow-[0_6px_20px_rgba(244,63,94,0.4)] flex items-center justify-center my-1">
              <CartoonCharacter
                levelNumber={selectedLevelData.levelNumber}
                size={56}
                isCurrent={selectedLevelData.levelNumber === profile.level}
                isCompleted={!!profile.completedLevels[selectedLevelData.levelNumber]?.completed}
              />
            </div>

            {/* Level Title */}
            <h3 className="mt-2 text-lg font-black font-['Chakra_Petch'] text-white tracking-wide uppercase">
              {selectedLevelData.title}
            </h3>
            <p className="text-[10px] font-mono font-bold tracking-widest text-pink-300 uppercase">
              LEVEL {selectedLevelData.levelNumber} OF {TOTAL_LEVELS}
            </p>

            {/* Target Score Card */}
            <div className="w-full my-4 p-3 rounded-2xl bg-white/[0.06] border border-white/15 flex flex-col items-center gap-1">
              <span className="text-[10px] font-mono font-bold text-amber-300/80 uppercase">
                TARGET SCORE
              </span>
              <span className="text-2xl font-black font-mono text-amber-300 tracking-tight">
                {selectedLevelData.targetScore.toLocaleString()} PTS
              </span>

              {/* Best Record & Stars */}
              <div className="w-full mt-2 pt-2 border-t border-white/10 flex items-center justify-between text-xs font-mono px-2">
                <span className="text-white/60">YOUR STARS:</span>
                <div className="flex items-center gap-1">
                  {[1, 2, 3].map((starIndex) => {
                    const stars = profile.completedLevels[selectedLevelData.levelNumber]?.stars || 0;
                    return (
                      <Star
                        key={starIndex}
                        className={`w-3.5 h-3.5 ${
                          starIndex <= stars
                            ? 'text-amber-300 fill-amber-300'
                            : 'text-white/20 fill-black/20'
                        }`}
                      />
                    );
                  })}
                </div>
              </div>

              {profile.completedLevels[selectedLevelData.levelNumber]?.bestScore && (
                <div className="w-full flex items-center justify-between text-[11px] font-mono px-2 text-emerald-300">
                  <span>BEST SCORE:</span>
                  <span className="font-bold">
                    {profile.completedLevels[selectedLevelData.levelNumber].bestScore.toLocaleString()} PTS
                  </span>
                </div>
              )}
            </div>

            {/* Play Button */}
            <button
              onClick={() => handleStartLevel(selectedLevelData.levelNumber)}
              className="w-full py-3.5 px-4 rounded-2xl btn-cta-glow text-black font-black uppercase text-sm tracking-wider flex items-center justify-center gap-2 active:scale-95 transition-transform cursor-pointer shadow-[0_6px_22px_rgba(255,51,102,0.6)]"
            >
              <Play className="w-4 h-4 fill-black" />
              <span>Play Level {selectedLevelData.levelNumber}</span>
            </button>
          </div>
        </div>
      )}

      {/* ================= REWARD MILESTONE MODAL ================= */}
      {/* STRICT REQUIREMENT: Labeled ONLY "MYSTERY REWARD". NO reward contents, NO fake coin/gem counts, NO reward claiming */}
      {selectedMilestone && (
        <div className="fixed inset-0 z-50 flex items-center justify-center px-4 bg-black/75 backdrop-blur-md animate-fade-in">
          <div className="relative w-full max-w-[340px] rounded-3xl glass-panel-colorful p-5 border-2 border-amber-400/50 shadow-[0_20px_50px_rgba(0,0,0,0.85)] flex flex-col items-center text-center animate-bounce-in">
            {/* Close Button */}
            <button
              onClick={() => {
                sound.playClick();
                setSelectedMilestone(null);
              }}
              className="absolute top-3.5 right-3.5 w-8 h-8 rounded-full bg-white/10 border border-white/20 flex items-center justify-center text-white/70 hover:text-white active:scale-95 cursor-pointer"
            >
              <X className="w-4 h-4" />
            </button>

            {/* Mystery Gift Box with Question Mark */}
            <div className="relative w-20 h-20 rounded-3xl bg-gradient-to-br from-amber-400 via-orange-500 to-rose-600 border-2 border-white shadow-[0_8px_28px_rgba(245,158,11,0.6)] flex items-center justify-center my-2">
              <Gift className="w-10 h-10 text-white drop-shadow-md" />
              <div className="absolute -top-2 -right-2 w-8 h-8 rounded-full bg-yellow-300 border-2 border-purple-950 text-purple-950 font-black flex items-center justify-center text-sm shadow-md">
                ?
              </div>
            </div>

            {/* STRICT REQUIREMENT: Labeled ONLY "MYSTERY REWARD" */}
            <h3 className="mt-2 text-xl font-black font-['Chakra_Petch'] text-amber-200 tracking-wider uppercase drop-shadow-[0_2px_10px_rgba(251,191,36,0.5)]">
              MYSTERY REWARD
            </h3>
            <p className="text-[10px] font-mono font-bold tracking-widest text-pink-300 uppercase">
              MILESTONE {selectedMilestone}
            </p>

            {/* Mystery Description Card */}
            <div className="w-full my-4 p-3.5 rounded-2xl bg-white/[0.06] border border-white/15 flex flex-col items-center gap-1.5 text-xs text-white/80">
              <p className="leading-relaxed">
                {profile.claimedMilestones?.includes(selectedMilestone)
                  ? `Congratulations! You already opened and claimed this Milestone ${selectedMilestone} Mystery Reward Chest!`
                  : profile.completedLevels[selectedMilestone]?.completed
                  ? `Level ${selectedMilestone} is completed! Your special Mystery Reward Chest is unlocked and ready to open!`
                  : `Complete Level ${selectedMilestone} on your adventure to reach this Mystery Reward milestone!`}
              </p>
            </div>

            {/* Action Buttons */}
            {profile.completedLevels[selectedMilestone]?.completed &&
            !profile.claimedMilestones?.includes(selectedMilestone) ? (
              <button
                onClick={() => {
                  sound.playClick();
                  const lvl = selectedMilestone;
                  setSelectedMilestone(null);
                  onOpenMilestoneChest(lvl);
                }}
                className="w-full py-3.5 px-4 rounded-2xl btn-cta-glow text-black font-black uppercase text-xs tracking-wider flex items-center justify-center gap-2 active:scale-95 transition-transform cursor-pointer shadow-lg"
              >
                <Gift className="w-4 h-4 fill-black" />
                <span>Open Milestone Chest</span>
              </button>
            ) : (
              <button
                onClick={() => {
                  sound.playClick();
                  setSelectedMilestone(null);
                }}
                className="w-full py-3 px-4 rounded-2xl btn-arcade text-pink-200 font-black uppercase text-xs tracking-wider flex items-center justify-center gap-2 active:scale-95 transition-transform cursor-pointer"
              >
                <span>Got It</span>
              </button>
            )}
          </div>
        </div>
      )}

      {/* ================= LOCKED LEVEL TOAST ================= */}
      {lockToast && (
        <div className="fixed bottom-20 left-1/2 -translate-x-1/2 z-50 px-4 py-2.5 rounded-2xl bg-black/90 border border-pink-400/60 shadow-[0_8px_30px_rgba(0,0,0,0.8)] backdrop-blur-md text-xs font-mono font-bold text-pink-200 flex items-center gap-2 animate-bounce-in max-w-[90%]">
          <Lock className="w-4 h-4 text-pink-400 shrink-0" />
          <span>{lockToast}</span>
        </div>
      )}
    </div>
  );
};
