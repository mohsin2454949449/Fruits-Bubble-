import React, { useState } from 'react';
import {
  X,
  Volume2,
  VolumeX,
  Music,
  RotateCcw,
  HelpCircle,
  Shield,
  Trash2,
  Check,
  Zap,
  Smartphone,
  Sparkles,
} from 'lucide-react';
import { GameSettings } from '../types/game';

interface SettingsModalProps {
  isOpen: boolean;
  settings: GameSettings;
  onUpdateSettings: (newSettings: Partial<GameSettings>) => void;
  onRestart?: () => void;
  onResetHighScore: () => void;
  onClose: () => void;
}

export const SettingsModal: React.FC<SettingsModalProps> = ({
  isOpen,
  settings,
  onUpdateSettings,
  onRestart,
  onResetHighScore,
  onClose,
}) => {
  const [confirmReset, setConfirmReset] = useState(false);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-xl animate-fade-in select-none">
      <div className="relative w-full max-w-md max-h-[90vh] overflow-y-auto rounded-3xl glass-panel-colorful p-5 text-left text-cyan-100 shadow-[0_0_60px_rgba(168,85,247,0.35)]">
        {/* Futuristic Corner Brackets */}
        <div className="absolute top-3 left-3 w-3 h-3 border-t-2 border-l-2 border-cyan-300 drop-shadow-[0_0_6px_rgba(0,240,255,0.8)]" />
        <div className="absolute top-3 right-3 w-3 h-3 border-t-2 border-r-2 border-cyan-300 drop-shadow-[0_0_6px_rgba(0,240,255,0.8)]" />
        <div className="absolute bottom-3 left-3 w-3 h-3 border-b-2 border-l-2 border-cyan-300 drop-shadow-[0_0_6px_rgba(0,240,255,0.8)]" />
        <div className="absolute bottom-3 right-3 w-3 h-3 border-b-2 border-r-2 border-cyan-300 drop-shadow-[0_0_6px_rgba(0,240,255,0.8)]" />

        {/* Modal Header */}
        <div className="flex items-center justify-between pb-3 mb-4 border-b border-white/10">
          <div className="flex items-center gap-2.5">
            <div className="p-1.5 rounded-xl bg-pink-500/15 border border-pink-400/40 text-pink-300 shadow-[0_0_12px_rgba(255,51,102,0.3)]">
              <Sparkles className="w-5 h-5 text-pink-400" />
            </div>
            <div>
              <h2 className="text-base sm:text-lg font-black uppercase tracking-wider text-white font-['Chakra_Petch',sans-serif]">
                FRUIT BUBBLE SETTINGS
              </h2>
              <p className="text-[10px] font-bold text-pink-400 font-mono tracking-widest uppercase">
                GAME PREFERENCES
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-xl btn-arcade flex items-center justify-center text-pink-300 transition-colors cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Quick Options */}
        <div className="space-y-2.5 mb-5">
          {/* Sound & Voice Toggle */}
          <div className="flex items-center justify-between p-3 rounded-2xl bg-white/[0.04] border border-white/10">
            <div className="flex items-center gap-3">
              <div className="w-9 h-9 rounded-xl bg-[#1c1545] border border-cyan-400/20 flex items-center justify-center text-cyan-300 shadow-sm">
                {settings.soundEnabled ? (
                  <Volume2 className="w-4 h-4 text-cyan-300" />
                ) : (
                  <VolumeX className="w-4 h-4 text-rose-400" />
                )}
              </div>
              <div>
                <div className="text-sm font-bold text-white">Audio & Voice</div>
                <div className="text-xs text-purple-300/80 font-mono">
                  {settings.soundEnabled ? 'SFX & Announcements Active' : 'Sound Muted'}
                </div>
              </div>
            </div>
            <button
              onClick={() => onUpdateSettings({ soundEnabled: !settings.soundEnabled })}
              className={`px-3.5 py-1.5 rounded-xl text-xs font-extrabold uppercase transition-all cursor-pointer ${
                settings.soundEnabled
                  ? 'bg-cyan-400/25 text-cyan-200 border border-cyan-400/60 shadow-[0_0_12px_rgba(0,240,255,0.35)]'
                  : 'bg-rose-950/80 text-rose-300 border border-rose-700/60'
              }`}
            >
              {settings.soundEnabled ? 'Active' : 'Muted'}
            </button>
          </div>

          {/* Music Toggle */}
          <div className="flex items-center justify-between p-3 rounded-2xl bg-white/[0.04] border border-white/10">
            <div className="flex items-center gap-3">
              <div className="w-9 h-9 rounded-xl bg-[#1c1545] border border-cyan-400/20 flex items-center justify-center text-cyan-300 shadow-sm">
                <Music className={`w-4 h-4 ${settings.musicEnabled ? 'text-fuchsia-300' : 'text-white/40'}`} />
              </div>
              <div>
                <div className="text-sm font-bold text-white">Background Music</div>
                <div className="text-xs text-purple-300/80 font-mono">
                  {settings.musicEnabled ? 'Cartoon Melody Active' : 'Music Off'}
                </div>
              </div>
            </div>
            <button
              onClick={() => onUpdateSettings({ musicEnabled: !settings.musicEnabled })}
              className={`px-3.5 py-1.5 rounded-xl text-xs font-extrabold uppercase transition-all cursor-pointer ${
                settings.musicEnabled
                  ? 'bg-fuchsia-500/25 text-fuchsia-200 border border-fuchsia-400/60 shadow-[0_0_12px_rgba(217,70,239,0.35)]'
                  : 'bg-white/10 text-white/50 border border-white/20'
              }`}
            >
              {settings.musicEnabled ? 'Active' : 'Off'}
            </button>
          </div>

          {/* Vibration / Haptic Toggle */}
          <div className="flex items-center justify-between p-3 rounded-2xl bg-white/[0.04] border border-white/10">
            <div className="flex items-center gap-3">
              <div className="w-9 h-9 rounded-xl bg-[#1c1545] border border-cyan-400/20 flex items-center justify-center text-cyan-300 shadow-sm">
                <Smartphone className={`w-4 h-4 ${settings.vibrationEnabled ? 'text-cyan-300' : 'text-white/40'}`} />
              </div>
              <div>
                <div className="text-sm font-bold text-white">Haptic Vibration</div>
                <div className="text-xs text-purple-300/80 font-mono">
                  {settings.vibrationEnabled ? 'Touch Vibration On' : 'Vibration Off'}
                </div>
              </div>
            </div>
            <button
              onClick={() => onUpdateSettings({ vibrationEnabled: !settings.vibrationEnabled })}
              className={`px-3.5 py-1.5 rounded-xl text-xs font-extrabold uppercase transition-all cursor-pointer ${
                settings.vibrationEnabled
                  ? 'bg-cyan-400/25 text-cyan-200 border border-cyan-400/60 shadow-[0_0_12px_rgba(0,240,255,0.35)]'
                  : 'bg-white/10 text-white/50 border border-white/20'
              }`}
            >
              {settings.vibrationEnabled ? 'On' : 'Off'}
            </button>
          </div>

          {/* Quick Restart if in game */}
          {onRestart && (
            <div className="flex items-center justify-between p-3 rounded-2xl bg-white/[0.04] border border-white/10">
              <div className="flex items-center gap-3">
                <div className="w-9 h-9 rounded-xl bg-[#1c1545] border border-cyan-400/20 flex items-center justify-center text-cyan-300 shadow-sm">
                  <RotateCcw className="w-4 h-4" />
                </div>
                <div>
                  <div className="text-sm font-bold text-white">Restart Level</div>
                  <div className="text-xs text-purple-300/80 font-mono">Reset current sector score to 0</div>
                </div>
              </div>
              <button
                onClick={() => {
                  onRestart();
                  onClose();
                }}
                className="px-3.5 py-1.5 rounded-xl text-xs font-extrabold uppercase btn-arcade text-cyan-300 cursor-pointer"
              >
                Restart
              </button>
            </div>
          )}
        </div>

        {/* How to Play / Directives */}
        <div className="p-3.5 mb-5 rounded-2xl bg-white/[0.04] border border-white/10 space-y-2.5">
          <div className="flex items-center gap-2 text-xs font-extrabold uppercase tracking-wider text-cyan-300">
            <HelpCircle className="w-4 h-4 text-cyan-400" />
            <span>Gameplay Directives</span>
          </div>
          <ul className="text-xs text-purple-200/90 space-y-2 list-disc list-inside leading-relaxed font-sans">
            <li>
              <strong className="text-white">7×7 Matrix:</strong> Drag and lock pieces into the energy grid.
            </li>
            <li>
              <strong className="text-cyan-300">3-Piece Batches:</strong> Place all 3 pieces before receiving a new batch.
            </li>
            <li>
              <strong className="text-amber-300">Level Target:</strong> Reach that level's target score to unlock the next sector. Each level starts from 0 points.
            </li>
            <li>
              <strong className="text-fuchsia-300">Power Only From Clears:</strong> Only completing full rows or columns awards points and charges your multiplier.
            </li>
          </ul>
        </div>

        {/* Reset High Score Action */}
        <div className="pt-2 border-t border-white/10 flex items-center justify-between">
          {!confirmReset ? (
            <button
              onClick={() => setConfirmReset(true)}
              className="text-xs text-rose-400/80 hover:text-rose-300 flex items-center gap-1.5 transition-colors cursor-pointer"
            >
              <Trash2 className="w-3.5 h-3.5" />
              <span>Reset Peak High Score</span>
            </button>
          ) : (
            <div className="flex items-center gap-2 w-full justify-between">
              <span className="text-xs text-rose-300 font-bold">Confirm reset high score?</span>
              <div className="flex items-center gap-2">
                <button
                  onClick={() => {
                    onResetHighScore();
                    setConfirmReset(false);
                  }}
                  className="px-3 py-1 rounded-xl bg-rose-600 text-white text-xs font-bold hover:bg-rose-500 cursor-pointer"
                >
                  Confirm
                </button>
                <button
                  onClick={() => setConfirmReset(false)}
                  className="px-3 py-1 rounded-xl bg-white/10 text-white text-xs hover:bg-white/20 cursor-pointer"
                >
                  Cancel
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
