import React, { useEffect, useRef } from 'react';
import { ReactorColor } from '../types/game';
import { REACTOR_COLORS } from '../utils/shapes';
import { BOARD_SIZE } from '../utils/gameLogic';

export interface ParticleEffect {
  triggerLineClear: (
    rows: number[],
    cols: number[],
    gridRect: DOMRect,
    color: ReactorColor,
    comboText?: string
  ) => void;
  triggerPlaceImpact: (x: number, y: number, color: ReactorColor) => void;
}

interface Particle {
  x: number;
  y: number;
  vx: number;
  vy: number;
  size: number;
  color: string;
  alpha: number;
  decay: number;
  life: number;
}

interface Shockwave {
  x: number;
  y: number;
  radius: number;
  maxRadius: number;
  color: string;
  alpha: number;
}

interface Beam {
  isRow: boolean;
  coord: number; // Y for row, X for col
  thickness: number;
  length: number;
  start: number;
  color: string;
  alpha: number;
}

interface FloatingText {
  text: string;
  x: number;
  y: number;
  color: string;
  alpha: number;
  scale: number;
}

export const ParticleCanvas = React.forwardRef<ParticleEffect, {}>((_, ref) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const particlesRef = useRef<Particle[]>([]);
  const shockwavesRef = useRef<Shockwave[]>([]);
  const beamsRef = useRef<Beam[]>([]);
  const textsRef = useRef<FloatingText[]>([]);
  const animFrameRef = useRef<number | null>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const handleResize = () => {
      canvas.width = window.innerWidth;
      canvas.height = window.innerHeight;
    };

    handleResize();
    window.addEventListener('resize', handleResize);

    // Main 60fps render loop
    const render = () => {
      const ctx = canvas.getContext('2d');
      if (ctx) {
        ctx.clearRect(0, 0, canvas.width, canvas.height);

        // 1. Draw Beams
        for (let i = beamsRef.current.length - 1; i >= 0; i--) {
          const b = beamsRef.current[i];
          ctx.save();
          ctx.globalAlpha = Math.max(0, b.alpha);
          ctx.shadowBlur = 15;
          ctx.shadowColor = b.color;
          ctx.fillStyle = b.color;

          if (b.isRow) {
            ctx.fillRect(b.start, b.coord - b.thickness / 2, b.length, b.thickness);
          } else {
            ctx.fillRect(b.coord - b.thickness / 2, b.start, b.thickness, b.length);
          }
          ctx.restore();

          b.thickness *= 0.92;
          b.alpha -= 0.05;
          if (b.alpha <= 0) {
            beamsRef.current.splice(i, 1);
          }
        }

        // 2. Draw Shockwaves
        for (let i = shockwavesRef.current.length - 1; i >= 0; i--) {
          const s = shockwavesRef.current[i];
          ctx.save();
          ctx.globalAlpha = Math.max(0, s.alpha);
          ctx.lineWidth = 3;
          ctx.strokeStyle = s.color;
          ctx.shadowBlur = 12;
          ctx.shadowColor = s.color;
          ctx.beginPath();
          ctx.arc(s.x, s.y, s.radius, 0, Math.PI * 2);
          ctx.stroke();
          ctx.restore();

          s.radius += (s.maxRadius - s.radius) * 0.18 + 1;
          s.alpha -= 0.045;
          if (s.alpha <= 0 || s.radius >= s.maxRadius) {
            shockwavesRef.current.splice(i, 1);
          }
        }

        // 3. Draw Particles
        for (let i = particlesRef.current.length - 1; i >= 0; i--) {
          const p = particlesRef.current[i];
          ctx.save();
          ctx.globalAlpha = Math.max(0, p.alpha);
          ctx.fillStyle = p.color;
          ctx.shadowBlur = 8;
          ctx.shadowColor = p.color;
          ctx.beginPath();
          ctx.arc(p.x, p.y, p.size, 0, Math.PI * 2);
          ctx.fill();
          ctx.restore();

          p.x += p.vx;
          p.y += p.vy;
          p.vx *= 0.96;
          p.vy *= 0.96;
          p.alpha -= p.decay;
          p.size = Math.max(0.5, p.size * 0.98);

          if (p.alpha <= 0) {
            particlesRef.current.splice(i, 1);
          }
        }

        // 4. Draw Floating Text (Combo Callouts)
        for (let i = textsRef.current.length - 1; i >= 0; i--) {
          const t = textsRef.current[i];
          ctx.save();
          ctx.globalAlpha = Math.max(0, t.alpha);
          ctx.font = `bold ${Math.round(24 * t.scale)}px "Chakra Petch", "JetBrains Mono", sans-serif`;
          ctx.textAlign = 'center';
          ctx.shadowBlur = 16;
          ctx.shadowColor = t.color;
          ctx.fillStyle = '#ffffff';
          ctx.fillText(t.text, t.x, t.y);

          ctx.lineWidth = 1.5;
          ctx.strokeStyle = t.color;
          ctx.strokeText(t.text, t.x, t.y);
          ctx.restore();

          t.y -= 1.6;
          t.scale = Math.min(1.3, t.scale + 0.02);
          t.alpha -= 0.025;
          if (t.alpha <= 0) {
            textsRef.current.splice(i, 1);
          }
        }
      }

      animFrameRef.current = requestAnimationFrame(render);
    };

    animFrameRef.current = requestAnimationFrame(render);

    return () => {
      window.removeEventListener('resize', handleResize);
      if (animFrameRef.current) cancelAnimationFrame(animFrameRef.current);
    };
  }, []);

  React.useImperativeHandle(ref, () => ({
    triggerPlaceImpact: (x: number, y: number, color: ReactorColor) => {
      const scheme = REACTOR_COLORS[color] || REACTOR_COLORS.blue;
      // Gentle juicy bubble ripple
      shockwavesRef.current.push({
        x,
        y,
        radius: 8,
        maxRadius: 38,
        color: scheme.core,
        alpha: 0.85,
      });

      // Fruit juice splash droplets
      for (let i = 0; i < 12; i++) {
        const angle = (Math.PI * 2 * i) / 12 + Math.random() * 0.4;
        const speed = 1.8 + Math.random() * 3.2;
        particlesRef.current.push({
          x,
          y,
          vx: Math.cos(angle) * speed,
          vy: Math.sin(angle) * speed,
          size: 2.2 + Math.random() * 2.8,
          color: Math.random() > 0.3 ? scheme.core : scheme.coreHighlight,
          alpha: 0.95,
          decay: 0.035 + Math.random() * 0.025,
          life: 1,
        });
      }
    },

    triggerLineClear: (
      rows: number[],
      cols: number[],
      gridRect: DOMRect,
      color: ReactorColor,
      comboText?: string
    ) => {
      const scheme = REACTOR_COLORS[color] || REACTOR_COLORS.blue;
      const cellW = gridRect.width / BOARD_SIZE;
      const cellH = gridRect.height / BOARD_SIZE;

      // Create juicy bubble pop wave across cleared rows
      rows.forEach((r) => {
        const centerY = gridRect.top + r * cellH + cellH / 2;
        beamsRef.current.push({
          isRow: true,
          coord: centerY,
          thickness: 16,
          start: gridRect.left - 15,
          length: gridRect.width + 30,
          color: scheme.coreHighlight,
          alpha: 0.9,
        });

        // Spawn juicy bubble beads and splashing droplets
        for (let i = 0; i < 24; i++) {
          const px = gridRect.left + (gridRect.width * i) / 24 + (Math.random() - 0.5) * 8;
          const py = centerY + (Math.random() - 0.5) * 12;
          particlesRef.current.push({
            x: px,
            y: py,
            vx: (Math.random() - 0.5) * 3.5,
            vy: (Math.random() - 0.5) * 6 - 1, // upward drift
            size: 2.5 + Math.random() * 3.5,
            color: Math.random() > 0.3 ? scheme.core : scheme.coreHighlight,
            alpha: 1,
            decay: 0.02 + Math.random() * 0.02,
            life: 1,
          });
        }
      });

      // Create juicy bubble pop wave down cleared cols
      cols.forEach((c) => {
        const centerX = gridRect.left + c * cellW + cellW / 2;
        beamsRef.current.push({
          isRow: false,
          coord: centerX,
          thickness: 16,
          start: gridRect.top - 15,
          length: gridRect.height + 30,
          color: scheme.coreHighlight,
          alpha: 0.9,
        });

        // Spawn juicy bubble beads along column
        for (let i = 0; i < 24; i++) {
          const px = centerX + (Math.random() - 0.5) * 12;
          const py = gridRect.top + (gridRect.height * i) / 24 + (Math.random() - 0.5) * 8;
          particlesRef.current.push({
            x: px,
            y: py,
            vx: (Math.random() - 0.5) * 6,
            vy: (Math.random() - 0.5) * 3.5 - 1,
            size: 2.5 + Math.random() * 3.5,
            color: Math.random() > 0.3 ? scheme.core : scheme.coreHighlight,
            alpha: 1,
            decay: 0.02 + Math.random() * 0.02,
            life: 1,
          });
        }
      });

      // Expanding juicy bubble pop shockwave
      const centerX = gridRect.left + gridRect.width / 2;
      const centerY = gridRect.top + gridRect.height / 2;
      shockwavesRef.current.push({
        x: centerX,
        y: centerY,
        radius: 12,
        maxRadius: Math.max(gridRect.width, gridRect.height) * 0.65,
        color: scheme.core,
        alpha: 0.9,
      });

      // Show floating combo text if provided
      if (comboText) {
        textsRef.current.push({
          text: comboText,
          x: centerX,
          y: centerY - 20,
          color: scheme.coreHighlight,
          alpha: 1,
          scale: 0.85,
        });
      }
    },
  }));

  return (
    <canvas
      ref={canvasRef}
      className="fixed inset-0 pointer-events-none z-50 overflow-hidden"
    />
  );
});

ParticleCanvas.displayName = 'ParticleCanvas';
