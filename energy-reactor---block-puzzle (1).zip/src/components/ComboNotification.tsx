import React, { useEffect, useState } from 'react';
import { Flame, Zap, Sparkles } from 'lucide-react';

export interface ComboNotificationData {
  id: number;
  count: number; // e.g. 2 for 2nd consecutive, 3 for 3rd, etc.
  multiplier: number; // scoring multiplier (2, 3, 4)
  visible: boolean;
}

interface ComboNotificationProps {
  combo: ComboNotificationData | null;
}

export const ComboNotification: React.FC<ComboNotificationProps> = ({ combo }) => {
  const [pulseKey, setPulseKey] = useState<number>(0);

  useEffect(() => {
    if (combo?.visible) {
      setPulseKey((k) => k + 1);
    }
  }, [combo?.id, combo?.count, combo?.visible]);

  if (!combo) return null;

  const count = combo.count;
  const isHighCombo = count >= 4;
  const isMidCombo = count === 3;

  return (
    <aside
      aria-label="Combo streak notification"
      className={`fixed top-16 sm:top-20 right-2 sm:right-4 z-40 pointer-events-none select-none transition-all duration-300 ease-out transform ${
        combo.visible
          ? 'translate-x-0 opacity-100'
          : 'translate-x-[130%] opacity-0'
      }`}
    >
      <div
        key={pulseKey}
        className={`relative flex items-center gap-2.5 sm:gap-3 p-2.5 sm:p-3 pr-3.5 sm:pr-4 rounded-2xl bg-[#0e0928]/95 border backdrop-blur-xl shadow-2xl overflow-hidden animate-wiggle ${
          isHighCombo
            ? 'border-fuchsia-400/90 shadow-[0_0_30px_rgba(217,70,239,0.55)]'
            : isMidCombo
            ? 'border-amber-400/90 shadow-[0_0_28px_rgba(251,191,36,0.5)]'
            : 'border-cyan-400/80 shadow-[0_0_25px_rgba(0,240,255,0.45)]'
        }`}
      >
        {/* Ambient Animated Corner Beam */}
        <div
          className={`absolute -right-6 -top-6 w-16 h-16 rounded-full blur-xl pointer-events-none ${
            isHighCombo ? 'bg-fuchsia-500/40' : isMidCombo ? 'bg-amber-500/40' : 'bg-cyan-500/40'
          }`}
        />

        {/* Pulsing Icon Shield */}
        <div
          className={`relative w-9 h-9 sm:w-10 sm:h-10 rounded-xl flex items-center justify-center flex-shrink-0 border shadow-inner ${
            isHighCombo
              ? 'bg-gradient-to-br from-fuchsia-500 to-rose-600 border-fuchsia-300 text-white'
              : isMidCombo
              ? 'bg-gradient-to-br from-amber-400 to-orange-500 border-amber-200 text-black'
              : 'bg-gradient-to-br from-cyan-400 to-blue-600 border-cyan-200 text-black'
          }`}
        >
          {isHighCombo ? (
            <Flame className="w-5 h-5 fill-current animate-bounce" />
          ) : isMidCombo ? (
            <Zap className="w-5 h-5 fill-current animate-pulse" />
          ) : (
            <Sparkles className="w-5 h-5 fill-current" />
          )}
        </div>

        {/* Text Area */}
        <div className="flex flex-col">
          <div className="flex items-center gap-1.5">
            <span
              className={`text-base sm:text-lg font-black font-['Chakra_Petch',sans-serif] tracking-wider uppercase leading-none drop-shadow-md ${
                isHighCombo
                  ? 'bg-gradient-to-r from-fuchsia-300 via-pink-200 to-rose-300 bg-clip-text text-transparent'
                  : isMidCombo
                  ? 'bg-gradient-to-r from-amber-200 via-yellow-100 to-orange-300 bg-clip-text text-transparent'
                  : 'bg-gradient-to-r from-cyan-200 via-sky-100 to-blue-200 bg-clip-text text-transparent'
              }`}
            >
              COMBO x{count}
            </span>
            <span
              className={`px-1.5 py-0.2 rounded text-[8px] font-black font-mono tracking-widest uppercase border ${
                isHighCombo
                  ? 'bg-fuchsia-950/80 border-fuchsia-400/80 text-fuchsia-200'
                  : isMidCombo
                  ? 'bg-amber-950/80 border-amber-400/80 text-amber-200'
                  : 'bg-cyan-950/80 border-cyan-400/80 text-cyan-200'
              }`}
            >
              ×{combo.multiplier} PTS
            </span>
          </div>

          <span className="text-[9px] font-bold uppercase font-mono tracking-widest text-purple-200/90 mt-0.5">
            CONSECUTIVE CLEAR
          </span>
        </div>

        {/* 5-Second Linear Timer Drain Indicator at Bottom */}
        <div className="absolute bottom-0 left-0 right-0 h-[2.5px] bg-white/10 overflow-hidden">
          <div
            key={`bar-${combo.id}`}
            className={`h-full ${
              isHighCombo
                ? 'bg-gradient-to-r from-pink-400 to-fuchsia-500'
                : isMidCombo
                ? 'bg-gradient-to-r from-yellow-300 to-amber-500'
                : 'bg-gradient-to-r from-cyan-300 to-blue-500'
            }`}
            style={{
              animation: 'drainBar 5s linear forwards',
            }}
          />
        </div>
      </div>
    </aside>
  );
};
