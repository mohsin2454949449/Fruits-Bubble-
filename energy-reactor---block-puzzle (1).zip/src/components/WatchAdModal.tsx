import React from 'react';
import {
  X,
  Tv,
  Coins,
  Sparkles,
  Zap,
  Play,
  ShieldCheck,
  CheckCircle2,
} from 'lucide-react';
import { sound } from '../utils/audio';
import { ADMOB_CONFIG } from '../services/admobConfig';

interface WatchAdModalProps {
  isOpen: boolean;
  onClose: () => void;
  onWatchAd: (amount: number, label: string) => void;
}

export const WatchAdModal: React.FC<WatchAdModalProps> = ({
  isOpen,
  onClose,
  onWatchAd,
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-fade-in select-none">
      <div className="relative w-full max-w-sm rounded-3xl glass-panel-colorful p-5 text-center overflow-hidden shadow-[0_0_50px_rgba(251,191,36,0.35)] border border-amber-400/50">
        {/* Background glow orbs */}
        <div className="absolute -top-14 left-1/2 -translate-x-1/2 w-56 h-28 bg-gradient-to-r from-amber-400/30 to-yellow-300/30 blur-2xl pointer-events-none" />

        {/* Close Button */}
        <button
          onClick={() => {
            sound.playClick();
            onClose();
          }}
          className="absolute top-3.5 right-3.5 p-2 rounded-full bg-white/10 hover:bg-white/20 text-white active:scale-95 transition-all z-10"
        >
          <X className="w-4 h-4" />
        </button>

        {/* Header Icon */}
        <div className="relative w-16 h-16 mx-auto mb-2.5 flex items-center justify-center">
          <div className="absolute inset-0 rounded-2xl bg-amber-400/20 blur-lg animate-pulse" />
          <div className="w-14 h-14 rounded-2xl bg-gradient-to-tr from-amber-400 to-yellow-500 flex items-center justify-center text-black shadow-lg shadow-amber-400/40">
            <Tv className="w-7 h-7 text-black stroke-[2.5]" />
          </div>
        </div>

        {/* Title */}
        <div className="inline-block px-3 py-0.5 mb-1.5 rounded-full bg-amber-950/80 border border-amber-400/60 text-[10px] font-mono font-bold tracking-widest text-amber-200 uppercase">
          REWARDED VIDEO ADS
        </div>
        <h2 className="text-xl font-black text-white uppercase tracking-wider font-['Chakra_Petch',sans-serif] mb-1">
          FREE BONUS COINS
        </h2>
        <p className="text-[11px] text-amber-200/90 mb-4 max-w-xs mx-auto">
          Watch a quick video advertisement to earn free coins for new Core Themes and Box Frames!
        </p>

        {/* Ad Opportunity Cards */}
        <div className="space-y-3 mb-4">
          {/* Option 1: 500 Coins */}
          <div className="p-3.5 rounded-2xl bg-white/[0.06] border border-amber-400/30 flex items-center justify-between gap-3 text-left hover:border-amber-400/60 transition-all">
            <div className="flex items-center gap-2.5">
              <div className="w-10 h-10 rounded-xl bg-amber-400/20 border border-amber-400/40 flex items-center justify-center text-amber-300">
                <Coins className="w-5 h-5 fill-amber-400" />
              </div>
              <div>
                <div className="text-xs font-black text-white uppercase flex items-center gap-1">
                  <span>Quick Boost</span>
                  <Zap className="w-3 h-3 text-yellow-300 fill-yellow-300" />
                </div>
                <div className="text-sm font-black font-mono text-amber-300">
                  +500 Coins
                </div>
              </div>
            </div>

            <button
              onClick={() => {
                sound.playClick();
                onWatchAd(500, 'Quick Boost (+500 Coins)');
              }}
              className="py-2 px-3 rounded-xl bg-gradient-to-r from-amber-400 to-yellow-500 text-black font-black text-xs uppercase tracking-wider shadow-md hover:scale-105 active:scale-95 transition-all flex items-center gap-1.5"
            >
              <Play className="w-3.5 h-3.5 fill-black" />
              <span>Watch</span>
            </button>
          </div>

          {/* Option 2: 1,000 Coins */}
          <div className="p-3.5 rounded-2xl bg-white/[0.06] border border-yellow-400/40 flex items-center justify-between gap-3 text-left hover:border-yellow-400/70 transition-all relative overflow-hidden">
            <div className="absolute top-0 right-0 px-2 py-0.5 rounded-bl-xl bg-yellow-400 text-black text-[8px] font-black uppercase font-mono">
              POPULAR
            </div>
            <div className="flex items-center gap-2.5">
              <div className="w-10 h-10 rounded-xl bg-yellow-400/25 border border-yellow-400/50 flex items-center justify-center text-yellow-200">
                <Sparkles className="w-5 h-5 text-yellow-300 fill-yellow-300" />
              </div>
              <div>
                <div className="text-xs font-black text-white uppercase flex items-center gap-1">
                  <span>Super Stash</span>
                  <Sparkles className="w-3 h-3 text-yellow-300" />
                </div>
                <div className="text-sm font-black font-mono text-yellow-300">
                  +1,000 Coins
                </div>
              </div>
            </div>

            <button
              onClick={() => {
                sound.playClick();
                onWatchAd(1000, 'Super Stash (+1,000 Coins)');
              }}
              className="py-2 px-3 rounded-xl bg-gradient-to-r from-yellow-300 via-amber-400 to-yellow-500 text-black font-black text-xs uppercase tracking-wider shadow-md hover:scale-105 active:scale-95 transition-all flex items-center gap-1.5"
            >
              <Play className="w-3.5 h-3.5 fill-black" />
              <span>Watch</span>
            </button>
          </div>
        </div>

        {/* AdMob Test Mode Footer Note */}
        <div className="p-2.5 rounded-xl bg-slate-900/60 border border-white/10 flex items-center justify-center gap-1.5 text-[10px] font-mono text-slate-300">
          <ShieldCheck className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
          <span>Google AdMob Android Test Mode Enabled</span>
        </div>
      </div>
    </div>
  );
};
