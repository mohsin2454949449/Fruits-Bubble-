import { CoreRarity } from './coreThemes';

export interface BgThemeItem {
  id: string;
  name: string;
  rarity: CoreRarity;
  price: number;
  tagline: string;
  description: string;
  gradient: string;
  orb1: { class: string; style?: React.CSSProperties };
  orb2: { class: string; style?: React.CSSProperties };
  orb3: { class: string; style?: React.CSSProperties };
  ambientAura: string;
  patternType?: 'bubbles' | 'stars' | 'grid' | 'leaves' | 'sparkles' | 'clouds';
  previewColor: string;
  previewGradient: string;
}

export const BACKGROUND_THEMES: BgThemeItem[] = [
  // 0. Default Cosmic Theme
  {
    id: 'bg_cosmic',
    name: 'Cosmic Blue & Violet',
    rarity: 'Default',
    price: 0,
    tagline: 'Deep Space Bubble Constellation',
    description: 'The iconic deep indigo cosmic void with soft strawberry and grape ambient nebulas and twinkling starlight.',
    gradient: 'from-[#2c0e3a] via-[#170926] to-[#090412]',
    orb1: { class: 'bg-pink-500/15' },
    orb2: { class: 'bg-purple-600/16' },
    orb3: { class: 'bg-amber-500/12' },
    ambientAura: 'rgba(244, 63, 94, 0.1)',
    patternType: 'bubbles',
    previewColor: '#c084fc',
    previewGradient: 'from-pink-600 via-purple-800 to-indigo-950',
  },

  // 1. Candy Fantasy
  {
    id: 'bg_candy',
    name: 'Candy Fantasy',
    rarity: 'Basic',
    price: 4000,
    tagline: 'Sugar-Coated Pastel Wonderland',
    description: 'Sweet cotton-candy pink and sky-blue glowing confectionery aura with playful marshmallow bubble glints.',
    gradient: 'from-[#3b1236] via-[#210926] to-[#0d0414]',
    orb1: { class: 'bg-rose-400/20' },
    orb2: { class: 'bg-pink-500/20' },
    orb3: { class: 'bg-yellow-400/15' },
    ambientAura: 'rgba(251, 113, 133, 0.15)',
    patternType: 'sparkles',
    previewColor: '#f43f5e',
    previewGradient: 'from-rose-400 via-pink-500 to-amber-300',
  },

  // 2. Ocean Bubble
  {
    id: 'bg_ocean',
    name: 'Ocean Bubble',
    rarity: 'Basic',
    price: 6000,
    tagline: 'Deep Coral Abyssal Waters',
    description: 'Soothing oceanic turquoise and abyssal deep-sea blue with shimmering underwater bubbles and bioluminescence.',
    gradient: 'from-[#082b3d] via-[#051824] to-[#020b12]',
    orb1: { class: 'bg-cyan-400/18' },
    orb2: { class: 'bg-teal-500/18' },
    orb3: { class: 'bg-blue-600/15' },
    ambientAura: 'rgba(6, 182, 212, 0.14)',
    patternType: 'bubbles',
    previewColor: '#06b6d4',
    previewGradient: 'from-cyan-400 via-teal-600 to-blue-950',
  },

  // 3. Magical Forest
  {
    id: 'bg_forest',
    name: 'Magical Forest',
    rarity: 'Advanced',
    price: 8000,
    tagline: 'Enchanted Evergreen Canopy',
    description: 'Emerald and jade enchanted woodland night with floating bioluminescent fireflies and golden fairy mist.',
    gradient: 'from-[#0b3320] via-[#071e13] to-[#030d08]',
    orb1: { class: 'bg-emerald-400/18' },
    orb2: { class: 'bg-lime-500/15' },
    orb3: { class: 'bg-teal-600/15' },
    ambientAura: 'rgba(16, 185, 129, 0.15)',
    patternType: 'leaves',
    previewColor: '#10b981',
    previewGradient: 'from-emerald-400 via-green-600 to-teal-950',
  },

  // 4. Crystal Kingdom
  {
    id: 'bg_crystal',
    name: 'Crystal Kingdom',
    rarity: 'Rare',
    price: 10000,
    tagline: 'Crystalline Spires & Diamond Caverns',
    description: 'Majestic crystalline palace bathed in refraction prisms, polar cyan lights, and sapphire gem dust.',
    gradient: 'from-[#0f2e45] via-[#091a29] to-[#030a12]',
    orb1: { class: 'bg-sky-300/22' },
    orb2: { class: 'bg-cyan-400/18' },
    orb3: { class: 'bg-indigo-500/18' },
    ambientAura: 'rgba(56, 189, 248, 0.15)',
    patternType: 'stars',
    previewColor: '#38bdf8',
    previewGradient: 'from-sky-300 via-blue-500 to-indigo-950',
  },

  // 5. Galaxy Space
  {
    id: 'bg_galaxy',
    name: 'Galaxy Space',
    rarity: 'Rare',
    price: 12000,
    tagline: 'Deep Orion Spiral Nebula',
    description: 'Epic cosmic galaxy spiral with swirling purple-and-violet star clouds, supernovas, and celestial dust.',
    gradient: 'from-[#2a0840] via-[#160424] to-[#08020e]',
    orb1: { class: 'bg-purple-500/22' },
    orb2: { class: 'bg-fuchsia-600/18' },
    orb3: { class: 'bg-blue-600/18' },
    ambientAura: 'rgba(168, 85, 247, 0.16)',
    patternType: 'stars',
    previewColor: '#a855f7',
    previewGradient: 'from-fuchsia-500 via-purple-700 to-slate-950',
  },

  // 6. Neon Cyber
  {
    id: 'bg_cyber',
    name: 'Neon Cyber',
    rarity: 'Rare',
    price: 14000,
    tagline: 'Futuristic Megacity Wireframe',
    description: 'High-tech synthwave darkscape laced with glowing hot-pink and electric-cyan laser grids and cyber glow.',
    gradient: 'from-[#330833] via-[#1c041f] to-[#0b020d]',
    orb1: { class: 'bg-pink-500/22' },
    orb2: { class: 'bg-cyan-400/20' },
    orb3: { class: 'bg-purple-600/18' },
    ambientAura: 'rgba(236, 72, 153, 0.18)',
    patternType: 'grid',
    previewColor: '#ec4899',
    previewGradient: 'from-pink-500 via-purple-600 to-cyan-500',
  },

  // 7. Dreamy Cloud World
  {
    id: 'bg_cloud',
    name: 'Dreamy Cloud World',
    rarity: 'Epic',
    price: 15000,
    tagline: 'Sunset Pastel Cloud Horizon',
    description: 'Ethereal sunset cumulus clouds glowing with warm lavender, peach twilight, and shimmering star mist.',
    gradient: 'from-[#381635] via-[#1f0b24] to-[#0d0414]',
    orb1: { class: 'bg-amber-300/18' },
    orb2: { class: 'bg-pink-400/20' },
    orb3: { class: 'bg-indigo-400/18' },
    ambientAura: 'rgba(244, 114, 182, 0.15)',
    patternType: 'clouds',
    previewColor: '#fb7185',
    previewGradient: 'from-amber-200 via-pink-400 to-purple-700',
  },

  // 8. Lava Fantasy
  {
    id: 'bg_lava',
    name: 'Lava Fantasy',
    rarity: 'Epic',
    price: 18000,
    tagline: 'Magmatic Underworld Embers',
    description: 'Molten magma rivers and fiery volcanic obsidian caverns filled with crackling thermal embers and golden light.',
    gradient: 'from-[#3b0d06] via-[#210603] to-[#0f0201]',
    orb1: { class: 'bg-rose-500/25' },
    orb2: { class: 'bg-orange-500/20' },
    orb3: { class: 'bg-yellow-400/15' },
    ambientAura: 'rgba(244, 63, 94, 0.2)',
    patternType: 'sparkles',
    previewColor: '#f97316',
    previewGradient: 'from-rose-500 via-orange-500 to-yellow-600',
  },

  // 9. Rainbow Sky
  {
    id: 'bg_rainbow',
    name: 'Rainbow Sky',
    rarity: 'Legendary',
    price: 22000,
    tagline: 'Celestial Prismatic Aurora',
    description: 'Breathtaking full-spectrum rainbow curtains flowing gracefully across a magical starlit twilight sky.',
    gradient: 'from-[#2e0f3d] via-[#160724] to-[#090212]',
    orb1: { class: 'bg-pink-400/20' },
    orb2: { class: 'bg-cyan-300/20' },
    orb3: { class: 'bg-yellow-300/18' },
    ambientAura: 'rgba(236, 72, 153, 0.2)',
    patternType: 'sparkles',
    previewColor: '#e879f9',
    previewGradient: 'from-pink-400 via-amber-300 via-emerald-400 via-cyan-400 to-purple-600',
  },

  // 10. Enchanted Garden
  {
    id: 'bg_garden',
    name: 'Enchanted Garden',
    rarity: 'Mythic',
    price: 28000,
    tagline: 'Sacred Blossom Mythic Sanctuary',
    description: 'Ancient blooming mythical garden illuminated by sacred moonlight, glistening dew drops, and shimmering spirit petals.',
    gradient: 'from-[#193325] via-[#0d2116] to-[#050f09]',
    orb1: { class: 'bg-emerald-300/22' },
    orb2: { class: 'bg-pink-300/22' },
    orb3: { class: 'bg-amber-300/18' },
    ambientAura: 'rgba(52, 211, 153, 0.22)',
    patternType: 'leaves',
    previewColor: '#34d399',
    previewGradient: 'from-pink-300 via-emerald-400 to-teal-900',
  },
];
