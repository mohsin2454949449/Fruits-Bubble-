import { CORE_THEMES, CoreThemeItem, CoreRarity } from './coreThemes';
import { CORE_BOX_THEMES, BoxThemeItem } from './boxThemes';
import { BACKGROUND_THEMES, BgThemeItem } from './bgThemes';

export type RewardType = 'coins' | 'coreTheme' | 'boxTheme' | 'bgTheme';

export interface MilestoneReward {
  type: RewardType;
  title: string;
  description: string;
  amount?: number; // coins amount
  itemId?: string;
  itemCategory?: 'Core Design' | 'Core Box Theme' | 'Background Theme';
  rarity?: CoreRarity;
  previewGradient?: string;
  accentColor?: string;
  isCompensation?: boolean;
  bonusCoins?: number;
}

/**
 * Checks whether a level number is a milestone level (10, 20, 30 ... 1000)
 */
export function isMilestoneLevel(levelNumber: number): boolean {
  return levelNumber >= 10 && levelNumber <= 1000 && levelNumber % 10 === 0;
}

/**
 * Generates a weighted, level-calibrated milestone reward.
 * Ensures cosmetics are unowned or converts duplicates to coin compensation.
 */
export function generateMilestoneReward(
  milestoneLevel: number,
  ownedItemIds: string[]
): MilestoneReward {
  // Coin reward choices based on tier
  const coinOptions: { small: number; med: number; large: number; rare: number } = {
    small: 500,
    med: 1000,
    large: 2000,
    rare: 5000,
  };

  // Determine allowed cosmetic rarities and coin bias according to requested milestone tier:
  // - Levels 10–50: Mostly coins + occasional Basic cosmetics
  // - Levels 60–200: Advanced cosmetics + medium/large coins
  // - Levels 210–500: Rare & Epic cosmetics + large/rare coins
  // - Levels 510–1000: Legendary & Mythic cosmetics + rare coins
  let allowedRarities: CoreRarity[] = ['Basic'];
  let cosmeticChance = 0.3; // 30% chance in early levels

  if (milestoneLevel > 500) {
    allowedRarities = ['Legendary', 'Mythic', 'Epic'];
    cosmeticChance = 0.65;
  } else if (milestoneLevel > 200) {
    allowedRarities = ['Rare', 'Epic'];
    cosmeticChance = 0.55;
  } else if (milestoneLevel > 50) {
    allowedRarities = ['Advanced', 'Rare'];
    cosmeticChance = 0.45;
  }

  const rollCosmetic = Math.random() < cosmeticChance;

  if (rollCosmetic) {
    // Gather all unowned items in the allowed rarities across the 3 categories
    const availableCores = CORE_THEMES.filter(
      (t) => t.price > 0 && allowedRarities.includes(t.rarity) && !ownedItemIds.includes(t.id)
    );
    const availableBoxes = CORE_BOX_THEMES.filter(
      (t) => t.price > 0 && allowedRarities.includes(t.rarity) && !ownedItemIds.includes(t.id)
    );
    const availableBgs = BACKGROUND_THEMES.filter(
      (t) => t.price > 0 && allowedRarities.includes(t.rarity) && !ownedItemIds.includes(t.id)
    );

    // Pick a category weighted randomly
    const categories: Array<{
      type: RewardType;
      items: (CoreThemeItem | BoxThemeItem | BgThemeItem)[];
      catName: 'Core Design' | 'Core Box Theme' | 'Background Theme';
    }> = [
      { type: 'coreTheme' as RewardType, items: availableCores, catName: 'Core Design' as const },
      { type: 'boxTheme' as RewardType, items: availableBoxes, catName: 'Core Box Theme' as const },
      { type: 'bgTheme' as RewardType, items: availableBgs, catName: 'Background Theme' as const },
    ].filter((c) => c.items.length > 0);

    if (categories.length > 0) {
      const selectedCategory = categories[Math.floor(Math.random() * categories.length)];
      const chosenItem = selectedCategory.items[Math.floor(Math.random() * selectedCategory.items.length)];

      return {
        type: selectedCategory.type,
        title: chosenItem.name,
        description: chosenItem.description,
        itemId: chosenItem.id,
        itemCategory: selectedCategory.catName,
        rarity: chosenItem.rarity,
        previewGradient: chosenItem.previewGradient,
        accentColor:
          'accentColor' in chosenItem ? chosenItem.accentColor : chosenItem.previewColor,
      };
    } else {
      // All items in the allowed tier are owned! Grant generous compensation coins!
      const compAmount = milestoneLevel > 500 ? 5000 : milestoneLevel > 200 ? 3000 : 2000;
      return {
        type: 'coins',
        title: `Compensation Cache: +${compAmount.toLocaleString()} Coins`,
        description:
          'All cosmetic items in this tier are already owned! Converted to high-value Coins.',
        amount: compAmount,
        rarity: 'Rare',
        isCompensation: true,
      };
    }
  }

  // Grant Coins reward
  let coinAmount = coinOptions.small;
  const rand = Math.random();

  if (milestoneLevel > 500) {
    coinAmount = rand < 0.6 ? coinOptions.rare : coinOptions.large;
  } else if (milestoneLevel > 200) {
    coinAmount = rand < 0.35 ? coinOptions.rare : rand < 0.75 ? coinOptions.large : coinOptions.med;
  } else if (milestoneLevel > 50) {
    coinAmount = rand < 0.2 ? coinOptions.rare : rand < 0.5 ? coinOptions.large : coinOptions.med;
  } else {
    coinAmount = rand < 0.15 ? coinOptions.large : rand < 0.55 ? coinOptions.med : coinOptions.small;
  }

  return {
    type: 'coins',
    title: `Coin Cache: +${coinAmount.toLocaleString()} Coins`,
    description: `Unlocked a bountiful stash of shiny coins for reaching Milestone ${milestoneLevel}!`,
    amount: coinAmount,
    rarity: coinAmount >= 5000 ? 'Rare' : coinAmount >= 2000 ? 'Advanced' : 'Basic',
  };
}
