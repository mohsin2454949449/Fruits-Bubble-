import { PlayerProfile, GameSettings, LevelProgress } from '../types/game';

const PROFILE_KEY = 'block_pulse_profile';
const SETTINGS_KEY = 'block_pulse_settings';

export const DEFAULT_PROFILE: PlayerProfile = {
  level: 1,
  completedLevels: {},
  coins: 300,
  highScore: 0,
  totalGames: 0,
  totalLines: 0,
  totalBlocks: 0,
  maxCombo: 0,
  equippedBlockSkin: 'core_fruit_bubble',
  equippedBoardTheme: 'board_default',
  equippedBgTheme: 'bg_cosmic',
  purchasedItems: ['core_fruit_bubble', 'skin_pulse', 'board_default', 'bg_cosmic'],
  powerups: {
    hammer: 2,
    refresh: 2,
  },
  claimedAchievements: [],
  claimedMilestones: [],
  lastDailyClaimDate: '',
  dailyStreak: 0,
};

export const DEFAULT_SETTINGS: GameSettings = {
  soundEnabled: true,
  musicEnabled: true,
  vibrationEnabled: true,
};

export function loadProfile(): PlayerProfile {
  try {
    const raw = localStorage.getItem(PROFILE_KEY);
    const legacyHighScore = localStorage.getItem('block_pulse_high_score') || localStorage.getItem('energy_reactor_high_score');
    const baseHighScore = legacyHighScore ? parseInt(legacyHighScore, 10) : 0;

    if (!raw) {
      return {
        ...DEFAULT_PROFILE,
        highScore: baseHighScore,
      };
    }

    const parsed = JSON.parse(raw) as Partial<PlayerProfile>;
    const loadedPurchased = parsed.purchasedItems || DEFAULT_PROFILE.purchasedItems;
    if (!loadedPurchased.includes('core_fruit_bubble')) {
      loadedPurchased.push('core_fruit_bubble');
    }

    return {
      ...DEFAULT_PROFILE,
      ...parsed,
      equippedBlockSkin:
        parsed.equippedBlockSkin === 'skin_pulse' || !parsed.equippedBlockSkin
          ? 'core_fruit_bubble'
          : parsed.equippedBlockSkin,
      powerups: {
        ...DEFAULT_PROFILE.powerups,
        ...(parsed.powerups || {}),
      },
      completedLevels: parsed.completedLevels || {},
      purchasedItems: loadedPurchased,
      claimedMilestones: parsed.claimedMilestones || [],
      highScore: Math.max(parsed.highScore || 0, baseHighScore),
    };
  } catch (e) {
    console.error('Failed to load player profile:', e);
    return DEFAULT_PROFILE;
  }
}

export function saveProfile(profile: PlayerProfile): void {
  try {
    localStorage.setItem(PROFILE_KEY, JSON.stringify(profile));
    localStorage.setItem('block_pulse_high_score', String(profile.highScore));
  } catch (e) {
    console.error('Failed to save player profile:', e);
  }
}

export function loadSettings(): GameSettings {
  try {
    const raw = localStorage.getItem(SETTINGS_KEY);
    const legacyMuted = localStorage.getItem('block_pulse_muted') === 'true';

    if (!raw) {
      return {
        ...DEFAULT_SETTINGS,
        soundEnabled: !legacyMuted,
      };
    }

    return {
      ...DEFAULT_SETTINGS,
      ...JSON.parse(raw),
      soundEnabled: !legacyMuted,
    };
  } catch (e) {
    console.error('Failed to load settings:', e);
    return DEFAULT_SETTINGS;
  }
}

export function saveSettings(settings: GameSettings): void {
  try {
    localStorage.setItem(SETTINGS_KEY, JSON.stringify(settings));
    localStorage.setItem('block_pulse_muted', String(!settings.soundEnabled));
  } catch (e) {
    console.error('Failed to save settings:', e);
  }
}

/**
 * Check if the player is eligible to claim today's daily gift
 */
export function isDailyGiftClaimable(lastClaimDate: string): boolean {
  if (!lastClaimDate) return true;
  const todayStr = new Date().toISOString().split('T')[0];
  return todayStr !== lastClaimDate;
}

/**
 * Trigger mobile vibration if enabled and supported by the device
 */
export function triggerHaptic(vibrationEnabled: boolean, pattern: number | number[] = 25): void {
  if (!vibrationEnabled) return;
  if (typeof window !== 'undefined' && 'navigator' in window && 'vibrate' in navigator) {
    try {
      navigator.vibrate(pattern);
    } catch {
      // Ignore vibration errors on unsupported platforms
    }
  }
}
