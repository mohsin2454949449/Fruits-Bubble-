import { ColorScheme, GamePiece, PieceShape, ReactorColor } from '../types/game';

export const REACTOR_COLORS: Record<ReactorColor, ColorScheme> = {
  blue: {
    id: 'blue',
    name: 'Blueberry Plum',
    primary: '#0284c7',
    core: '#38bdf8',
    coreHighlight: '#f0f9ff',
    plasmaGlow: '#00b4d8',
    borderDark: '#034a75',
    borderLight: '#bae6fd',
    recessed: '#072b43',
    socketTint: 'rgba(2, 132, 199, 0.2)',
  },
  red: {
    id: 'red',
    name: 'Strawberry Red',
    primary: '#ff2d55',
    core: '#ff6482',
    coreHighlight: '#fff0f3',
    plasmaGlow: '#ff375f',
    borderDark: '#850020',
    borderLight: '#ffa3b5',
    recessed: '#4a0012',
    socketTint: 'rgba(255, 45, 85, 0.22)',
  },
  green: {
    id: 'green',
    name: 'Kiwi Lime',
    primary: '#10b981',
    core: '#34d399',
    coreHighlight: '#ecfdf5',
    plasmaGlow: '#059669',
    borderDark: '#044e3b',
    borderLight: '#a7f3d0',
    recessed: '#022c22',
    socketTint: 'rgba(16, 185, 129, 0.2)',
  },
  yellow: {
    id: 'yellow',
    name: 'Lemon Mango',
    primary: '#f59e0b',
    core: '#fbbf24',
    coreHighlight: '#fffbeb',
    plasmaGlow: '#ea580c',
    borderDark: '#78350f',
    borderLight: '#fde68a',
    recessed: '#451a03',
    socketTint: 'rgba(245, 158, 11, 0.2)',
  },
  purple: {
    id: 'purple',
    name: 'Grape Berry',
    primary: '#a855f7',
    core: '#c084fc',
    coreHighlight: '#faf5ff',
    plasmaGlow: '#9333ea',
    borderDark: '#581c87',
    borderLight: '#e9d5ff',
    recessed: '#3b0764',
    socketTint: 'rgba(168, 85, 247, 0.2)',
  },
};

export const COLOR_KEYS: ReactorColor[] = ['blue', 'red', 'green', 'yellow', 'purple'];

export const ALL_SHAPES: PieceShape[] = [
  // 1x1 Single
  {
    id: 'dot-1',
    name: 'Single Core',
    matrix: [[1]],
    width: 1,
    height: 1,
  },

  // 2-blocks
  {
    id: 'line-2-h',
    name: 'Twin Array H',
    matrix: [[1, 1]],
    width: 2,
    height: 1,
  },
  {
    id: 'line-2-v',
    name: 'Twin Array V',
    matrix: [[1], [1]],
    width: 1,
    height: 2,
  },

  // 3-blocks Line
  {
    id: 'line-3-h',
    name: 'Tri-Beam H',
    matrix: [[1, 1, 1]],
    width: 3,
    height: 1,
  },
  {
    id: 'line-3-v',
    name: 'Tri-Beam V',
    matrix: [[1], [1], [1]],
    width: 1,
    height: 3,
  },

  // 4-blocks Line
  {
    id: 'line-4-h',
    name: 'Quad-Conduit H',
    matrix: [[1, 1, 1, 1]],
    width: 4,
    height: 1,
  },
  {
    id: 'line-4-v',
    name: 'Quad-Conduit V',
    matrix: [[1], [1], [1], [1]],
    width: 1,
    height: 4,
  },

  // 5-blocks Line
  {
    id: 'line-5-h',
    name: 'Penta-Rail H',
    matrix: [[1, 1, 1, 1, 1]],
    width: 5,
    height: 1,
  },
  {
    id: 'line-5-v',
    name: 'Penta-Rail V',
    matrix: [[1], [1], [1], [1], [1]],
    width: 1,
    height: 5,
  },

  // 2x2 Square
  {
    id: 'square-2',
    name: 'Reactor Quad',
    matrix: [
      [1, 1],
      [1, 1],
    ],
    width: 2,
    height: 2,
  },

  // 3x3 Square
  {
    id: 'square-3',
    name: 'Fusion Matrix',
    matrix: [
      [1, 1, 1],
      [1, 1, 1],
      [1, 1, 1],
    ],
    width: 3,
    height: 3,
  },

  // Small Corner (3 blocks)
  {
    id: 'corner-sm-tl',
    name: 'Corner Alpha',
    matrix: [
      [1, 1],
      [1, 0],
    ],
    width: 2,
    height: 2,
  },
  {
    id: 'corner-sm-tr',
    name: 'Corner Beta',
    matrix: [
      [1, 1],
      [0, 1],
    ],
    width: 2,
    height: 2,
  },
  {
    id: 'corner-sm-bl',
    name: 'Corner Gamma',
    matrix: [
      [1, 0],
      [1, 1],
    ],
    width: 2,
    height: 2,
  },
  {
    id: 'corner-sm-br',
    name: 'Corner Delta',
    matrix: [
      [0, 1],
      [1, 1],
    ],
    width: 2,
    height: 2,
  },

  // Medium L-Shapes (4 blocks)
  {
    id: 'l-med-1',
    name: 'L-Conduit 1',
    matrix: [
      [1, 0],
      [1, 0],
      [1, 1],
    ],
    width: 2,
    height: 3,
  },
  {
    id: 'l-med-2',
    name: 'L-Conduit 2',
    matrix: [
      [0, 1],
      [0, 1],
      [1, 1],
    ],
    width: 2,
    height: 3,
  },
  {
    id: 'l-med-3',
    name: 'L-Conduit 3',
    matrix: [
      [1, 1, 1],
      [1, 0, 0],
    ],
    width: 3,
    height: 2,
  },
  {
    id: 'l-med-4',
    name: 'L-Conduit 4',
    matrix: [
      [1, 1, 1],
      [0, 0, 1],
    ],
    width: 3,
    height: 2,
  },

  // Big Corner (5 blocks)
  {
    id: 'corner-lg-bl',
    name: 'Heavy Corner L',
    matrix: [
      [1, 0, 0],
      [1, 0, 0],
      [1, 1, 1],
    ],
    width: 3,
    height: 3,
  },
  {
    id: 'corner-lg-br',
    name: 'Heavy Corner R',
    matrix: [
      [0, 0, 1],
      [0, 0, 1],
      [1, 1, 1],
    ],
    width: 3,
    height: 3,
  },
  {
    id: 'corner-lg-tl',
    name: 'Heavy Corner TL',
    matrix: [
      [1, 1, 1],
      [1, 0, 0],
      [1, 0, 0],
    ],
    width: 3,
    height: 3,
  },
  {
    id: 'corner-lg-tr',
    name: 'Heavy Corner TR',
    matrix: [
      [1, 1, 1],
      [0, 0, 1],
      [0, 0, 1],
    ],
    width: 3,
    height: 3,
  },

  // T-Shapes (4 blocks)
  {
    id: 't-up',
    name: 'T-Emitter Up',
    matrix: [
      [0, 1, 0],
      [1, 1, 1],
    ],
    width: 3,
    height: 2,
  },
  {
    id: 't-down',
    name: 'T-Emitter Down',
    matrix: [
      [1, 1, 1],
      [0, 1, 0],
    ],
    width: 3,
    height: 2,
  },

  // Z / S shapes (4 blocks)
  {
    id: 'z-shape',
    name: 'Z-Coupler',
    matrix: [
      [1, 1, 0],
      [0, 1, 1],
    ],
    width: 3,
    height: 2,
  },
  {
    id: 's-shape',
    name: 'S-Coupler',
    matrix: [
      [0, 1, 1],
      [1, 1, 0],
    ],
    width: 3,
    height: 2,
  },
];

let pieceIdCounter = 1;

/**
 * Generate exactly 3 random block pieces for the tray batch.
 * Rules:
 * - Exactly 3 pieces per batch.
 * - Avoid duplicate shapes within the same batch.
 * - Each piece has ONE SOLID COLOR ONLY from the 5 required colors.
 * - Supports balanced gradual shape challenge as level increases.
 */
export function generateThreePieces(levelNumber?: number): GamePiece[] {
  let pool = [...ALL_SHAPES];

  // In very early levels (1-5), prioritize friendly starter shapes so players master the 7x7 board
  if (levelNumber && levelNumber <= 5) {
    const starterShapeIds = ['dot-1', 'line-2-h', 'line-2-v', 'square-2', 'line-3-h', 'line-3-v', 'corner-s1', 'corner-s2'];
    const starterShapes = ALL_SHAPES.filter((s) => starterShapeIds.includes(s.id));
    // Mix with a few standard shapes
    pool = [...starterShapes, ...starterShapes, ...ALL_SHAPES];
  }

  // Shuffle all available shapes and pick 3 distinct shapes (no duplicate shapes in same batch)
  const shuffledShapes = [...pool].sort(() => Math.random() - 0.5);
  const selectedShapes: PieceShape[] = [];
  const seenIds = new Set<string>();

  for (const s of shuffledShapes) {
    if (!seenIds.has(s.id)) {
      seenIds.add(s.id);
      selectedShapes.push(s);
      if (selectedShapes.length === 3) break;
    }
  }

  // Fallback if needed
  while (selectedShapes.length < 3) {
    selectedShapes.push(ALL_SHAPES[Math.floor(Math.random() * ALL_SHAPES.length)]);
  }

  // Shuffle colors so pieces in the batch have distinct solid colors
  const shuffledColors = [...COLOR_KEYS].sort(() => Math.random() - 0.5);

  return selectedShapes.map((shape, idx) => ({
    id: `piece-${Date.now()}-${pieceIdCounter++}-${idx}`,
    shape,
    color: shuffledColors[idx % shuffledColors.length],
    used: false,
    canFit: true,
    rotation: 0,
  }));
}
