import { ReactorColor } from '../types/game';

export type CoreRarity =
  | 'Default'
  | 'Basic'
  | 'Advanced'
  | 'Rare'
  | 'Epic'
  | 'Legendary'
  | 'Mythic';

export interface CoreThemeItem {
  id: string;
  name: string;
  rarity: CoreRarity;
  price: number;
  description: string;
  tagline: string;
  previewGradient: string;
  accentColor: string;
  badge?: string;
}

export const RARITY_CONFIG: Record<
  CoreRarity,
  { label: string; bg: string; text: string; border: string; glow: string }
> = {
  Default: {
    label: 'Default',
    bg: 'bg-pink-500/20',
    text: 'text-pink-300',
    border: 'border-pink-400/40',
    glow: 'rgba(244,63,94,0.4)',
  },
  Basic: {
    label: 'Basic',
    bg: 'bg-cyan-500/20',
    text: 'text-cyan-300',
    border: 'border-cyan-400/40',
    glow: 'rgba(6,182,212,0.4)',
  },
  Advanced: {
    label: 'Advanced',
    bg: 'bg-emerald-500/20',
    text: 'text-emerald-300',
    border: 'border-emerald-400/40',
    glow: 'rgba(16,185,129,0.4)',
  },
  Rare: {
    label: 'Rare',
    bg: 'bg-blue-500/20',
    text: 'text-blue-300',
    border: 'border-blue-400/40',
    glow: 'rgba(59,130,246,0.4)',
  },
  Epic: {
    label: 'Epic',
    bg: 'bg-purple-500/20',
    text: 'text-purple-300',
    border: 'border-purple-400/40',
    glow: 'rgba(168,85,247,0.4)',
  },
  Legendary: {
    label: 'Legendary',
    bg: 'bg-amber-500/20',
    text: 'text-amber-300',
    border: 'border-amber-400/40',
    glow: 'rgba(245,158,11,0.5)',
  },
  Mythic: {
    label: 'Mythic',
    bg: 'bg-rose-500/25',
    text: 'text-rose-200',
    border: 'border-rose-400/60',
    glow: 'rgba(244,63,94,0.6)',
  },
};

/**
 * 20 Unique Premium Core Theme Designs + 1 Default Fruit Bubble Design
 * Exact requested designs with calibrated coin price tiers:
 * - Basic: 2,000 coins
 * - Advanced: 5,000 coins
 * - Rare: 10,000 coins
 * - Epic: 20,000 coins
 * - Legendary: 35,000 coins
 * - Mythic: 50,000 coins
 */
export const CORE_THEMES: CoreThemeItem[] = [
  // 0. DEFAULT STARTING DESIGN (Always FREE & UNLOCKED)
  {
    id: 'core_fruit_bubble',
    name: 'Fruit Bubble Core',
    rarity: 'Default',
    price: 0,
    tagline: 'Original Juicy Translucent Glass',
    description:
      'The classic glossy 3D fruit bubble with soft transparent glass shine, dual specular highlights, and vibrant juice depth.',
    previewGradient: 'from-pink-500 via-rose-500 to-amber-500',
    accentColor: '#f43f5e',
    badge: 'STARTER',
  },

  // 1. BASIC PREMIUM DESIGNS (2,000 coins)
  {
    id: 'core_crystal',
    name: 'Crystal Core',
    rarity: 'Basic',
    price: 2000,
    tagline: 'Transparent Geometric Cleavage',
    description:
      'Pure transparent crystalline mineral structure with polished geometric facets, internal cleavage lines, and crisp light glints.',
    previewGradient: 'from-cyan-400 via-sky-300 to-blue-500',
    accentColor: '#38bdf8',
  },
  {
    id: 'core_neon',
    name: 'Neon Energy Core',
    rarity: 'Basic',
    price: 2000,
    tagline: 'Radiant High-Lumen Gas Tube',
    description:
      'Ultra-bright glowing neon tube perimeter with dual perimeter rings and saturated phosphorescent illumination.',
    previewGradient: 'from-lime-400 via-emerald-400 to-cyan-500',
    accentColor: '#22c55e',
  },
  {
    id: 'core_ice',
    name: 'Ice Crystal Core',
    rarity: 'Basic',
    price: 2000,
    tagline: 'Sub-Zero Frosted Glass',
    description:
      'Sub-zero glacial block featuring frost crackles, a delicate hexagonal snowflake core, and frosty white specular edges.',
    previewGradient: 'from-sky-200 via-cyan-400 to-blue-600',
    accentColor: '#7dd3fc',
  },
  {
    id: 'core_aqua',
    name: 'Aqua Bubble Core',
    rarity: 'Basic',
    price: 2000,
    tagline: 'Living Liquid Droplet',
    description:
      'Crystal-clear liquid water sphere with dynamic caustic ripples, rising micro-bubbles, and refractive fluid reflections.',
    previewGradient: 'from-blue-400 via-cyan-400 to-teal-500',
    accentColor: '#06b6d4',
  },

  // 2. ADVANCED DESIGNS (5,000 coins)
  {
    id: 'core_emerald',
    name: 'Emerald Core',
    rarity: 'Advanced',
    price: 5000,
    tagline: 'Deep Beryl Jewel',
    description:
      'Rich emerald-cut beryl crystal with step facets, deep velvety green refraction, and brilliant corner facets.',
    previewGradient: 'from-emerald-400 via-green-500 to-teal-700',
    accentColor: '#10b981',
  },
  {
    id: 'core_ruby',
    name: 'Ruby Core',
    rarity: 'Advanced',
    price: 5000,
    tagline: 'Pigeon-Blood Crimson Jewel',
    description:
      'Precious cushion-cut ruby with fiery internal crimson reflections, radiant brilliance, and sparkling jewel crown.',
    previewGradient: 'from-rose-500 via-red-600 to-purple-800',
    accentColor: '#e11d48',
  },
  {
    id: 'core_sapphire',
    name: 'Sapphire Core',
    rarity: 'Advanced',
    price: 5000,
    tagline: 'Royal Blue Brilliant Cut',
    description:
      'Majestic royal blue sapphire displaying deep cornflower luster, sharp table facets, and icy refractive flashes.',
    previewGradient: 'from-blue-500 via-indigo-600 to-sky-400',
    accentColor: '#2563eb',
  },
  {
    id: 'core_electric',
    name: 'Electric Core',
    rarity: 'Advanced',
    price: 5000,
    tagline: 'High-Voltage Arc Discharge',
    description:
      'Crackling high-voltage lightning bolts arcing across the core with ionized plasma spark bursts and pulsating nodes.',
    previewGradient: 'from-yellow-300 via-amber-400 to-cyan-500',
    accentColor: '#facc15',
  },

  // 3. RARE DESIGNS (10,000 coins)
  {
    id: 'core_diamond',
    name: 'Diamond Core',
    rarity: 'Rare',
    price: 10000,
    tagline: 'Brilliant Diamond-Cut Sheen',
    description:
      'Unsurpassed 58-facet round brilliant diamond cut with pure adamantine luster and kaleidoscopic rainbow light dispersion.',
    previewGradient: 'from-slate-100 via-sky-200 to-indigo-300',
    accentColor: '#e0e7ff',
  },
  {
    id: 'core_plasma',
    name: 'Plasma Core',
    rarity: 'Rare',
    price: 10000,
    tagline: 'Superheated Ionized Gas',
    description:
      'Superheated fusion plasma cell containing kinetic energy filaments, an incandescent core nucleus, and magnetic containment rings.',
    previewGradient: 'from-purple-500 via-fuchsia-500 to-pink-500',
    accentColor: '#c084fc',
  },
  {
    id: 'core_rainbow',
    name: 'Rainbow Glass Core',
    rarity: 'Rare',
    price: 10000,
    tagline: 'Prismatic Spectral Chromatics',
    description:
      'Luminous chromatic prism glass that refracts incoming light into a vivid 7-color rainbow spectrum with smooth glass sheen.',
    previewGradient: 'from-rose-500 via-amber-400 via-emerald-400 via-cyan-400 to-purple-500',
    accentColor: '#f43f5e',
  },
  {
    id: 'core_cyber',
    name: 'Cyber Tech Core',
    rarity: 'Rare',
    price: 10000,
    tagline: 'Hexagonal Quantum Microchip',
    description:
      'Futuristic mechanical chassis featuring etched circuit bus traces, hexagonal micro-mesh, and a pulsing central quantum processor.',
    previewGradient: 'from-cyan-500 via-slate-800 to-blue-900',
    accentColor: '#00f0ff',
  },

  // 4. EPIC DESIGNS (20,000 coins)
  {
    id: 'core_lava',
    name: 'Lava Core',
    rarity: 'Epic',
    price: 20000,
    tagline: 'Molten Magma Obsidian Fissures',
    description:
      'Dark volcanic obsidian crust fractured by glowing orange-red molten magma seams with glowing hot spots and embers.',
    previewGradient: 'from-amber-500 via-orange-600 to-red-950',
    accentColor: '#f97316',
  },
  {
    id: 'core_holographic',
    name: 'Holographic Core',
    rarity: 'Epic',
    price: 20000,
    tagline: 'Futuristic Volumetric Hologram',
    description:
      '3D photonic hologram projector with horizontal raster scanlines, iridescent color-shifting sheen, and futuristic wireframe grid.',
    previewGradient: 'from-teal-300 via-fuchsia-400 to-indigo-400',
    accentColor: '#2dd4bf',
  },
  {
    id: 'core_galaxy',
    name: 'Galaxy Core',
    rarity: 'Epic',
    price: 20000,
    tagline: 'Deep Space Spiral Galaxy',
    description:
      'Vast astronomical void displaying an incandescent spiral galaxy swirl, distant nebulae dust clouds, and twinkling field stars.',
    previewGradient: 'from-indigo-600 via-purple-700 to-slate-950',
    accentColor: '#818cf8',
  },
  {
    id: 'core_cosmic',
    name: 'Cosmic Nebula Core',
    rarity: 'Epic',
    price: 20000,
    tagline: 'Stardust Supernova Clouds',
    description:
      'Ethereal cosmic nebula woven with magenta and teal interstellar stardust clouds, glowing stellar nurseries, and nova sparkles.',
    previewGradient: 'from-fuchsia-500 via-violet-600 to-cyan-500',
    accentColor: '#d946ef',
  },

  // 5. LEGENDARY DESIGNS (35,000 coins)
  {
    id: 'core_gold',
    name: 'Golden Royal Core',
    rarity: 'Legendary',
    price: 35000,
    tagline: '24K Polished Crown Bullion',
    description:
      'Solid 24-karat mirror-polished royal gold block etched with imperial crown emblems, bevelled filigree trims, and metallic gleam.',
    previewGradient: 'from-amber-300 via-yellow-400 to-amber-600',
    accentColor: '#f59e0b',
    badge: 'LUXURY',
  },
  {
    id: 'core_shadow',
    name: 'Shadow Phantom Core',
    rarity: 'Legendary',
    price: 35000,
    tagline: 'Dark Matter Void Phantom',
    description:
      'Eerie dark matter core emitting supernatural purple phantom flames, arcane runic inscriptions, and a swirling void aura.',
    previewGradient: 'from-purple-900 via-slate-900 to-black',
    accentColor: '#a855f7',
    badge: 'DARK',
  },
  {
    id: 'core_solar',
    name: 'Solar Flare Core',
    rarity: 'Legendary',
    price: 35000,
    tagline: 'Blinding Stellar Prominence',
    description:
      'A miniature living star radiating thermonuclear corona prominences, roaring solar flare loops, and an intensely hot core.',
    previewGradient: 'from-yellow-300 via-amber-500 to-rose-600',
    accentColor: '#fbbf24',
    badge: 'SOLAR',
  },

  // 6. MYTHIC DESIGNS (50,000 coins)
  {
    id: 'core_dragon',
    name: 'Mythic Dragon Core',
    rarity: 'Mythic',
    price: 50000,
    tagline: 'Ancient Draconian Dragon Ember',
    description:
      'Ancient mythological dragon scale armor encasing a pulsing volcanic slit dragon eye, burning with primordial dragonfire.',
    previewGradient: 'from-red-600 via-amber-500 to-stone-900',
    accentColor: '#dc2626',
    badge: 'MYTHIC',
  },
];
