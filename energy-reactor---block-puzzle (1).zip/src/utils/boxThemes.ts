import { CoreRarity, RARITY_CONFIG } from './coreThemes';

export interface BoxThemeItem {
  id: string;
  name: string;
  rarity: CoreRarity;
  price: number;
  tagline: string;
  description: string;
  casingStyle: string;
  gridBorderColor: string;
  emptyCellBorder: string;
  cellBg?: string;
  cornerDots: [string, string, string, string]; // Top-left, top-right, bottom-left, bottom-right gradients
  previewColor: string;
  previewGradient: string;
}

export const CORE_BOX_THEMES: BoxThemeItem[] = [
  // 0. Default Free Box
  {
    id: 'box_default',
    name: 'Bubble Glass Box',
    rarity: 'Default',
    price: 0,
    tagline: 'Classic Translucent Fruit Chamber',
    description: 'Smooth translucent indigo glass frame with soft neon purple accents and candy corner dots.',
    casingStyle: 'from-[#2a0e44]/95 via-[#18092d]/95 to-[#0d051c] border-purple-300/35 shadow-[0_14px_45px_rgba(168,85,247,0.28)]',
    gridBorderColor: 'border-purple-400/30',
    emptyCellBorder: 'border-white/15 hover:border-pink-300/70',
    cornerDots: [
      'from-pink-300 to-rose-500',
      'from-cyan-300 to-blue-500',
      'from-emerald-300 to-green-500',
      'from-amber-300 to-yellow-500',
    ],
    previewColor: '#c084fc',
    previewGradient: 'from-purple-900 via-pink-900 to-indigo-950',
  },

  // 1. Crystal Box
  {
    id: 'box_crystal',
    name: 'Crystal Box',
    rarity: 'Basic',
    price: 3000,
    tagline: 'Faceted Glacial Quartz Frame',
    description: 'High-purity crystalline quartz bevels with icy cyan facets and refractive prism borders.',
    casingStyle: 'from-[#0a233a]/95 via-[#071626]/95 to-[#030b14] border-cyan-400/50 shadow-[0_14px_45px_rgba(6,182,212,0.35)]',
    gridBorderColor: 'border-cyan-400/40',
    emptyCellBorder: 'border-cyan-300/20 hover:border-cyan-300/80',
    cellBg: 'bg-cyan-950/20',
    cornerDots: [
      'from-cyan-200 to-sky-400',
      'from-sky-300 to-blue-500',
      'from-teal-200 to-cyan-400',
      'from-white to-sky-300',
    ],
    previewColor: '#38bdf8',
    previewGradient: 'from-cyan-500 via-sky-600 to-blue-900',
  },

  // 2. Neon Box
  {
    id: 'box_neon',
    name: 'Neon Box',
    rarity: 'Basic',
    price: 4000,
    tagline: 'High-Voltage Synthwave Grid',
    description: 'Electrifying neon magenta and cyber lime laser conduits with intense phosphor illumination.',
    casingStyle: 'from-[#3a0d3f]/95 via-[#23082a]/95 to-[#120417] border-pink-500/50 shadow-[0_14px_45px_rgba(236,72,153,0.35)]',
    gridBorderColor: 'border-pink-500/40',
    emptyCellBorder: 'border-pink-400/25 hover:border-pink-300/80',
    cellBg: 'bg-pink-950/20',
    cornerDots: [
      'from-pink-400 to-fuchsia-600',
      'from-lime-300 to-emerald-500',
      'from-cyan-300 to-blue-500',
      'from-yellow-300 to-amber-500',
    ],
    previewColor: '#ec4899',
    previewGradient: 'from-pink-500 via-fuchsia-600 to-purple-950',
  },

  // 3. Ice Box
  {
    id: 'box_ice',
    name: 'Ice Box',
    rarity: 'Basic',
    price: 5000,
    tagline: 'Permafrost Glacial Container',
    description: 'Chilled permafrost ice casing with crystalline frost crackles and sub-zero polar blue cell sockets.',
    casingStyle: 'from-[#072438]/95 via-[#041522]/95 to-[#020a12] border-sky-300/45 shadow-[0_14px_45px_rgba(56,189,248,0.3)]',
    gridBorderColor: 'border-sky-400/35',
    emptyCellBorder: 'border-sky-200/25 hover:border-white',
    cellBg: 'bg-sky-950/25',
    cornerDots: [
      'from-white to-sky-300',
      'from-sky-200 to-blue-400',
      'from-cyan-200 to-sky-500',
      'from-blue-200 to-indigo-400',
    ],
    previewColor: '#7dd3fc',
    previewGradient: 'from-sky-300 via-cyan-500 to-blue-900',
  },

  // 4. Golden Box
  {
    id: 'box_golden',
    name: 'Golden Box',
    rarity: 'Advanced',
    price: 6000,
    tagline: 'Imperial 24K Gilded Frame',
    description: 'Luxurious burnished 24-karat gold molding with warm stellar amber bevels and radiant auric luster.',
    casingStyle: 'from-[#3d2708]/95 via-[#261704]/95 to-[#120a02] border-amber-400/55 shadow-[0_14px_45px_rgba(245,158,11,0.35)]',
    gridBorderColor: 'border-amber-400/45',
    emptyCellBorder: 'border-amber-300/25 hover:border-yellow-200',
    cellBg: 'bg-amber-950/25',
    cornerDots: [
      'from-yellow-200 to-amber-500',
      'from-amber-300 to-orange-500',
      'from-yellow-300 to-amber-600',
      'from-white to-yellow-400',
    ],
    previewColor: '#fbbf24',
    previewGradient: 'from-amber-400 via-yellow-500 to-amber-700',
  },

  // 5. Emerald Box
  {
    id: 'box_emerald',
    name: 'Emerald Box',
    rarity: 'Advanced',
    price: 8000,
    tagline: 'Ancient Jade Matrix Bevel',
    description: 'Deep emerald beryl and verdant jade facets with mystical forest luminescence and polished gold brackets.',
    casingStyle: 'from-[#072d1f]/95 via-[#041a12]/95 to-[#020d09] border-emerald-400/50 shadow-[0_14px_45px_rgba(16,185,129,0.35)]',
    gridBorderColor: 'border-emerald-400/40',
    emptyCellBorder: 'border-emerald-300/25 hover:border-emerald-200',
    cellBg: 'bg-emerald-950/20',
    cornerDots: [
      'from-emerald-300 to-teal-500',
      'from-lime-300 to-green-600',
      'from-emerald-200 to-green-500',
      'from-teal-300 to-emerald-600',
    ],
    previewColor: '#34d399',
    previewGradient: 'from-emerald-400 via-teal-500 to-green-900',
  },

  // 6. Cyber Box
  {
    id: 'box_cyber',
    name: 'Cyber Box',
    rarity: 'Rare',
    price: 10000,
    tagline: 'Titanium Nanotech Enclosure',
    description: 'Precision carbon-fiber chassis with cyan telemetry line traces and illuminated sub-pixel cells.',
    casingStyle: 'from-[#091b2c]/95 via-[#06111d]/95 to-[#03080e] border-cyan-400/60 shadow-[0_14px_45px_rgba(6,182,212,0.4)]',
    gridBorderColor: 'border-cyan-400/50',
    emptyCellBorder: 'border-cyan-400/30 hover:border-cyan-200',
    cellBg: 'bg-cyan-950/30',
    cornerDots: [
      'from-cyan-300 to-blue-500',
      'from-blue-400 to-indigo-600',
      'from-cyan-400 to-teal-500',
      'from-sky-300 to-cyan-500',
    ],
    previewColor: '#06b6d4',
    previewGradient: 'from-cyan-500 via-blue-600 to-slate-900',
  },

  // 7. Galaxy Box
  {
    id: 'box_galaxy',
    name: 'Galaxy Box',
    rarity: 'Rare',
    price: 12000,
    tagline: 'Deep Cosmic Nebula Frame',
    description: 'Deep cosmic void casing sparkling with distant star clusters, violet dust lanes, and starlight reflections.',
    casingStyle: 'from-[#23093d]/95 via-[#140524]/95 to-[#08020e] border-purple-400/50 shadow-[0_14px_45px_rgba(168,85,247,0.4)]',
    gridBorderColor: 'border-purple-400/40',
    emptyCellBorder: 'border-purple-300/25 hover:border-pink-300',
    cellBg: 'bg-purple-950/25',
    cornerDots: [
      'from-fuchsia-400 to-purple-600',
      'from-pink-300 to-purple-500',
      'from-indigo-400 to-purple-600',
      'from-purple-300 to-pink-500',
    ],
    previewColor: '#a855f7',
    previewGradient: 'from-purple-600 via-fuchsia-600 to-slate-950',
  },

  // 8. Royal Box
  {
    id: 'box_royal',
    name: 'Royal Box',
    rarity: 'Epic',
    price: 15000,
    tagline: 'Crown Sovereign Velvet Frame',
    description: 'Regal velvet violet and platinum filigree casing adorned with majestic royal crest highlights.',
    casingStyle: 'from-[#330835]/95 via-[#1e0420]/95 to-[#0d020e] border-pink-300/60 shadow-[0_14px_45px_rgba(244,114,182,0.4)]',
    gridBorderColor: 'border-pink-300/50',
    emptyCellBorder: 'border-pink-300/30 hover:border-yellow-200',
    cellBg: 'bg-pink-950/30',
    cornerDots: [
      'from-amber-200 to-pink-400',
      'from-purple-300 to-pink-500',
      'from-yellow-300 to-rose-500',
      'from-pink-200 to-purple-400',
    ],
    previewColor: '#f472b6',
    previewGradient: 'from-pink-400 via-purple-600 to-amber-400',
  },

  // 9. Lava Box
  {
    id: 'box_lava',
    name: 'Lava Box',
    rarity: 'Epic',
    price: 18000,
    tagline: 'Magmatic Obsidian Crucible',
    description: 'Volcanic basalt stone frame etched with fiery glowing magma channels and incandescent amber embers.',
    casingStyle: 'from-[#380e06]/95 via-[#240803]/95 to-[#120301] border-rose-500/60 shadow-[0_14px_45px_rgba(244,63,94,0.45)]',
    gridBorderColor: 'border-rose-500/50',
    emptyCellBorder: 'border-orange-500/30 hover:border-yellow-300',
    cellBg: 'bg-rose-950/30',
    cornerDots: [
      'from-yellow-400 to-red-600',
      'from-orange-400 to-rose-600',
      'from-red-500 to-rose-700',
      'from-yellow-300 to-orange-500',
    ],
    previewColor: '#f43f5e',
    previewGradient: 'from-rose-500 via-orange-500 to-yellow-500',
  },

  // 10. Rainbow Glass Box
  {
    id: 'box_rainbow',
    name: 'Rainbow Glass Box',
    rarity: 'Legendary',
    price: 25000,
    tagline: 'Spectral Prismatic Wonder',
    description: 'Luminous chromatic crystal frame that refracts radiant rainbow spectral waves across every cell socket.',
    casingStyle: 'from-[#2e0e38]/95 via-[#180a29]/95 to-[#0b0416] border-white/60 shadow-[0_14px_50px_rgba(236,72,153,0.5)]',
    gridBorderColor: 'border-pink-300/60',
    emptyCellBorder: 'border-white/35 hover:border-amber-300',
    cellBg: 'bg-purple-950/30',
    cornerDots: [
      'from-rose-400 to-amber-400',
      'from-yellow-300 to-emerald-400',
      'from-cyan-300 to-blue-500',
      'from-purple-400 to-pink-500',
    ],
    previewColor: '#ec4899',
    previewGradient: 'from-pink-500 via-amber-400 via-emerald-400 via-cyan-400 to-purple-600',
  },
];
