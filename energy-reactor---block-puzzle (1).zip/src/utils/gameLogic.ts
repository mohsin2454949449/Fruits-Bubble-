import { BoardMatrix, GamePiece, PlacementPreview, ReactorColor } from '../types/game';

export const BOARD_SIZE = 7;

/**
 * Initializes a clean 7x7 reactor grid (49 cells)
 */
export function createEmptyBoard(): BoardMatrix {
  const board: BoardMatrix = [];
  for (let r = 0; r < BOARD_SIZE; r++) {
    const row = [];
    for (let c = 0; c < BOARD_SIZE; c++) {
      row.push({
        filled: false,
        color: null as ReactorColor | null,
        clearing: false,
      });
    }
    board.push(row);
  }
  return board;
}

/**
 * Checks whether a piece can be placed at board position (startRow, startCol)
 */
export function canPlacePiece(
  board: BoardMatrix,
  piece: GamePiece,
  startRow: number,
  startCol: number
): boolean {
  const { matrix, height, width } = piece.shape;

  // Boundary check
  if (startRow < 0 || startCol < 0) return false;
  if (startRow + height > BOARD_SIZE || startCol + width > BOARD_SIZE) return false;

  // Overlap check
  for (let r = 0; r < height; r++) {
    for (let c = 0; c < width; c++) {
      if (matrix[r][c] === 1) {
        const boardRow = startRow + r;
        const boardCol = startCol + c;
        if (board[boardRow][boardCol].filled) {
          return false;
        }
      }
    }
  }

  return true;
}

/**
 * Checks if a piece can fit ANYWHERE on the board
 */
export function canPieceFitAnywhere(board: BoardMatrix, piece: GamePiece): boolean {
  if (piece.used) return false;

  const { height, width } = piece.shape;
  for (let r = 0; r <= BOARD_SIZE - height; r++) {
    for (let c = 0; c <= BOARD_SIZE - width; c++) {
      if (canPlacePiece(board, piece, r, c)) {
        return true;
      }
    }
  }
  return false;
}

/**
 * Calculates placement preview and any lines that will be cleared
 */
export function getPlacementPreview(
  board: BoardMatrix,
  piece: GamePiece,
  startRow: number,
  startCol: number
): PlacementPreview | null {
  if (!canPlacePiece(board, piece, startRow, startCol)) {
    return null;
  }

  const { matrix, height, width } = piece.shape;
  const cells: { r: number; c: number }[] = [];

  // Temporary virtual board to calculate line clears
  const virtualBoard = board.map((row) => row.map((cell) => ({ ...cell })));

  for (let r = 0; r < height; r++) {
    for (let c = 0; c < width; c++) {
      if (matrix[r][c] === 1) {
        const tr = startRow + r;
        const tc = startCol + c;
        cells.push({ r: tr, c: tc });
        virtualBoard[tr][tc].filled = true;
      }
    }
  }

  // Find which rows will be completely filled
  const clearingRows: number[] = [];
  for (let r = 0; r < BOARD_SIZE; r++) {
    if (virtualBoard[r].every((cell) => cell.filled)) {
      clearingRows.push(r);
    }
  }

  // Find which cols will be completely filled
  const clearingCols: number[] = [];
  for (let c = 0; c < BOARD_SIZE; c++) {
    let colFull = true;
    for (let r = 0; r < BOARD_SIZE; r++) {
      if (!virtualBoard[r][c].filled) {
        colFull = false;
        break;
      }
    }
    if (colFull) {
      clearingCols.push(c);
    }
  }

  return {
    valid: true,
    startRow,
    startCol,
    cells,
    clearingRows,
    clearingCols,
  };
}

/**
 * Places piece and determines line clears
 */
export function placePieceOnBoard(
  board: BoardMatrix,
  piece: GamePiece,
  startRow: number,
  startCol: number
): {
  newBoard: BoardMatrix;
  clearedRows: number[];
  clearedCols: number[];
  cellsCount: number;
} {
  const newBoard = board.map((row) => row.map((cell) => ({ ...cell })));
  const { matrix, height, width } = piece.shape;
  let cellsCount = 0;

  for (let r = 0; r < height; r++) {
    for (let c = 0; c < width; c++) {
      if (matrix[r][c] === 1) {
        const br = startRow + r;
        const bc = startCol + c;
        newBoard[br][bc] = {
          filled: true,
          color: piece.color,
          clearing: false,
          justPlaced: true,
        };
        cellsCount++;
      }
    }
  }

  // Identify full rows
  const clearedRows: number[] = [];
  for (let r = 0; r < BOARD_SIZE; r++) {
    if (newBoard[r].every((cell) => cell.filled)) {
      clearedRows.push(r);
    }
  }

  // Identify full columns
  const clearedCols: number[] = [];
  for (let c = 0; c < BOARD_SIZE; c++) {
    let full = true;
    for (let r = 0; r < BOARD_SIZE; r++) {
      if (!newBoard[r][c].filled) {
        full = false;
        break;
      }
    }
    if (full) {
      clearedCols.push(c);
    }
  }

  return {
    newBoard,
    clearedRows,
    clearedCols,
    cellsCount,
  };
}

/**
 * Clears rows and columns from the board
 */
export function executeClearLines(
  board: BoardMatrix,
  clearedRows: number[],
  clearedCols: number[]
): BoardMatrix {
  const newBoard = board.map((row) => row.map((cell) => ({ ...cell })));

  // Clear rows
  for (const r of clearedRows) {
    for (let c = 0; c < BOARD_SIZE; c++) {
      newBoard[r][c] = {
        filled: false,
        color: null,
      };
    }
  }

  // Clear columns
  for (const c of clearedCols) {
    for (let r = 0; r < BOARD_SIZE; r++) {
      newBoard[r][c] = {
        filled: false,
        color: null,
      };
    }
  }

  return newBoard;
}

/**
 * Base line clear scoring table:
 * 1 completed line = 100 points
 * 2 completed lines simultaneously = 300 points
 * 3 completed lines simultaneously = 600 points
 * 4 completed lines simultaneously = 1000 points
 * For >4 lines: (n * (n + 1) / 2) * 100 (5 -> 1500, 6 -> 2100)
 */
export function getBaseLineScore(linesCleared: number): number {
  if (linesCleared <= 0) return 0;
  if (linesCleared === 1) return 100;
  if (linesCleared === 2) return 300;
  if (linesCleared === 3) return 600;
  if (linesCleared === 4) return 1000;
  return Math.round((linesCleared * (linesCleared + 1)) / 2) * 100;
}

/**
 * Consecutive successful line-clear multiplier:
 * - First consecutive clear = ×1
 * - Second consecutive clear = ×2
 * - Third consecutive clear = ×3
 * - Fourth and subsequent consecutive clears = ×4
 */
export function getComboMultiplier(consecutiveClears: number): number {
  if (consecutiveClears <= 0) return 1;
  if (consecutiveClears === 1) return 1;
  if (consecutiveClears === 2) return 2;
  if (consecutiveClears === 3) return 3;
  return 4;
}

export interface ScoreCalculationResult {
  baseScore: number;
  multiplier: number;
  finalPoints: number;
  newConsecutiveClears: number;
}

/**
 * Calculate score strictly for line clears:
 * - Block placement alone awards 0 points.
 * - Final Points = Base Score × Combo Multiplier
 * - If no line is cleared, combo resets to 0.
 */
export function calculateScore(
  linesCleared: number,
  currentConsecutiveClears: number
): ScoreCalculationResult {
  if (linesCleared <= 0) {
    return {
      baseScore: 0,
      multiplier: 1,
      finalPoints: 0,
      newConsecutiveClears: 0,
    };
  }

  const newConsecutiveClears = currentConsecutiveClears + 1;
  const baseScore = getBaseLineScore(linesCleared);
  const multiplier = getComboMultiplier(newConsecutiveClears);
  const finalPoints = baseScore * multiplier;

  return {
    baseScore,
    multiplier,
    finalPoints,
    newConsecutiveClears,
  };
}

/**
 * Rotates a 2D binary matrix exactly 90 degrees clockwise.
 * For an H x W matrix, output is W x H.
 * The cell at (r, c) moves to (c, H - 1 - r).
 * The number of filled cells (1s) and their relative structure is strictly preserved.
 */
export function rotateMatrix90(matrix: number[][]): number[][] {
  const H = matrix.length;
  const W = matrix[0].length;
  const rotated: number[][] = [];
  for (let c = 0; c < W; c++) {
    const row: number[] = new Array(H);
    for (let r = 0; r < H; r++) {
      row[H - 1 - r] = matrix[r][c];
    }
    rotated.push(row);
  }
  return rotated;
}

/**
 * Rotates a game piece 90 degrees clockwise:
 * - Rotates the complete core shape matrix.
 * - Updates shape width and height.
 * - Advances rotation (0 -> 90 -> 180 -> 270 -> 0).
 * - Preserves color, id, and used status.
 */
export function rotatePiece90(piece: GamePiece): GamePiece {
  const newMatrix = rotateMatrix90(piece.shape.matrix);
  const currentRotation = piece.rotation || 0;
  const nextRotation = (currentRotation + 90) % 360;

  return {
    ...piece,
    rotation: nextRotation,
    shape: {
      ...piece.shape,
      matrix: newMatrix,
      width: newMatrix[0].length,
      height: newMatrix.length,
    },
  };
}

/**
 * Checks if a piece can fit anywhere on the board in ANY of its 4 rotations (0°, 90°, 180°, 270°).
 */
export function canPieceFitWithRotation(board: BoardMatrix, piece: GamePiece): boolean {
  if (piece.used) return false;
  let testPiece = piece;
  for (let r = 0; r < 4; r++) {
    if (canPieceFitAnywhere(board, testPiece)) {
      return true;
    }
    testPiece = rotatePiece90(testPiece);
  }
  return false;
}

/**
 * Check if game is over (no remaining unused piece can fit anywhere, taking rotation into account)
 */
export function checkIsGameOver(board: BoardMatrix, pieces: GamePiece[]): boolean {
  const unusedPieces = pieces.filter((p) => !p.used);
  if (unusedPieces.length === 0) return false;

  return unusedPieces.every((piece) => !canPieceFitWithRotation(board, piece));
}
