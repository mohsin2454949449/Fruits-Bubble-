/**
 * Procedural Web Audio Synthesizer & Voice Announcer for Block Pulse
 * Generates custom arcade sound effects and crystal-clear human-like voice announcements.
 */

import { VOICE_AUDIO_BASE64 } from './voiceData';

class SoundSystem {
  private ctx: AudioContext | null = null;
  private isMuted: boolean = false;
  private isMusicMuted: boolean = false;
  private voiceBuffers: Map<number, AudioBuffer> = new Map();
  private audioElements: Map<number, HTMLAudioElement> = new Map();
  private lastVoicePlayTime: number = 0;
  private lastVoiceLines: number = 0;
  private activeVoiceSource: AudioBufferSourceNode | null = null;
  private currentAudioElement: HTMLAudioElement | null = null;
  private isBgmPlaying: boolean = false;
  private bgmGainNode: GainNode | null = null;
  private bgmTimerId: number | null = null;
  private bgmNextBeatTime: number = 0;
  private bgmCurrentBeat: number = 0;
  private readonly BGM_TEMPO: number = 114; // Happy, bouncy cartoon pace
  private readonly BGM_LOOP_BEATS: number = 64; // 16 measures of 4 beats
  private readonly BGM_VOLUME: number = 0.28; // 28% volume (25–30% requirement)

  constructor() {
    // Check localStorage for saved sound preference
    const saved = localStorage.getItem('block_pulse_muted') || localStorage.getItem('energy_reactor_muted');
    if (saved !== null) {
      this.isMuted = saved === 'true';
    }
    const savedMusic = localStorage.getItem('block_pulse_music_muted');
    if (savedMusic !== null) {
      this.isMusicMuted = savedMusic === 'true';
    }

    // Set up auto-unlock on first user interaction for Android and mobile browsers
    if (typeof window !== 'undefined') {
      const unlock = () => {
        this.unlockAudio();
        if (!this.isMusicMuted && !this.isBgmPlaying) {
          this.startBgm();
        }
      };
      window.addEventListener('pointerdown', unlock, { once: true, passive: true });
      window.addEventListener('touchstart', unlock, { once: true, passive: true });
      window.addEventListener('click', unlock, { once: true, passive: true });

      // Handle mobile visibility change to suspend/resume and conserve battery
      document.addEventListener('visibilitychange', () => {
        if (document.hidden) {
          if (this.ctx && this.ctx.state === 'running') {
            this.ctx.suspend().catch(() => {});
          }
        } else {
          if (this.ctx && this.ctx.state === 'suspended' && !this.isMusicMuted) {
            this.ctx.resume().catch(() => {});
          }
        }
      });
    }
  }

  private initCtx() {
    if (!this.ctx) {
      const AudioCtx = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      if (AudioCtx) {
        this.ctx = new AudioCtx();
        this.bgmGainNode = this.ctx.createGain();
        this.bgmGainNode.gain.setValueAtTime(this.BGM_VOLUME, this.ctx.currentTime);
        this.bgmGainNode.connect(this.ctx.destination);
      }
    }
    if (this.ctx && this.ctx.state === 'suspended') {
      this.ctx.resume().catch(() => {});
    }
  }

  /**
   * Unlock and pre-warm audio context and voice buffers on first user interaction
   */
  public unlockAudio() {
    this.initCtx();
    this.preloadVoices();
  }

  /**
   * Preload and decode voice audio files into Web Audio memory for instant 0ms playback
   */
  private preloadVoices() {
    [2, 3, 4, 5, 6, 7].forEach((lines) => {
      this.loadVoiceBuffer(lines);
      const entry = VOICE_AUDIO_BASE64[lines];
      if (entry && !this.audioElements.has(lines)) {
        try {
          const audio = new Audio(entry.dataUri);
          audio.preload = 'auto';
          this.audioElements.set(lines, audio);
        } catch {
          // Fallback handled gracefully
        }
      }
    });

    // Also pre-warm SpeechSynthesis voice list if available
    if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
      window.speechSynthesis.getVoices();
    }
  }

  private async loadVoiceBuffer(lines: number) {
    if (this.voiceBuffers.has(lines) || !this.ctx) return;
    const entry = VOICE_AUDIO_BASE64[lines];
    if (!entry) return;

    try {
      const res = await fetch(entry.dataUri);
      const arr = await res.arrayBuffer();
      if (this.ctx) {
        const audioBuffer = await this.ctx.decodeAudioData(arr);
        this.voiceBuffers.set(lines, audioBuffer);
      }
    } catch {
      // Handled via HTMLAudioElement or Web Speech API fallback
    }
  }

  public toggleMute(): boolean {
    this.isMuted = !this.isMuted;
    localStorage.setItem('block_pulse_muted', String(this.isMuted));
    if (this.isMuted) {
      this.stopVoice();
    }
    return this.isMuted;
  }

  public getMuted(): boolean {
    return this.isMuted;
  }

  public setMuted(muted: boolean): void {
    this.isMuted = muted;
    localStorage.setItem('block_pulse_muted', String(this.isMuted));
    if (this.isMuted) {
      this.stopVoice();
    }
  }

  public toggleMusic(): boolean {
    this.isMusicMuted = !this.isMusicMuted;
    localStorage.setItem('block_pulse_music_muted', String(this.isMusicMuted));
    if (this.isMusicMuted) {
      this.stopBgm();
    } else {
      this.startBgm();
    }
    return this.isMusicMuted;
  }

  public getMusicMuted(): boolean {
    return this.isMusicMuted;
  }

  public setMusicMuted(muted: boolean): void {
    this.isMusicMuted = muted;
    localStorage.setItem('block_pulse_music_muted', String(this.isMusicMuted));
    if (this.isMusicMuted) {
      this.stopBgm();
    } else {
      this.startBgm();
    }
  }

  /**
   * Cheerful, child-friendly cartoon-style instrumental BGM
   * Features soft xylophone/marimba, ukulele plucks, gentle bells, and playful pizzicato bass.
   * Microsecond lookahead scheduling ensures a seamless loop with zero breaks or stutters.
   */
  public startBgm() {
    if (this.isMusicMuted) return;
    if (this.isBgmPlaying) return; // Prevent duplicate playback across screen changes

    this.initCtx();
    if (!this.ctx) return;

    if (this.ctx.state === 'suspended') {
      this.ctx.resume().catch(() => {});
    }

    // Dedicated BGM master gain (kept at 28%, satisfying 25-30% volume requirement)
    if (!this.bgmGainNode) {
      this.bgmGainNode = this.ctx.createGain();
      this.bgmGainNode.gain.setValueAtTime(this.BGM_VOLUME, this.ctx.currentTime);
      this.bgmGainNode.connect(this.ctx.destination);
    } else {
      this.bgmGainNode.gain.cancelScheduledValues(this.ctx.currentTime);
      this.bgmGainNode.gain.setValueAtTime(this.BGM_VOLUME, this.ctx.currentTime);
    }

    this.isBgmPlaying = true;
    this.bgmNextBeatTime = this.ctx.currentTime + 0.05;
    this.bgmCurrentBeat = 0;

    const beatDuration = 60 / this.BGM_TEMPO;
    const lookahead = 0.16; // 160ms lookahead window

    // Ukulele chord progression across 16 bars (happy C major / F / G / Am bounce)
    const UKULELE_CHORDS: Record<number, number[]> = {
      0: [261.63, 329.63, 392.0, 523.25],   // C Maj
      1: [261.63, 349.23, 440.0, 523.25],   // F Maj
      2: [246.94, 293.66, 392.0, 493.88],   // G Maj
      3: [261.63, 329.63, 392.0, 523.25],   // C Maj
      4: [261.63, 329.63, 392.0, 523.25],   // C Maj
      5: [220.0, 261.63, 329.63, 440.0],    // A Min
      6: [261.63, 349.23, 440.0, 523.25],   // F Maj
      7: [261.63, 329.63, 392.0, 523.25],   // C Maj
      8: [246.94, 329.63, 392.0, 493.88],   // E Min
      9: [261.63, 349.23, 440.0, 523.25],   // F Maj
      10: [220.0, 293.66, 349.23, 440.0],   // D Min
      11: [246.94, 293.66, 392.0, 493.88],  // G Maj
      12: [261.63, 329.63, 392.0, 523.25],  // C Maj
      13: [261.63, 349.23, 440.0, 523.25],  // F Maj
      14: [246.94, 293.66, 392.0, 493.88],  // G Maj
      15: [261.63, 329.63, 392.0, 523.25],  // C Maj
    };

    // Playful Upright Bass progression (Roots and 5ths on beats 1 and 3)
    const BASS_NOTES: Record<number, [number, number]> = {
      0: [130.81, 98.0],    // C3 -> G2
      1: [87.31, 130.81],   // F2 -> C3
      2: [98.0, 146.83],    // G2 -> D3
      3: [130.81, 98.0],    // C3 -> G2
      4: [130.81, 98.0],    // C3 -> G2
      5: [110.0, 82.41],    // A2 -> E2
      6: [87.31, 98.0],     // F2 -> G2
      7: [130.81, 123.47],  // C3 -> B2
      8: [82.41, 123.47],   // E2 -> B2
      9: [87.31, 130.81],   // F2 -> C3
      10: [73.42, 110.0],   // D2 -> A2
      11: [98.0, 146.83],   // G2 -> D3
      12: [130.81, 82.41],  // C3 -> E2
      13: [87.31, 110.0],   // F2 -> A2
      14: [98.0, 98.0],     // G2 -> G2
      15: [130.81, 98.0],   // C3 -> G2
    };

    // Catchy, joyful cartoon marimba / xylophone lead melody
    const CARTOON_MELODY: Array<{ beat: number; freq: number; dur?: number; vel?: number }> = [
      // Movement 1: Joyful arpeggio & bounce (Bars 1-4)
      { beat: 0.0, freq: 523.25 }, // C5
      { beat: 0.5, freq: 659.25 }, // E5
      { beat: 1.0, freq: 783.99 }, // G5
      { beat: 2.0, freq: 659.25 }, // E5
      { beat: 3.0, freq: 783.99 }, // G5
      { beat: 4.0, freq: 880.0 },  // A5
      { beat: 5.0, freq: 783.99 }, // G5
      { beat: 6.0, freq: 698.46 }, // F5
      { beat: 7.0, freq: 659.25 }, // E5
      { beat: 8.0, freq: 587.33 }, // D5
      { beat: 8.5, freq: 659.25 }, // E5
      { beat: 9.0, freq: 698.46 }, // F5
      { beat: 10.0, freq: 587.33 },// D5
      { beat: 11.0, freq: 493.88 },// B4
      { beat: 12.0, freq: 523.25 },// C5
      { beat: 13.0, freq: 659.25 },// E5
      { beat: 14.0, freq: 783.99 },// G5

      // Movement 2: Leap to high C & bell descent (Bars 5-8)
      { beat: 16.0, freq: 523.25 }, // C5
      { beat: 17.0, freq: 659.25 }, // E5
      { beat: 18.0, freq: 783.99 }, // G5
      { beat: 19.0, freq: 1046.5 }, // C6
      { beat: 20.0, freq: 987.77 }, // B5
      { beat: 21.0, freq: 880.0 },  // A5
      { beat: 22.0, freq: 783.99 }, // G5
      { beat: 23.0, freq: 659.25 }, // E5
      { beat: 24.0, freq: 698.46 }, // F5
      { beat: 25.0, freq: 880.0 },  // A5
      { beat: 26.0, freq: 783.99 }, // G5
      { beat: 27.0, freq: 587.33 }, // D5
      { beat: 28.0, freq: 523.25 }, // C5
      { beat: 30.0, freq: 587.33 }, // D5
      { beat: 31.0, freq: 523.25 }, // C5

      // Movement 3: Playful staccato cartoon bridge (Bars 9-12)
      { beat: 32.0, freq: 659.25 }, // E5
      { beat: 32.5, freq: 659.25 }, // E5
      { beat: 33.0, freq: 783.99 }, // G5
      { beat: 34.0, freq: 880.0 },  // A5
      { beat: 36.0, freq: 783.99 }, // G5
      { beat: 37.0, freq: 659.25 }, // E5
      { beat: 38.0, freq: 587.33 }, // D5
      { beat: 39.0, freq: 523.25 }, // C5
      { beat: 40.0, freq: 587.33 }, // D5
      { beat: 40.5, freq: 587.33 }, // D5
      { beat: 41.0, freq: 698.46 }, // F5
      { beat: 42.0, freq: 783.99 }, // G5
      { beat: 44.0, freq: 880.0 },  // A5
      { beat: 45.0, freq: 987.77 }, // B5
      { beat: 46.0, freq: 1046.5 }, // C6

      // Movement 4: Relaxing resolution looping seamlessly to Bar 1 (Bars 13-16)
      { beat: 48.0, freq: 783.99 }, // G5
      { beat: 49.0, freq: 659.25 }, // E5
      { beat: 50.0, freq: 523.25 }, // C5
      { beat: 51.0, freq: 659.25 }, // E5
      { beat: 52.0, freq: 698.46 }, // F5
      { beat: 53.0, freq: 587.33 }, // D5
      { beat: 54.0, freq: 493.88 }, // B4
      { beat: 55.0, freq: 587.33 }, // D5
      { beat: 56.0, freq: 523.25 }, // C5
      { beat: 57.0, freq: 392.0 },  // G4
      { beat: 58.0, freq: 329.63 }, // E4
      { beat: 59.0, freq: 392.0 },  // G4
      { beat: 60.0, freq: 523.25 }, // C5
      { beat: 62.0, freq: 659.25 }, // E5
      { beat: 63.0, freq: 587.33 }, // D5
    ];

    // High sparkling glockenspiel bell accents
    const BELL_ACCENTS: Array<{ beat: number; freq: number }> = [
      { beat: 4.0, freq: 1046.5 },  // C6
      { beat: 14.0, freq: 1318.51 },// E6
      { beat: 19.0, freq: 1046.5 }, // C6
      { beat: 20.0, freq: 1567.98 },// G6
      { beat: 28.0, freq: 1046.5 }, // C6
      { beat: 46.0, freq: 1318.51 },// E6
      { beat: 60.0, freq: 1046.5 }, // C6
    ];

    const scheduleLoop = () => {
      if (!this.isBgmPlaying || this.isMusicMuted || !this.ctx || this.ctx.state !== 'running') {
        return;
      }

      while (this.bgmNextBeatTime < this.ctx.currentTime + lookahead) {
        const beatInLoop = this.bgmCurrentBeat % this.BGM_LOOP_BEATS;
        const beatTime = this.bgmNextBeatTime;
        const barIndex = Math.floor(beatInLoop / 4);
        const beatInBar = beatInLoop % 4;

        // 1. Playful Upright Bass on beats 0 and 2
        if (beatInBar === 0 && BASS_NOTES[barIndex]) {
          this.playPizzicatoBassNote(BASS_NOTES[barIndex][0], beatTime);
        } else if (beatInBar === 2 && BASS_NOTES[barIndex]) {
          this.playPizzicatoBassNote(BASS_NOTES[barIndex][1], beatTime);
        }

        // 2. Ukulele Plucked Chords on upbeat (skank rhythm)
        if (UKULELE_CHORDS[barIndex]) {
          this.playUkuleleChord(UKULELE_CHORDS[barIndex], beatTime + beatDuration * 0.5);
        }

        // 3. Marimba & Xylophone Melody Notes
        const notes = CARTOON_MELODY.filter(
          (m) => m.beat >= beatInLoop && m.beat < beatInLoop + 1
        );
        notes.forEach((m) => {
          const noteTime = beatTime + (m.beat - beatInLoop) * beatDuration;
          this.playMarimbaNote(m.freq, noteTime, m.dur, m.vel);
        });

        // 4. Glockenspiel Bell Accents
        const bells = BELL_ACCENTS.filter(
          (b) => b.beat >= beatInLoop && b.beat < beatInLoop + 1
        );
        bells.forEach((b) => {
          const bellTime = beatTime + (b.beat - beatInLoop) * beatDuration;
          this.playBellAccent(b.freq, bellTime);
        });

        this.bgmCurrentBeat++;
        this.bgmNextBeatTime += beatDuration;
      }

      this.bgmTimerId = window.setTimeout(scheduleLoop, 45);
    };

    scheduleLoop();
  }

  /**
   * Smoothly stops background music without clicking
   */
  public stopBgm() {
    this.isBgmPlaying = false;
    if (this.bgmTimerId !== null) {
      clearTimeout(this.bgmTimerId);
      this.bgmTimerId = null;
    }
    if (this.bgmGainNode && this.ctx) {
      try {
        this.bgmGainNode.gain.cancelScheduledValues(this.ctx.currentTime);
        this.bgmGainNode.gain.linearRampToValueAtTime(0.0001, this.ctx.currentTime + 0.08);
      } catch {
        // Ignored
      }
    }
  }

  /**
   * Soft cartoon marimba/xylophone tone with wooden bar resonance and mallet strike
   */
  private playMarimbaNote(freq: number, time: number, duration: number = 0.24, velocity: number = 0.22) {
    if (!this.ctx || !this.bgmGainNode) return;
    const t = Math.max(time, this.ctx.currentTime);

    // Primary wooden fundamental
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();
    const filter = this.ctx.createBiquadFilter();

    osc.type = 'sine';
    osc.frequency.setValueAtTime(freq, t);

    // Warm wooden resonator filter
    filter.type = 'bandpass';
    filter.frequency.setValueAtTime(freq * 1.5, t);
    filter.Q.setValueAtTime(1.1, t);

    // Percussive wooden envelope
    gain.gain.setValueAtTime(0.0001, t);
    gain.gain.linearRampToValueAtTime(velocity, t + 0.004);
    gain.gain.exponentialRampToValueAtTime(0.0001, t + duration);

    osc.connect(filter);
    filter.connect(gain);
    gain.connect(this.bgmGainNode);

    osc.start(t);
    osc.stop(t + duration + 0.02);

    // Mallet strike "tok" overtone
    const strikeOsc = this.ctx.createOscillator();
    const strikeGain = this.ctx.createGain();

    strikeOsc.type = 'triangle';
    strikeOsc.frequency.setValueAtTime(freq * 3.0, t);
    strikeGain.gain.setValueAtTime(velocity * 0.35, t);
    strikeGain.gain.exponentialRampToValueAtTime(0.0001, t + 0.045);

    strikeOsc.connect(strikeGain);
    strikeGain.connect(this.bgmGainNode);

    strikeOsc.start(t);
    strikeOsc.stop(t + 0.05);
  }

  /**
   * Strummed nylon-string ukulele chord with humanized micro-delay
   */
  private playUkuleleChord(frequencies: number[], time: number, velocity: number = 0.12) {
    if (!this.ctx || !this.bgmGainNode) return;
    const baseTime = Math.max(time, this.ctx.currentTime);

    frequencies.forEach((freq, idx) => {
      if (!this.ctx || !this.bgmGainNode) return;
      const strummedTime = baseTime + idx * 0.012;
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();
      const filter = this.ctx.createBiquadFilter();

      osc.type = 'triangle';
      osc.frequency.setValueAtTime(freq, strummedTime);

      filter.type = 'bandpass';
      filter.frequency.setValueAtTime(800, strummedTime);
      filter.Q.setValueAtTime(1.2, strummedTime);

      gain.gain.setValueAtTime(0.0001, strummedTime);
      gain.gain.linearRampToValueAtTime(velocity, strummedTime + 0.006);
      gain.gain.exponentialRampToValueAtTime(0.0001, strummedTime + 0.28);

      osc.connect(filter);
      filter.connect(gain);
      gain.connect(this.bgmGainNode);

      osc.start(strummedTime);
      osc.stop(strummedTime + 0.3);
    });
  }

  /**
   * Playful pizzicato cartoon upright bass note
   */
  private playPizzicatoBassNote(freq: number, time: number, duration: number = 0.36, velocity: number = 0.24) {
    if (!this.ctx || !this.bgmGainNode) return;
    const t = Math.max(time, this.ctx.currentTime);

    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();
    const filter = this.ctx.createBiquadFilter();

    osc.type = 'sine';
    osc.frequency.setValueAtTime(freq, t);

    // Warm rounded lowpass
    filter.type = 'lowpass';
    filter.frequency.setValueAtTime(240, t);

    gain.gain.setValueAtTime(0.0001, t);
    gain.gain.linearRampToValueAtTime(velocity, t + 0.008);
    gain.gain.exponentialRampToValueAtTime(0.0001, t + duration);

    osc.connect(filter);
    filter.connect(gain);
    gain.connect(this.bgmGainNode);

    osc.start(t);
    osc.stop(t + duration + 0.02);
  }

  /**
   * Gentle glockenspiel / music box bell accent with shimmer vibrato
   */
  private playBellAccent(freq: number, time: number, velocity: number = 0.10) {
    if (!this.ctx || !this.bgmGainNode) return;
    const t = Math.max(time, this.ctx.currentTime);

    const osc = this.ctx.createOscillator();
    const overtone = this.ctx.createOscillator();
    const gain = this.ctx.createGain();

    osc.type = 'sine';
    osc.frequency.setValueAtTime(freq, t);

    overtone.type = 'sine';
    overtone.frequency.setValueAtTime(freq * 2.76, t);

    gain.gain.setValueAtTime(0.0001, t);
    gain.gain.linearRampToValueAtTime(velocity, t + 0.003);
    gain.gain.exponentialRampToValueAtTime(0.0001, t + 0.75);

    osc.connect(gain);
    overtone.connect(gain);
    gain.connect(this.bgmGainNode);

    osc.start(t);
    overtone.start(t);
    osc.stop(t + 0.8);
    overtone.stop(t + 0.8);
  }

  /**
   * Immediately stops any playing voice audio or speech synthesis
   */
  public stopVoice() {
    if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
      window.speechSynthesis.cancel();
    }
    if (this.activeVoiceSource) {
      try {
        this.activeVoiceSource.stop();
      } catch {
        // Ignored
      }
      this.activeVoiceSource = null;
    }
    if (this.currentAudioElement) {
      this.currentAudioElement.pause();
      this.currentAudioElement.currentTime = 0;
    }
  }

  /**
   * Plays the actual human voice announcement matching the lines cleared:
   * 2 lines: "Nice!"
   * 3 lines: "Great!"
   * 4 lines: "Excellent!"
   * 5 lines: "Impressive!"
   * 6 lines: "Unbelievable!"
   * 7 lines: "Legendary!"
   */
  public playVoiceAnnouncement(linesCount: number) {
    if (this.isMuted) return;
    if (linesCount < 2) return;

    const clamped = Math.min(Math.max(linesCount, 2), 7);
    const now = Date.now();

    // Deduplication: prevent duplicate voice triggers within 350ms for the same line count
    if (now - this.lastVoicePlayTime < 350 && this.lastVoiceLines === clamped) {
      return;
    }
    this.lastVoicePlayTime = now;
    this.lastVoiceLines = clamped;

    const entry = VOICE_AUDIO_BASE64[clamped];
    if (!entry) return;

    this.unlockAudio();

    // 1. Primary path: Pre-decoded Web Audio buffer for crystal-clear zero-latency audio
    const buffer = this.voiceBuffers.get(clamped);
    if (buffer && this.ctx && this.ctx.state === 'running') {
      try {
        const source = this.ctx.createBufferSource();
        source.buffer = buffer;

        // Punchy, clear voice volume elevated above synth backdrop
        const gainNode = this.ctx.createGain();
        gainNode.gain.setValueAtTime(1.25, this.ctx.currentTime);

        source.connect(gainNode);
        gainNode.connect(this.ctx.destination);
        source.start(0);
        this.activeVoiceSource = source;
        return;
      } catch (err) {
        console.warn('Web Audio voice buffer error, trying HTMLAudio fallback:', err);
      }
    }

    // 2. Secondary path: Preloaded HTMLAudioElement with embedded dataUri
    try {
      let audio = this.audioElements.get(clamped);
      if (!audio) {
        audio = new Audio(entry.dataUri);
        this.audioElements.set(clamped, audio);
      }
      audio.currentTime = 0;
      audio.volume = 1.0;
      this.currentAudioElement = audio;
      const playPromise = audio.play();
      if (playPromise) {
        playPromise.catch(() => {
          // Fallback to Web Speech API if Audio element playback blocked
          this.speakWithSpeechSynthesis(entry.text);
        });
        return;
      }
    } catch {
      // 3. Tertiary fallback: Web Speech API
      this.speakWithSpeechSynthesis(entry.text);
    }
  }

  /**
   * Web Speech API fallback with high-energy arcade cadence
   */
  private speakWithSpeechSynthesis(text: string) {
    if (this.isMuted) return;
    if (typeof window === 'undefined' || !('speechSynthesis' in window)) return;

    try {
      window.speechSynthesis.cancel();
      const utterance = new SpeechSynthesisUtterance(text);
      utterance.volume = 1.0;
      utterance.rate = 1.12; // punchy, energetic
      utterance.pitch = 1.15; // upbeat arcade pitch
      utterance.lang = 'en-US';

      const voices = window.speechSynthesis.getVoices();
      if (voices && voices.length > 0) {
        const preferred =
          voices.find(
            (v) =>
              v.lang.startsWith('en') &&
              (v.name.includes('Natural') ||
                v.name.includes('Google') ||
                v.name.includes('Samantha') ||
                v.name.includes('Daniel') ||
                v.name.includes('Premium'))
          ) || voices.find((v) => v.lang.startsWith('en'));
        if (preferred) {
          utterance.voice = preferred;
        }
      }
      window.speechSynthesis.speak(utterance);
    } catch (e) {
      console.warn('Speech synthesis error:', e);
    }
  }

  /**
   * Sound played when piece rotates 90 degrees
   */
  public playRotate() {
    if (this.isMuted) return;
    this.initCtx();
    if (!this.ctx) return;

    const t = this.ctx.currentTime;
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();

    osc.type = 'sine';
    osc.frequency.setValueAtTime(440, t);
    osc.frequency.exponentialRampToValueAtTime(740, t + 0.08);

    gain.gain.setValueAtTime(0.14, t);
    gain.gain.exponentialRampToValueAtTime(0.001, t + 0.09);

    osc.connect(gain);
    gain.connect(this.ctx.destination);

    osc.start(t);
    osc.stop(t + 0.1);
  }

  /**
   * Sound played when picking up a piece
   */
  public playPickup() {
    if (this.isMuted) return;
    this.initCtx();
    if (!this.ctx) return;

    const t = this.ctx.currentTime;
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();

    osc.type = 'sine';
    osc.frequency.setValueAtTime(320, t);
    osc.frequency.exponentialRampToValueAtTime(580, t + 0.08);

    gain.gain.setValueAtTime(0.12, t);
    gain.gain.exponentialRampToValueAtTime(0.001, t + 0.09);

    osc.connect(gain);
    gain.connect(this.ctx.destination);

    osc.start(t);
    osc.stop(t + 0.1);
  }

  /**
   * Sound played when piece locks into the grid
   */
  public playPlace() {
    if (this.isMuted) return;
    this.initCtx();
    if (!this.ctx) return;

    const t = this.ctx.currentTime;

    // Sub-bass thud
    const osc1 = this.ctx.createOscillator();
    const gain1 = this.ctx.createGain();
    osc1.type = 'triangle';
    osc1.frequency.setValueAtTime(140, t);
    osc1.frequency.exponentialRampToValueAtTime(45, t + 0.12);

    gain1.gain.setValueAtTime(0.28, t);
    gain1.gain.exponentialRampToValueAtTime(0.001, t + 0.14);

    osc1.connect(gain1);
    gain1.connect(this.ctx.destination);
    osc1.start(t);
    osc1.stop(t + 0.15);

    // Metallic click
    const osc2 = this.ctx.createOscillator();
    const gain2 = this.ctx.createGain();
    osc2.type = 'sine';
    osc2.frequency.setValueAtTime(880, t);
    osc2.frequency.exponentialRampToValueAtTime(440, t + 0.05);

    gain2.gain.setValueAtTime(0.15, t);
    gain2.gain.exponentialRampToValueAtTime(0.001, t + 0.06);

    osc2.connect(gain2);
    gain2.connect(this.ctx.destination);
    osc2.start(t);
    osc2.stop(t + 0.07);
  }

  /**
   * Sound played for 1 line cleared
   */
  public playSingleClear() {
    if (this.isMuted) return;
    this.initCtx();
    if (!this.ctx) return;

    const t = this.ctx.currentTime;
    const osc1 = this.ctx.createOscillator();
    const osc2 = this.ctx.createOscillator();
    const gain = this.ctx.createGain();

    osc1.type = 'triangle';
    osc1.frequency.setValueAtTime(523.25, t); // C5
    osc1.frequency.exponentialRampToValueAtTime(659.25, t + 0.12); // E5

    osc2.type = 'sine';
    osc2.frequency.setValueAtTime(1046.5, t); // C6
    osc2.frequency.exponentialRampToValueAtTime(1318.5, t + 0.14);

    gain.gain.setValueAtTime(0.2, t);
    gain.gain.exponentialRampToValueAtTime(0.001, t + 0.22);

    osc1.connect(gain);
    osc2.connect(gain);
    gain.connect(this.ctx.destination);

    osc1.start(t);
    osc2.start(t);
    osc1.stop(t + 0.23);
    osc2.stop(t + 0.23);
  }

  /**
   * 2 Lines Clear: "NICE!"
   * Upbeat double chime with rich overtone harmonics
   */
  public playNiceSound() {
    if (this.isMuted) return;
    this.initCtx();
    if (!this.ctx) return;

    const t = this.ctx.currentTime;
    const notes = [587.33, 739.99, 880.0]; // D5, F#5, A5
    notes.forEach((freq, i) => {
      if (!this.ctx) return;
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();
      const st = t + i * 0.06;

      osc.type = 'triangle';
      osc.frequency.setValueAtTime(freq, st);
      osc.frequency.exponentialRampToValueAtTime(freq * 1.04, st + 0.16);

      // Balanced gain so human voice cuts through clearly
      gain.gain.setValueAtTime(0.12, st);
      gain.gain.exponentialRampToValueAtTime(0.001, st + 0.22);

      osc.connect(gain);
      gain.connect(this.ctx.destination);
      osc.start(st);
      osc.stop(st + 0.24);
    });

    // High sparkle ping
    const spark = this.ctx.createOscillator();
    const sparkGain = this.ctx.createGain();
    spark.type = 'sine';
    spark.frequency.setValueAtTime(1760, t + 0.1);
    sparkGain.gain.setValueAtTime(0.08, t + 0.1);
    sparkGain.gain.exponentialRampToValueAtTime(0.001, t + 0.28);
    spark.connect(sparkGain);
    sparkGain.connect(this.ctx.destination);
    spark.start(t + 0.1);
    spark.stop(t + 0.3);
  }

  /**
   * 3 Lines Clear: "GREAT!"
   * Triumphant triad chord fanfare with power surge
   */
  public playGreatSound() {
    if (this.isMuted) return;
    this.initCtx();
    if (!this.ctx) return;

    const t = this.ctx.currentTime;
    // Sub thump
    const sub = this.ctx.createOscillator();
    const subGain = this.ctx.createGain();
    sub.type = 'triangle';
    sub.frequency.setValueAtTime(130, t);
    sub.frequency.exponentialRampToValueAtTime(50, t + 0.18);
    subGain.gain.setValueAtTime(0.16, t);
    subGain.gain.exponentialRampToValueAtTime(0.001, t + 0.2);
    sub.connect(subGain);
    subGain.connect(this.ctx.destination);
    sub.start(t);
    sub.stop(t + 0.22);

    // Fast ascending arcade fanfare: G4 -> C5 -> E5 -> G5
    const chord = [392.0, 523.25, 659.25, 783.99];
    chord.forEach((freq, i) => {
      if (!this.ctx) return;
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();
      const st = t + i * 0.055;

      osc.type = 'sawtooth';
      osc.frequency.setValueAtTime(freq, st);
      osc.frequency.exponentialRampToValueAtTime(freq * 1.03, st + 0.22);

      const filter = this.ctx.createBiquadFilter();
      filter.type = 'lowpass';
      filter.frequency.setValueAtTime(1800, st);
      filter.frequency.exponentialRampToValueAtTime(3200, st + 0.15);

      gain.gain.setValueAtTime(0.10, st);
      gain.gain.exponentialRampToValueAtTime(0.001, st + 0.3);

      osc.connect(filter);
      filter.connect(gain);
      gain.connect(this.ctx.destination);
      osc.start(st);
      osc.stop(st + 0.32);
    });
  }

  /**
   * 4 Lines Clear: "EXCELLENT!"
   * Powerful quad-tone arcade fanfare with sub impact
   */
  public playExcellentSound() {
    if (this.isMuted) return;
    this.initCtx();
    if (!this.ctx) return;

    const t = this.ctx.currentTime;
    // Sub kick
    const sub = this.ctx.createOscillator();
    const subGain = this.ctx.createGain();
    sub.type = 'sine';
    sub.frequency.setValueAtTime(180, t);
    sub.frequency.exponentialRampToValueAtTime(35, t + 0.25);
    subGain.gain.setValueAtTime(0.18, t);
    subGain.gain.exponentialRampToValueAtTime(0.001, t + 0.28);
    sub.connect(subGain);
    subGain.connect(this.ctx.destination);
    sub.start(t);
    sub.stop(t + 0.3);

    // Quad fanfare: C5 -> E5 -> G5 -> C6
    const notes = [523.25, 659.25, 783.99, 1046.5];
    notes.forEach((freq, i) => {
      if (!this.ctx) return;
      const st = t + i * 0.05;
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();

      osc.type = 'triangle';
      osc.frequency.setValueAtTime(freq, st);
      osc.frequency.exponentialRampToValueAtTime(freq * 1.02, st + 0.3);

      gain.gain.setValueAtTime(0.12, st);
      gain.gain.exponentialRampToValueAtTime(0.001, st + 0.38);

      osc.connect(gain);
      gain.connect(this.ctx.destination);
      osc.start(st);
      osc.stop(t + 0.4);
    });

    // Sustained high chord ring
    const highRing = this.ctx.createOscillator();
    const ringGain = this.ctx.createGain();
    highRing.type = 'sine';
    highRing.frequency.setValueAtTime(2093, t + 0.2); // C7
    ringGain.gain.setValueAtTime(0.07, t + 0.2);
    ringGain.gain.exponentialRampToValueAtTime(0.001, t + 0.55);
    highRing.connect(ringGain);
    ringGain.connect(this.ctx.destination);
    highRing.start(t + 0.2);
    highRing.stop(t + 0.6);
  }

  /**
   * 5 Lines Clear: "IMPRESSIVE!"
   * Dramatic multi-stage laser sweep + soaring harmonic brass synth blast
   */
  public playImpressiveSound() {
    if (this.isMuted) return;
    this.initCtx();
    if (!this.ctx) return;

    const t = this.ctx.currentTime;
    // Sub pulse
    const sub = this.ctx.createOscillator();
    const subGain = this.ctx.createGain();
    sub.type = 'triangle';
    sub.frequency.setValueAtTime(220, t);
    sub.frequency.exponentialRampToValueAtTime(32, t + 0.35);
    subGain.gain.setValueAtTime(0.20, t);
    subGain.gain.exponentialRampToValueAtTime(0.001, t + 0.38);
    sub.connect(subGain);
    subGain.connect(this.ctx.destination);
    sub.start(t);
    sub.stop(t + 0.4);

    // Ascending 5-tone sweep: A4, C#5, E5, A5, C#6, E6
    const notes = [440, 554.37, 659.25, 880, 1108.73, 1318.5];
    notes.forEach((freq, i) => {
      if (!this.ctx) return;
      const st = t + i * 0.045;
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();

      osc.type = 'sawtooth';
      osc.frequency.setValueAtTime(freq, st);

      const filter = this.ctx.createBiquadFilter();
      filter.type = 'bandpass';
      filter.frequency.setValueAtTime(freq * 1.5, st);
      filter.Q.setValueAtTime(2.5, st);

      gain.gain.setValueAtTime(0.12, st);
      gain.gain.exponentialRampToValueAtTime(0.001, st + 0.45);

      osc.connect(filter);
      filter.connect(gain);
      gain.connect(this.ctx.destination);
      osc.start(st);
      osc.stop(st + 0.5);
    });
  }

  /**
   * 6 Lines Clear: "UNBELIEVABLE!"
   * Cosmic resonant arpeggio cascade + stereo pulse sweep
   */
  public playUnbelievableSound() {
    if (this.isMuted) return;
    this.initCtx();
    if (!this.ctx) return;

    const t = this.ctx.currentTime;
    // Sub boom
    const sub = this.ctx.createOscillator();
    const subGain = this.ctx.createGain();
    sub.type = 'sine';
    sub.frequency.setValueAtTime(240, t);
    sub.frequency.exponentialRampToValueAtTime(30, t + 0.45);
    subGain.gain.setValueAtTime(0.22, t);
    subGain.gain.exponentialRampToValueAtTime(0.001, t + 0.48);
    sub.connect(subGain);
    subGain.connect(this.ctx.destination);
    sub.start(t);
    sub.stop(t + 0.5);

    // 6-tone cascading arpeggio
    const chord = [392.0, 493.88, 587.33, 783.99, 987.77, 1174.66, 1567.98];
    chord.forEach((freq, i) => {
      if (!this.ctx) return;
      const st = t + i * 0.04;
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();

      osc.type = 'triangle';
      osc.frequency.setValueAtTime(freq, st);
      osc.frequency.exponentialRampToValueAtTime(freq * 1.05, st + 0.35);

      gain.gain.setValueAtTime(0.13, st);
      gain.gain.exponentialRampToValueAtTime(0.001, st + 0.55);

      osc.connect(gain);
      gain.connect(this.ctx.destination);
      osc.start(st);
      osc.stop(st + 0.6);
    });

    // Cosmic shimmer laser sweep
    const sweep = this.ctx.createOscillator();
    const sweepGain = this.ctx.createGain();
    sweep.type = 'sine';
    sweep.frequency.setValueAtTime(1000, t + 0.15);
    sweep.frequency.exponentialRampToValueAtTime(4000, t + 0.6);
    sweepGain.gain.setValueAtTime(0.08, t + 0.15);
    sweepGain.gain.exponentialRampToValueAtTime(0.001, t + 0.65);
    sweep.connect(sweepGain);
    sweepGain.connect(this.ctx.destination);
    sweep.start(t + 0.15);
    sweep.stop(t + 0.7);
  }

  /**
   * 7 Lines Clear: "LEGENDARY!"
   * Ultimate epic legendary synth explosion + massive fanfare chord stack
   */
  public playLegendarySound() {
    if (this.isMuted) return;
    this.initCtx();
    if (!this.ctx) return;

    const t = this.ctx.currentTime;
    // Monumental sub drop
    const sub = this.ctx.createOscillator();
    const subGain = this.ctx.createGain();
    sub.type = 'triangle';
    sub.frequency.setValueAtTime(260, t);
    sub.frequency.exponentialRampToValueAtTime(28, t + 0.6);
    subGain.gain.setValueAtTime(0.24, t);
    subGain.gain.exponentialRampToValueAtTime(0.001, t + 0.65);
    sub.connect(subGain);
    subGain.connect(this.ctx.destination);
    sub.start(t);
    sub.stop(t + 0.7);

    // Full 7-note cascading arpeggio
    const cascade = [261.63, 329.63, 392.0, 523.25, 659.25, 783.99, 1046.5, 1318.51];
    cascade.forEach((freq, i) => {
      if (!this.ctx) return;
      const st = t + i * 0.045;
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();

      osc.type = 'sawtooth';
      osc.frequency.setValueAtTime(freq, st);

      const filter = this.ctx.createBiquadFilter();
      filter.type = 'lowpass';
      filter.frequency.setValueAtTime(2200, st);
      filter.frequency.exponentialRampToValueAtTime(4500, st + 0.4);

      gain.gain.setValueAtTime(0.12, st);
      gain.gain.exponentialRampToValueAtTime(0.001, st + 0.6);

      osc.connect(filter);
      filter.connect(gain);
      gain.connect(this.ctx.destination);
      osc.start(st);
      osc.stop(st + 0.65);
    });

    // Radiant final sustained chord (C5 + G5 + C6 + E6)
    const finalChord = [523.25, 783.99, 1046.5, 1318.51, 2093.0];
    finalChord.forEach((freq) => {
      if (!this.ctx) return;
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();
      const st = t + 0.32;

      osc.type = 'triangle';
      osc.frequency.setValueAtTime(freq, st);

      gain.gain.setValueAtTime(0.11, st);
      gain.gain.exponentialRampToValueAtTime(0.001, st + 0.85);

      osc.connect(gain);
      gain.connect(this.ctx.destination);
      osc.start(st);
      osc.stop(st + 0.9);
    });
  }

  /**
   * Main dispatch for line clear announcements:
   * Plays the musical synth fanfare AND the matching human voice announcement!
   * 2 lines: "Nice!"
   * 3 lines: "Great!"
   * 4 lines: "Excellent!"
   * 5 lines: "Impressive!"
   * 6 lines: "Unbelievable!"
   * 7 lines: "Legendary!"
   */
  public playLineClearAnnouncement(linesCount: number) {
    if (linesCount <= 1) {
      this.playSingleClear();
      return;
    }

    // Play arcade musical accompaniment
    if (linesCount === 2) {
      this.playNiceSound();
    } else if (linesCount === 3) {
      this.playGreatSound();
    } else if (linesCount === 4) {
      this.playExcellentSound();
    } else if (linesCount === 5) {
      this.playImpressiveSound();
    } else if (linesCount === 6) {
      this.playUnbelievableSound();
    } else {
      this.playLegendarySound();
    }

    // Play spoken human-like voice announcement simultaneously
    this.playVoiceAnnouncement(linesCount);
  }

  /**
   * Dedicated satisfying sound played for COMBO achievements (x2, x3, x4...)
   */
  public playCombo(comboLevel: number) {
    if (this.isMuted) return;
    this.initCtx();
    if (!this.ctx) return;

    const t = this.ctx.currentTime;
    const baseFreq = 587.33 * Math.pow(1.12, Math.min(comboLevel, 6)); // D5 up

    // Double rising ping with punchy attack
    const osc1 = this.ctx.createOscillator();
    const gain1 = this.ctx.createGain();
    osc1.type = 'triangle';
    osc1.frequency.setValueAtTime(baseFreq, t);
    osc1.frequency.exponentialRampToValueAtTime(baseFreq * 1.5, t + 0.14);

    gain1.gain.setValueAtTime(0.24, t);
    gain1.gain.exponentialRampToValueAtTime(0.001, t + 0.28);

    osc1.connect(gain1);
    gain1.connect(this.ctx.destination);
    osc1.start(t);
    osc1.stop(t + 0.3);

    // Sparkling upper harmonic
    const osc2 = this.ctx.createOscillator();
    const gain2 = this.ctx.createGain();
    osc2.type = 'sine';
    osc2.frequency.setValueAtTime(baseFreq * 2, t + 0.05);
    osc2.frequency.exponentialRampToValueAtTime(baseFreq * 2.5, t + 0.2);

    gain2.gain.setValueAtTime(0.16, t + 0.05);
    gain2.gain.exponentialRampToValueAtTime(0.001, t + 0.35);

    osc2.connect(gain2);
    gain2.connect(this.ctx.destination);
    osc2.start(t + 0.05);
    osc2.stop(t + 0.38);
  }

  /**
   * Sound played when rows/columns are cleared (wrapper calling announcement)
   */
  public playClear(lineCount: number, _comboStreak?: number) {
    this.playLineClearAnnouncement(lineCount);
  }

  /**
   * Sound played on invalid placement attempt
   */
  public playInvalid() {
    if (this.isMuted) return;
    this.initCtx();
    if (!this.ctx) return;

    const t = this.ctx.currentTime;
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();

    osc.type = 'sawtooth';
    osc.frequency.setValueAtTime(130, t);
    osc.frequency.setValueAtTime(110, t + 0.05);

    gain.gain.setValueAtTime(0.08, t);
    gain.gain.exponentialRampToValueAtTime(0.001, t + 0.12);

    osc.connect(gain);
    gain.connect(this.ctx.destination);

    osc.start(t);
    osc.stop(t + 0.13);
  }

  /**
   * Sound played when game is over
   */
  public playGameOver() {
    if (this.isMuted) return;
    this.initCtx();
    if (!this.ctx) return;

    const t = this.ctx.currentTime;
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();

    osc.type = 'sawtooth';
    osc.frequency.setValueAtTime(320, t);
    osc.frequency.exponentialRampToValueAtTime(60, t + 0.7);

    gain.gain.setValueAtTime(0.2, t);
    gain.gain.exponentialRampToValueAtTime(0.001, t + 0.75);

    osc.connect(gain);
    gain.connect(this.ctx.destination);

    osc.start(t);
    osc.stop(t + 0.8);
  }

  /**
   * Sound played when UI button is pressed
   */
  public playClick() {
    if (this.isMuted) return;
    this.initCtx();
    if (!this.ctx) return;

    const t = this.ctx.currentTime;
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();

    osc.type = 'sine';
    osc.frequency.setValueAtTime(600, t);
    osc.frequency.exponentialRampToValueAtTime(300, t + 0.04);

    gain.gain.setValueAtTime(0.08, t);
    gain.gain.exponentialRampToValueAtTime(0.001, t + 0.05);

    osc.connect(gain);
    gain.connect(this.ctx.destination);

    osc.start(t);
    osc.stop(t + 0.06);
  }

  /**
   * Triumphant Level Complete Fanfare
   */
  public playLevelComplete() {
    if (this.isMuted) return;
    this.initCtx();
    if (!this.ctx) return;

    const t = this.ctx.currentTime;
    // Major chord fanfare: C5 -> E5 -> G5 -> C6 -> E6
    const chord = [523.25, 659.25, 783.99, 1046.5, 1318.5];
    chord.forEach((freq, idx) => {
      if (!this.ctx) return;
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();
      const startTime = t + idx * 0.08;

      osc.type = 'triangle';
      osc.frequency.setValueAtTime(freq, startTime);
      osc.frequency.exponentialRampToValueAtTime(freq * 1.02, startTime + 0.4);

      gain.gain.setValueAtTime(0.2, startTime);
      gain.gain.exponentialRampToValueAtTime(0.001, startTime + 0.55);

      osc.connect(gain);
      gain.connect(this.ctx.destination);
      osc.start(startTime);
      osc.stop(startTime + 0.6);
    });

    // Grand final shimmer chord
    setTimeout(() => {
      if (this.isMuted || !this.ctx) return;
      const tEnd = this.ctx.currentTime;
      [1046.5, 1318.5, 1567.98, 2093].forEach((f) => {
        if (!this.ctx) return;
        const osc = this.ctx.createOscillator();
        const gain = this.ctx.createGain();
        osc.type = 'sine';
        osc.frequency.setValueAtTime(f, tEnd);
        gain.gain.setValueAtTime(0.12, tEnd);
        gain.gain.exponentialRampToValueAtTime(0.001, tEnd + 0.8);
        osc.connect(gain);
        gain.connect(this.ctx.destination);
        osc.start(tEnd);
        osc.stop(tEnd + 0.85);
      });
    }, 450);
  }

  /**
   * Sound played when collecting coins / claiming daily rewards
   */
  public playCoin() {
    if (this.isMuted) return;
    this.initCtx();
    if (!this.ctx) return;

    const t = this.ctx.currentTime;
    const osc1 = this.ctx.createOscillator();
    const osc2 = this.ctx.createOscillator();
    const gain = this.ctx.createGain();

    osc1.type = 'sine';
    osc1.frequency.setValueAtTime(987.77, t); // B5
    osc1.frequency.setValueAtTime(1318.51, t + 0.08); // E6

    osc2.type = 'triangle';
    osc2.frequency.setValueAtTime(1975.53, t); // B6
    osc2.frequency.setValueAtTime(2637.02, t + 0.08); // E7

    gain.gain.setValueAtTime(0.18, t);
    gain.gain.exponentialRampToValueAtTime(0.001, t + 0.35);

    osc1.connect(gain);
    osc2.connect(gain);
    gain.connect(this.ctx.destination);

    osc1.start(t);
    osc2.start(t);
    osc1.stop(t + 0.38);
    osc2.stop(t + 0.38);
  }

  /**
   * Sound played when purchasing/equipping items in store
   */
  public playPurchase() {
    if (this.isMuted) return;
    this.initCtx();
    if (!this.ctx) return;

    const t = this.ctx.currentTime;
    const notes = [659.25, 880, 1174.66, 1760];
    notes.forEach((freq, idx) => {
      if (!this.ctx) return;
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();
      const st = t + idx * 0.04;
      osc.type = 'triangle';
      osc.frequency.setValueAtTime(freq, st);
      gain.gain.setValueAtTime(0.15, st);
      gain.gain.exponentialRampToValueAtTime(0.001, st + 0.2);
      osc.connect(gain);
      gain.connect(this.ctx.destination);
      osc.start(st);
      osc.stop(st + 0.22);
    });
  }

  /**
   * Sound played when activating a powerup (Hammer / Reroll)
   */
  public playPowerup() {
    if (this.isMuted) return;
    this.initCtx();
    if (!this.ctx) return;

    const t = this.ctx.currentTime;
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();

    osc.type = 'sawtooth';
    osc.frequency.setValueAtTime(220, t);
    osc.frequency.exponentialRampToValueAtTime(1200, t + 0.25);

    gain.gain.setValueAtTime(0.2, t);
    gain.gain.exponentialRampToValueAtTime(0.001, t + 0.28);

    osc.connect(gain);
    gain.connect(this.ctx.destination);
    osc.start(t);
    osc.stop(t + 0.3);
  }
}

export const sound = new SoundSystem();
