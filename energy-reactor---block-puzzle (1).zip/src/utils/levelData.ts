import { LevelData } from '../types/game';

export const TOTAL_LEVELS = 1000;
export const BATCH_SIZE = 50;
export const TOTAL_BATCHES = Math.ceil(TOTAL_LEVELS / BATCH_SIZE); // 20 batches

export interface BiomeInfo {
  id: number;
  name: string;
  themeFruit: string;
  startLevel: number;
  endLevel: number;
  roadGradient: [string, string, string];
  bgGradient: string;
  accentColor: string;
}

export const BIOMES: BiomeInfo[] = [
  {
    id: 1,
    name: 'Strawberry Meadow',
    themeFruit: '🍓',
    startLevel: 1,
    endLevel: 50,
    roadGradient: ['#ff4071', '#ff7844', '#ffd043'],
    bgGradient: 'from-[#19062b] via-[#24083d] to-[#0f031e]',
    accentColor: '#f43f5e',
  },
  {
    id: 2,
    name: 'Sunny Citrus Grove',
    themeFruit: '🍊',
    startLevel: 51,
    endLevel: 100,
    roadGradient: ['#f97316', '#fbbf24', '#38bdf8'],
    bgGradient: 'from-[#1e0a24] via-[#2d121c] to-[#120517]',
    accentColor: '#f97316',
  },
  {
    id: 3,
    name: 'Lemon Lagoon',
    themeFruit: '🍋',
    startLevel: 101,
    endLevel: 150,
    roadGradient: ['#eab308', '#22c55e', '#06b6d4'],
    bgGradient: 'from-[#1a1708] via-[#1a281e] to-[#0b1318]',
    accentColor: '#eab308',
  },
  {
    id: 4,
    name: 'Kiwi Paradise Valley',
    themeFruit: '🥝',
    startLevel: 151,
    endLevel: 200,
    roadGradient: ['#10b981', '#06b6d4', '#a855f7'],
    bgGradient: 'from-[#071f18] via-[#09252c] to-[#0c1024]',
    accentColor: '#10b981',
  },
  {
    id: 5,
    name: 'Royal Grape Highlands',
    themeFruit: '🍇',
    startLevel: 201,
    endLevel: 250,
    roadGradient: ['#a855f7', '#ec4899', '#f43f5e'],
    bgGradient: 'from-[#1e0832] via-[#270929] to-[#120320]',
    accentColor: '#a855f7',
  },
  {
    id: 6,
    name: 'Blueberry Glade',
    themeFruit: '🫐',
    startLevel: 251,
    endLevel: 300,
    roadGradient: ['#0284c7', '#38bdf8', '#c084fc'],
    bgGradient: 'from-[#051833] via-[#0d2149] to-[#090b21]',
    accentColor: '#0284c7',
  },
  {
    id: 7,
    name: 'Watermelon Oasis',
    themeFruit: '🍉',
    startLevel: 301,
    endLevel: 350,
    roadGradient: ['#f43f5e', '#10b981', '#fbbf24'],
    bgGradient: 'from-[#24061a] via-[#0b241b] to-[#0d071b]',
    accentColor: '#f43f5e',
  },
  {
    id: 8,
    name: 'Peach Blossom Orchard',
    themeFruit: '🍑',
    startLevel: 351,
    endLevel: 400,
    roadGradient: ['#fb7185', '#fb923c', '#facc15'],
    bgGradient: 'from-[#2b0c1e] via-[#33161d] to-[#18071e]',
    accentColor: '#fb7185',
  },
  {
    id: 9,
    name: 'Cherry Pop Peaks',
    themeFruit: '🍒',
    startLevel: 401,
    endLevel: 450,
    roadGradient: ['#e11d48', '#f43f5e', '#a855f7'],
    bgGradient: 'from-[#2d0717] via-[#220930] to-[#14021a]',
    accentColor: '#e11d48',
  },
  {
    id: 10,
    name: 'Golden Pineapple Reef',
    themeFruit: '🍍',
    startLevel: 451,
    endLevel: 500,
    roadGradient: ['#f59e0b', '#84cc16', '#06b6d4'],
    bgGradient: 'from-[#241505] via-[#122618] to-[#081b24]',
    accentColor: '#f59e0b',
  },
  {
    id: 11,
    name: 'Tropical Mango Cove',
    themeFruit: '🥭',
    startLevel: 501,
    endLevel: 550,
    roadGradient: ['#f97316', '#fbbf24', '#f43f5e'],
    bgGradient: 'from-[#2b1008] via-[#301c0c] to-[#170a1a]',
    accentColor: '#f97316',
  },
  {
    id: 12,
    name: 'Apple Crisp Canyon',
    themeFruit: '🍎',
    startLevel: 551,
    endLevel: 600,
    roadGradient: ['#dc2626', '#16a34a', '#eab308'],
    bgGradient: 'from-[#290808] via-[#182310] to-[#12071a]',
    accentColor: '#dc2626',
  },
  {
    id: 13,
    name: 'Dragonfruit Dunes',
    themeFruit: '🐲',
    startLevel: 601,
    endLevel: 650,
    roadGradient: ['#db2777', '#f43f5e', '#38bdf8'],
    bgGradient: 'from-[#2b0824] via-[#1a0730] to-[#090e24]',
    accentColor: '#db2777',
  },
  {
    id: 14,
    name: 'Coconut Breeze Isle',
    themeFruit: '🥥',
    startLevel: 651,
    endLevel: 700,
    roadGradient: ['#10b981', '#0ea5e9', '#f59e0b'],
    bgGradient: 'from-[#07241d] via-[#0b2038] to-[#171408]',
    accentColor: '#10b981',
  },
  {
    id: 15,
    name: 'Banana Bounce Jungle',
    themeFruit: '🍌',
    startLevel: 701,
    endLevel: 750,
    roadGradient: ['#facc15', '#84cc16', '#f97316'],
    bgGradient: 'from-[#261f08] via-[#18260a] to-[#12061e]',
    accentColor: '#facc15',
  },
  {
    id: 16,
    name: 'Papaya Sunset Bay',
    themeFruit: '🍈',
    startLevel: 751,
    endLevel: 800,
    roadGradient: ['#f97316', '#ec4899', '#8b5cf6'],
    bgGradient: 'from-[#2b1107] via-[#290c27] to-[#13072b]',
    accentColor: '#f97316',
  },
  {
    id: 17,
    name: 'Berry Frost Cavern',
    themeFruit: '❄️',
    startLevel: 801,
    endLevel: 850,
    roadGradient: ['#38bdf8', '#818cf8', '#c084fc'],
    bgGradient: 'from-[#07192f] via-[#101438] to-[#190930]',
    accentColor: '#38bdf8',
  },
  {
    id: 18,
    name: 'Neon Bubble Realm',
    themeFruit: '🫧',
    startLevel: 851,
    endLevel: 900,
    roadGradient: ['#a855f7', '#06b6d4', '#f43f5e'],
    bgGradient: 'from-[#1a0636] via-[#062438] to-[#260620]',
    accentColor: '#a855f7',
  },
  {
    id: 19,
    name: 'Celestial Fruit Galaxy',
    themeFruit: '✨',
    startLevel: 901,
    endLevel: 950,
    roadGradient: ['#6366f1', '#ec4899', '#fbbf24'],
    bgGradient: 'from-[#0e0c38] via-[#290d33] to-[#1e1308]',
    accentColor: '#6366f1',
  },
  {
    id: 20,
    name: 'Grand Master Summit',
    themeFruit: '👑',
    startLevel: 951,
    endLevel: 1000,
    roadGradient: ['#fbbf24', '#f59e0b', '#ec4899'],
    bgGradient: 'from-[#2d1b06] via-[#331122] to-[#170529]',
    accentColor: '#fbbf24',
  },
];

// Presets for first 10 tutorial / gentle introduction levels
const TUTORIAL_TARGETS: Record<number, number> = {
  1: 500,
  2: 1000,
  3: 1800,
  4: 2800,
  5: 4000,
  6: 5400,
  7: 7000,
  8: 8800,
  9: 10800,
  10: 13000,
};

/**
 * Calculates a well-balanced target score for any level from 1 to 1000.
 * Ensures smooth, gradual progression that is always fair and rewarding.
 */
export function getLevelTarget(levelNumber: number): number {
  if (levelNumber <= 10 && TUTORIAL_TARGETS[levelNumber]) {
    return TUTORIAL_TARGETS[levelNumber];
  }

  // Smooth curve for levels 11 to 1000
  if (levelNumber <= 50) {
    // 13,000 to ~48,000 (+875 pts / level)
    return Math.round((13000 + (levelNumber - 10) * 875) / 100) * 100;
  }

  if (levelNumber <= 100) {
    // 48,000 to ~86,000 (+760 pts / level)
    return Math.round((48000 + (levelNumber - 50) * 760) / 100) * 100;
  }

  if (levelNumber <= 250) {
    // 86,000 to ~195,000 (+725 pts / level)
    return Math.round((86000 + (levelNumber - 100) * 725) / 100) * 100;
  }

  if (levelNumber <= 500) {
    // 195,000 to ~365,000 (+680 pts / level)
    return Math.round((195000 + (levelNumber - 250) * 680) / 250) * 250;
  }

  // Levels 501 to 1000: reaches up to ~690,000 pts (+650 pts / level)
  return Math.round((365000 + (levelNumber - 500) * 650) / 500) * 500;
}

/**
 * Get which batch index (1 to 20) a level belongs to
 */
export function getBatchForLevel(levelNumber: number): number {
  const bounded = Math.max(1, Math.min(TOTAL_LEVELS, levelNumber));
  return Math.floor((bounded - 1) / BATCH_SIZE) + 1;
}

/**
 * Get Biome information for a given batch index (1 to 20)
 */
export function getBiomeForBatch(batchNumber: number): BiomeInfo {
  const idx = Math.max(1, Math.min(TOTAL_BATCHES, batchNumber)) - 1;
  return BIOMES[idx];
}

/**
 * Generates LevelData for any level number 1 to 1000
 */
export function getLevelData(levelNumber: number): LevelData {
  const targetScore = getLevelTarget(levelNumber);
  const batchNum = getBatchForLevel(levelNumber);
  const biome = getBiomeForBatch(batchNum);
  const stepInBatch = ((levelNumber - 1) % BATCH_SIZE) + 1;

  // Coin rewards scale with level
  const rewardCoins = 100 + Math.min((levelNumber - 1) * 15, 3000);

  let difficulty: LevelData['difficulty'] = 'normal';
  if (levelNumber > 750) difficulty = 'legendary';
  else if (levelNumber > 350) difficulty = 'expert';
  else if (levelNumber > 100) difficulty = 'hard';

  // Thematic titles
  const STAGE_TITLES = [
    'Fruit Blossom', 'Sweet Breeze', 'Juice Splash', 'Sugar Peak', 'Berry Burst',
    'Tandem Pop', 'Sunny Trail', 'Bubble Cascade', 'Gummy Grove', 'Zesty Summit',
  ];
  const titleSuffix = STAGE_TITLES[(stepInBatch - 1) % STAGE_TITLES.length];
  const title = `${biome.name} #${stepInBatch} – ${titleSuffix}`;

  return {
    levelNumber,
    targetScore,
    rewardCoins,
    title,
    difficulty,
  };
}

/**
 * Returns exactly 50 levels for a specific batch (batchNumber 1 to 20)
 */
export function getBatchLevels(batchNumber: number): LevelData[] {
  const batch = Math.max(1, Math.min(TOTAL_BATCHES, batchNumber));
  const startLevel = (batch - 1) * BATCH_SIZE + 1;
  const endLevel = Math.min(batch * BATCH_SIZE, TOTAL_LEVELS);

  const levels: LevelData[] = [];
  for (let l = startLevel; l <= endLevel; l++) {
    levels.push(getLevelData(l));
  }
  return levels;
}

/**
 * Legacy support: returns initial batch of 50 levels (or all requested)
 */
export function getAllLevels(): LevelData[] {
  return getBatchLevels(1);
}
