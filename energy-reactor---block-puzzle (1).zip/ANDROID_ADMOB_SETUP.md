# Google AdMob Android Setup & Monetization Guide

This document outlines the AdMob architecture and the manual steps required when building the release Android APK for the **Fruit Bubble Puzzle** game.

---

## 1. What Has Been Implemented (In Code)

- **Centralized AdMob Configuration (`src/services/admobConfig.ts`)**:
  - Google's official Android Test App ID: `ca-app-pub-3940256099942544~3347511713`
  - Interstitial Test Ad Unit ID: `ca-app-pub-3940256099942544/1033173712`
  - Rewarded Video Test Ad Unit ID: `ca-app-pub-3940256099942544/5224354917`
  - Cooldown rules (90s minimum cooldown between interstitials, 30s cooldown between voluntary rewarded ads)
  - Frequency rules (interstitials trigger strictly every 3 completed levels at level transitions)

- **Capacitor Configuration (`capacitor.config.json`)**:
  - Pre-configured with App ID `com.fruitbubble.puzzle`, app name `Fruit Bubble Puzzle`, and web directory `dist`.

- **AdMob Service (`src/services/admobService.ts`)**:
  - Detects native Android bridge (`window.Capacitor.Plugins.AdMob` or `window.AndroidAdMob`).
  - Seamlessly falls back to the in-app interactive Google AdMob Test Ad player when running in web preview or browser testing.
  - Strict reward confirmation callback: rewards are **never** credited if an ad is skipped, canceled, or closed early.
  - Offline network detection and friendly error toast if ads fail to load.

- **Rewarded Video Ad Touchpoints**:
  1. **Free Coins Modal (`WatchAdModal.tsx`)**:
     - Voluntary "Quick Boost" (+500 Coins)
     - Voluntary "Super Stash" (+1,000 Coins)
  2. **Home Screen**:
     - Voluntary "Free Coins (Watch Ad)" banner and +Ad pill on Coins counter.
  3. **Cosmetics Store**:
     - Voluntary +Ad button in the store header.
  4. **Level Completion Modal**:
     - Voluntary "Watch Ad for Bonus (+500 Coins)" button on level clear.

- **Interstitial Ads at Natural Transitions**:
  - Triggers **only** when exiting the Level Complete screen (`onContinue`, `onReplay`, or `onHome`).
  - Strict gate: requires at least 3 completed levels (`levelsCompletedSinceLastAd >= 3`) and 90s cooldown.
  - **Never** interrupts active gameplay, block placement, or rotation.

- **Interactive Google Test Ad Player (`AdMobTestPlayer.tsx`)**:
  - Renders official Google AdMob test banner with logo and Ad Unit ID.
  - Realistic countdown with progress bar.
  - Forfeiture protection dialog: warns user before exiting a rewarded video early so they don't lose coins unintentionally.

---

## 2. Android Project Configuration (For Packaging APK)

To compile the application into an Android `.apk` or `.aab`:

### Step 2.1: Add the Android Platform
Run the following in the project terminal:
```bash
npm run build
npx cap add android
```

### Step 2.2: Install Capacitor AdMob Plugin (if using Capacitor plugin)
```bash
npm install @capacitor-community/admob
npx cap sync android
```

### Step 2.3: Configure `android/app/src/main/AndroidManifest.xml`
Inside the `<application>` tag, insert your AdMob App ID:
```xml
<!-- Google AdMob Application ID (Official Android Test App ID) -->
<meta-data
    android:name="com.google.android.gms.ads.APPLICATION_ID"
    android:value="ca-app-pub-3940256099942544~3347511713"/>

<uses-permission android:name="android.permission.INTERNET"/>
<uses-permission android:name="android.permission.ACCESS_NETWORK_STATE"/>
```

---

## 3. Switching to Production AdMob IDs (Before Publishing)

When you are ready to publish on the Google Play Store:
1. Create your app in [Google AdMob Console](https://admob.google.com).
2. Create an **Interstitial** ad unit and a **Rewarded Video** ad unit.
3. Update `src/services/admobConfig.ts`:
   - Set `IS_TESTING: false`
   - Replace `APP_ID` with your real AdMob App ID
   - Replace `INTERSTITIAL_TEST_ID` with your real Interstitial Ad Unit ID
   - Replace `REWARDED_TEST_ID` with your real Rewarded Ad Unit ID
4. Update `AndroidManifest.xml` with your real AdMob App ID.
